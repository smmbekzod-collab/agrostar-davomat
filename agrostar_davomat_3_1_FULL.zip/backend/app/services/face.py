from __future__ import annotations
import io
import numpy as np
from PIL import Image, ImageOps
from deepface import DeepFace
from app.core.config import settings


class FaceError(ValueError):
    pass


def _decode(image_bytes: bytes) -> np.ndarray:
    if not image_bytes or len(image_bytes) > settings.max_upload_bytes:
        raise FaceError("Rasm hajmi noto'g'ri yoki juda katta")
    try:
        with Image.open(io.BytesIO(image_bytes)) as opened:
            # EXIF orientationni real piksel yo'nalishiga aylantiramiz.
            img = ImageOps.exif_transpose(opened).convert("RGB")
            if img.width < 160 or img.height < 160:
                raise FaceError("Rasm sifati juda past")
            if img.width * img.height > 24_000_000:
                raise FaceError("Rasm o'lchami juda katta")
            return np.asarray(img)
    except FaceError:
        raise
    except Exception as exc:
        raise FaceError("Rasmni o'qib bo'lmadi") from exc


def _rotations(img: np.ndarray) -> list[tuple[str, np.ndarray]]:
    """Ba'zi Android kameralar EXIFsiz 90° aylangan JPEG berishi mumkin."""
    return [
        ("0", img),
        ("90", np.ascontiguousarray(np.rot90(img, 1))),
        ("270", np.ascontiguousarray(np.rot90(img, 3))),
        ("180", np.ascontiguousarray(np.rot90(img, 2))),
    ]


def _detector_backends() -> list[str]:
    backends = [settings.face_detector]
    # RetinaFace biror qurilma JPEGida topa olmasa, OpenCV detector fallback bo'ladi.
    if settings.face_detector != "opencv":
        backends.append("opencv")
    return backends


def _find_single_face_image(img: np.ndarray) -> tuple[np.ndarray, str]:
    """Yuz bor bo'lgan to'g'ri orientatsiya va detectorni topadi.

    Bu bosqich livenessni o'chirmaydi; faqat qaysi aylanishda aynan bitta yuz
    borligini aniqlaydi. Anti-spoofing keyingi bosqichda majburiy bajariladi.
    """
    last_error: Exception | None = None
    saw_multiple = False
    for _, candidate in _rotations(img):
        for detector in _detector_backends():
            try:
                faces = DeepFace.extract_faces(
                    img_path=candidate,
                    detector_backend=detector,
                    enforce_detection=True,
                    align=True,
                    anti_spoofing=False,
                )
                if len(faces) == 1:
                    return candidate, detector
                if len(faces) > 1:
                    saw_multiple = True
            except Exception as exc:
                last_error = exc
                continue
    if saw_multiple:
        raise FaceError("Kadrda aynan bitta yuz bo'lishi kerak")
    detail = f": {last_error}" if last_error else ""
    raise FaceError(f"Yuz aniqlanmadi. Telefonni tik tuting, yuzni markazga yaqinlashtiring va yorug' joyda qayta oling{detail}")


def extract_embedding(image_bytes: bytes, require_liveness: bool = True) -> tuple[list[float], float | None]:
    img = _decode(image_bytes)
    face_img, detector = _find_single_face_image(img)

    anti_score = None
    if require_liveness:
        try:
            live_faces = DeepFace.extract_faces(
                img_path=face_img,
                detector_backend=detector,
                enforce_detection=True,
                align=True,
                anti_spoofing=True,
            )
        except Exception as exc:
            raise FaceError(f"Jonli yuz tekshiruvini bajarib bo'lmadi: {exc}") from exc
        if len(live_faces) != 1:
            raise FaceError("Kadrda aynan bitta yuz bo'lishi kerak")
        if live_faces[0].get("is_real") is not True:
            raise FaceError("Jonli yuz tasdiqlanmadi. Ekrandagi suratdan emas, kameraga bevosita qarab selfi oling")
        anti_score = float(live_faces[0].get("antispoof_score", 0.0))

    try:
        reps = DeepFace.represent(
            img_path=face_img,
            model_name=settings.face_model,
            detector_backend=detector,
            enforce_detection=True,
            align=True,
            normalization="base",
            max_faces=1,
        )
    except Exception as exc:
        raise FaceError(f"Yuz embeddingini yaratib bo'lmadi: {exc}") from exc
    if len(reps) != 1:
        raise FaceError("Yuz embeddingi yagona bo'lishi kerak")
    return [float(v) for v in reps[0]["embedding"]], anti_score


def cosine_distance(a: list[float], b: list[float]) -> float:
    av = np.asarray(a, dtype=np.float32)
    bv = np.asarray(b, dtype=np.float32)
    denom = float(np.linalg.norm(av) * np.linalg.norm(bv))
    if denom == 0:
        return 1.0
    return float(1.0 - np.dot(av, bv) / denom)


def verify_embedding(reference: list[float], probe: list[float]) -> tuple[bool, float, float]:
    distance = cosine_distance(reference, probe)
    threshold = float(settings.face_threshold)
    return distance <= threshold, distance, threshold

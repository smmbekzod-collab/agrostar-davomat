from collections import defaultdict
from io import BytesIO
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from openpyxl import Workbook
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Attendance, Organization, Employee


def _utc_month_bounds(year: int, month: int, tz: ZoneInfo) -> tuple[datetime, datetime]:
    start_local = datetime(year, month, 1, tzinfo=tz)
    if month == 12:
        end_local = datetime(year + 1, 1, 1, tzinfo=tz)
    else:
        end_local = datetime(year, month + 1, 1, tzinfo=tz)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc)


def _registration_label(employee: Employee) -> str:
    return "Belgilangan hududda emas" if employee.registration_outside_area else "Belgilangan hududda"


def monthly_xlsx(db: Session, organization_id: int, year: int, month: int) -> bytes:
    org = db.get(Organization, organization_id)
    if not org:
        raise ValueError("Tashkilot topilmadi")
    try:
        tz = ZoneInfo(org.timezone or "Asia/Tashkent")
    except Exception:
        tz = ZoneInfo("Asia/Tashkent")
    start_utc, end_utc = _utc_month_bounds(year, month, tz)

    rows = db.scalars(
        select(Attendance)
        .where(Attendance.organization_id == organization_id)
        .where(Attendance.occurred_at >= start_utc)
        .where(Attendance.occurred_at < end_utc)
        .order_by(Attendance.occurred_at.asc())
    ).all()
    employees = db.scalars(
        select(Employee)
        .where(Employee.organization_id == organization_id)
        .order_by(Employee.full_name.asc())
    ).all()

    wb = Workbook()
    ws = wb.active
    ws.title = "Davomat"
    ws.append([
        "ID", "Xodim kodi", "Xodim", "Ro'yxatdan o'tish hududi", "Ro'yxat izohi",
        "Turi", f"Vaqt ({org.timezone})", "UTC vaqt", "Status", "Daqiqa",
        "Latitude", "Longitude", "Aniqlik(m)", "Mock GPS", "Face distance",
        "Threshold", "Anti-spoof score", "Google Maps",
    ])

    summary = defaultdict(lambda: {
        "name": "", "code": "", "checkin_days": set(), "checkouts": 0,
        "late_days": 0, "late_minutes": 0, "early_leave_days": 0, "early_leave_minutes": 0,
        "registration_outside_area": False, "registration_area_note": "",
    })

    for r in rows:
        emp = r.employee
        key = r.employee_id
        s = summary[key]
        s["name"] = emp.full_name if emp else str(r.employee_id)
        s["code"] = emp.employee_code if emp else ""
        if emp:
            s["registration_outside_area"] = emp.registration_outside_area
            s["registration_area_note"] = emp.registration_area_note or ""
        local_at = r.occurred_at.astimezone(tz)
        if r.event_type == "checkin":
            s["checkin_days"].add(local_at.date())
            if r.schedule_status == "late":
                s["late_days"] += 1
                s["late_minutes"] += r.minutes_delta or 0
        else:
            s["checkouts"] += 1
            if r.schedule_status == "early_leave":
                s["early_leave_days"] += 1
                s["early_leave_minutes"] += r.minutes_delta or 0

        ws.append([
            r.id,
            emp.employee_code if emp else "",
            emp.full_name if emp else r.employee_id,
            _registration_label(emp) if emp else "",
            (emp.registration_area_note or "") if emp else "",
            r.event_type,
            local_at.strftime("%d.%m.%Y %H:%M:%S"),
            r.occurred_at.astimezone(timezone.utc).isoformat(),
            r.schedule_status,
            r.minutes_delta,
            r.latitude,
            r.longitude,
            r.accuracy_m,
            "HA" if r.is_mocked else "YO'Q",
            r.face_distance,
            r.face_threshold,
            r.anti_spoof_score,
            f"https://maps.google.com/?q={r.latitude},{r.longitude}",
        ])

    sum_ws = wb.create_sheet("Xodimlar xulosasi")
    sum_ws.append([
        "Xodim kodi", "F.I.O.", "Ro'yxatdan o'tish hududi", "Ro'yxat izohi",
        "Ishga kelgan kunlar", "Kechikkan kunlar", "Jami kechikish (daq)",
        "Ketish yozuvlari", "Erta ketgan kunlar", "Jami erta ketish (daq)",
    ])
    for _, s in sorted(summary.items(), key=lambda item: item[1]["name"]):
        sum_ws.append([
            s["code"], s["name"],
            "Belgilangan hududda emas" if s["registration_outside_area"] else "Belgilangan hududda",
            s["registration_area_note"],
            len(s["checkin_days"]), s["late_days"], s["late_minutes"], s["checkouts"],
            s["early_leave_days"], s["early_leave_minutes"],
        ])

    roster_ws = wb.create_sheet("Xodimlar ro'yxati")
    roster_ws.append([
        "Xodim kodi", "F.I.O.", "Holati", "Tasdiqlangan", "Ro'yxatdan o'tgan vaqt",
        "Ro'yxatdan o'tish hududi", "Hududdan tashqari sabab / izoh",
    ])
    for employee in employees:
        created_local = employee.created_at.astimezone(tz) if employee.created_at.tzinfo else employee.created_at.replace(tzinfo=timezone.utc).astimezone(tz)
        roster_ws.append([
            employee.employee_code,
            employee.full_name,
            "Faol" if employee.is_active else "Faolsiz",
            "HA" if employee.is_approved else "YO'Q",
            created_local.strftime("%d.%m.%Y %H:%M:%S"),
            _registration_label(employee),
            employee.registration_area_note or "",
        ])

    info_ws = wb.create_sheet("Hisobot sozlamalari")
    info_ws.append(["Tashkilot", org.name])
    info_ws.append(["Davr", f"{year}-{month:02d}"])
    info_ws.append(["Timezone", org.timezone])
    info_ws.append(["Ish boshlanishi", org.work_start])
    info_ws.append(["Ish tugashi", org.work_end])
    info_ws.append(["Kechikish grace (daq)", org.grace_minutes])
    info_ws.append(["Davomat GPS rejimi", "Istalgan joydan; koordinata faqat qayd etiladi"])
    info_ws.append(["Ro'yxatdan o'tish hududi", "Xodim o'zi belgilaydi: hududda / hududda emas. Hududda emas bo'lsa izoh majburiy."])

    for sheet in (ws, sum_ws, roster_ws, info_ws):
        for col in sheet.columns:
            sheet.column_dimensions[col[0].column_letter].width = min(
                max(len(str(c.value or "")) for c in col) + 2, 54
            )
        sheet.freeze_panes = "A2"

    out = BytesIO()
    wb.save(out)
    return out.getvalue()

import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import '../models/models.dart';
import 'config.dart';
import 'session_store.dart';

class ApiClient {
  final Dio dio=Dio(BaseOptions(baseUrl:AppConfig.apiBaseUrl,connectTimeout:const Duration(seconds:20),receiveTimeout:const Duration(seconds:60)));
  final SessionStore session; ApiClient(this.session);
  String msg(Object e){
    if(e is DioException){
      final d=e.response?.data;
      if(d is Map&&d['detail']!=null){
        final detail=d['detail'];
        if(detail is List&&detail.isNotEmpty){
          final first=detail.first;
          if(first is Map){
            final loc=first['loc'];
            final field=(loc is List&&loc.isNotEmpty)?loc.last.toString():'';
            final type=first['type']?.toString()??'';
            final ctx=first['ctx'];
            final min=(ctx is Map)?ctx['min_length']:null;
            const names={'code':'Tashkilot kodi','name':'Tashkilot nomi','work_start':'Ish boshlanish vaqti','work_end':'Ish tugash vaqti','grace_minutes':'Grace daqiqasi'};
            if(type=='string_too_short')return '${names[field]??field} kamida ${min??2} ta belgidan iborat bo‘lishi kerak.';
            return first['msg']?.toString()??'Kiritilgan ma’lumot noto‘g‘ri.';
          }
        }
        return detail.toString();
      }
      return e.message??'Server xatosi';
    }
    return e.toString();
  }
  Future<Options> opts()async=>Options(headers:{'Authorization':'Bearer ${await session.accessToken()}'});
  Future<void> login(String u,String p)async{try{final r=await dio.post('/admin-auth/login',data:{'username':u,'password':p});await session.save(r.data['access_token'],r.data['refresh_token']);}catch(e){throw Exception(msg(e));}}
  Future<void> registerRequest(String fullName,String username,String password,int orgId)async{try{await dio.post('/admin-auth/register-request',data:{'full_name':fullName,'username':username,'password':password,'organization_id':orgId});}catch(e){throw Exception(msg(e));}}
  Future<bool> refresh()async{final t=await session.refreshToken();if(t==null)return false;try{final r=await dio.post('/admin-auth/refresh',data:{'refresh_token':t});await session.save(r.data['access_token'],r.data['refresh_token']);return true;}catch(_){await session.clear();return false;}}
  Future<Response> _req(String method,String path,{dynamic data,Map<String,dynamic>? query})async{try{return await dio.request(path,data:data,queryParameters:query,options:(await opts()).copyWith(method:method));}on DioException catch(e){if(e.response?.statusCode==401&&await refresh())return dio.request(path,data:data,queryParameters:query,options:(await opts()).copyWith(method:method));throw Exception(msg(e));}}
  Future<Map<String,dynamic>> me()async=>Map<String,dynamic>.from((await _req('GET','/admin/me')).data);
  Future<Map<String,dynamic>> dashboard()async=>Map<String,dynamic>.from((await _req('GET','/admin/dashboard')).data);
  Future<List<Map<String,dynamic>>> todayStatus()async{final r=await _req('GET','/admin/today-status');return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}
  Future<Map<String,dynamic>> permissionCatalog()async=>Map<String,dynamic>.from((await _req('GET','/admin/permissions')).data);
  Future<void> changeOwnPassword(String current,String next)async=>_req('POST','/admin/change-password',data:{'current_password':current,'new_password':next});
  Future<List<Organization>> publicOrganizations()async{final r=await dio.get('/public/organizations');return(r.data as List).map((e)=>Organization.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<List<Organization>> organizations()async{final r=await _req('GET','/admin/organizations');return(r.data as List).map((e)=>Organization.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<void> createOrganization(String name,String code,bool autoApprove,{String timezone='Asia/Tashkent',String workStart='09:00',String workEnd='18:00',int graceMinutes=10})async=>_req('POST','/admin/organizations',data:{'name':name,'code':code,'location_mode':'anywhere','employee_auto_approve':autoApprove,'timezone':timezone,'work_start':workStart,'work_end':workEnd,'grace_minutes':graceMinutes});
  Future<void> updateOrganization(int id,Map<String,dynamic> data)async=>_req('PATCH','/admin/organizations/$id',data:data);
  Future<void> deactivateOrganization(int id)async=>_req('DELETE','/admin/organizations/$id');
  Future<List<AdminAccount>> admins()async{final r=await _req('GET','/admin/admins');return(r.data as List).map((e)=>AdminAccount.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<void> createAdmin(Map<String,dynamic> data)async=>_req('POST','/admin/admins',data:data);
  Future<void> updateAdmin(int id,Map<String,dynamic> data)async=>_req('PATCH','/admin/admins/$id',data:data);
  Future<void> approveAdmin(int id)async=>_req('POST','/admin/admins/$id/approve');
  Future<void> resetAdminPassword(int id,String p)async=>_req('POST','/admin/admins/$id/reset-password',data:{'new_password':p});
  Future<void> deactivateAdmin(int id)async=>_req('DELETE','/admin/admins/$id');
  Future<List<EmployeeItem>> employees({int? orgId})async{final r=await _req('GET','/admin/employees',query:orgId==null?null:{'organization_id':orgId});return(r.data as List).map((e)=>EmployeeItem.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<void> approveEmployee(int id)async=>_req('POST','/admin/employees/$id/approve');
  Future<void> resetEmployeeDevice(int id)async=>_req('POST','/admin/employees/$id/reset-device');
  Future<void> deactivateEmployee(int id)async=>_req('DELETE','/admin/employees/$id');
  Future<List<AttendanceItem>> attendance({int? orgId})async{final r=await _req('GET','/admin/attendance',query:orgId==null?null:{'organization_id':orgId,'limit':500});return(r.data as List).map((e)=>AttendanceItem.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<File> monthlyReport(int orgId,int year,int month)async{final dir=await getTemporaryDirectory();final f=File('${dir.path}/davomat_${orgId}_${year}_${month.toString().padLeft(2,'0')}.xlsx');try{Response r;try{r=await dio.get('/admin/reports/monthly.xlsx',queryParameters:{'organization_id':orgId,'year':year,'month':month},options:(await opts()).copyWith(responseType:ResponseType.bytes));}on DioException catch(e){if(e.response?.statusCode==401&&await refresh()){r=await dio.get('/admin/reports/monthly.xlsx',queryParameters:{'organization_id':orgId,'year':year,'month':month},options:(await opts()).copyWith(responseType:ResponseType.bytes));}else{rethrow;}}await f.writeAsBytes(List<int>.from(r.data));return f;}catch(e){throw Exception(msg(e));}}
  Future<List<Map<String,dynamic>>> audit()async{final r=await _req('GET','/admin/audit');return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}
}

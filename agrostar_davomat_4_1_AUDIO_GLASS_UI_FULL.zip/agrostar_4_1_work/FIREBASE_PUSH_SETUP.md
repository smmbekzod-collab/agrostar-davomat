# Firebase / Push setup

Kodda backend push provider va device-token API mavjud, lekin maxfiy Firebase credential ZIPga kiritilmaydi.

1. Firebase project yarating va Android package'larni ro‘yxatdan o‘tkazing.
2. Hodim/Admin app uchun `google-services.json` va iOS uchun `GoogleService-Info.plist` oling.
3. FlutterFire (`firebase_core`, `firebase_messaging`) client bootstrapni provider fayllari bilan ulang.
4. Device FCM tokenini `/api/v1/work/push-token` yoki `/api/v1/admin/work/push-token` ga yuboring.
5. Railway: `PUSH_ENABLED=true` va `FIREBASE_CREDENTIALS_JSON` o‘rnating.
6. Android’da `default` va `urgent` notification channel yarating. Urgent channel high importance bo‘lsin; DND bypass uchun user/system ruxsati talab etiladi.
7. iOS’da APNs capability yoqing. Critical Alerts kerak bo‘lsa Apple entitlement alohida olinadi.

Backend credentials bo‘lmasa notificationlar `notification_logs` jadvalida `provider_not_configured` sifatida qoladi; tasklar va qolgan modul normal ishlayveradi.

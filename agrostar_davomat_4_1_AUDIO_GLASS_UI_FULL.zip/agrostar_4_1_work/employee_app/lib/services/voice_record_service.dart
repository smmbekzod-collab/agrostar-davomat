import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class VoiceRecordService{
  final AudioRecorder _rec=AudioRecorder();
  bool recording=false;
  Future<void> start()async{if(!await _rec.hasPermission())throw Exception('Mikrofon ruxsati berilmadi');final d=await getTemporaryDirectory();final p='${d.path}/hisobot_${DateTime.now().millisecondsSinceEpoch}.m4a';await _rec.start(const RecordConfig(encoder:AudioEncoder.aacLc,bitRate:96000,sampleRate:44100),path:p);recording=true;}
  Future<File?> stop()async{final p=await _rec.stop();recording=false;return p==null?null:File(p);}
  Future<void> dispose()=>_rec.dispose();
}

import 'dart:async';
import 'dart:io';
import 'package:geolocator/geolocator.dart';
import '../core/api_client.dart';

class WorkLocationService {
  StreamSubscription<Position>? _sub;
  bool _started = false;

  Future<void> start(ApiClient api, Map<String, dynamic> cfg) async {
    if (_started || cfg['location_tracking_enabled'] != true) return;
    if (!await Geolocator.isLocationServiceEnabled()) return;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;

    final interval = Duration(minutes: (cfg['location_interval_minutes'] as num?)?.toInt() ?? 15);
    final distance = (cfg['location_distance_m'] as num?)?.toInt() ?? 100;
    final LocationSettings settings;
    if (Platform.isAndroid) {
      settings = AndroidSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distance,
        intervalDuration: interval,
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: 'AgroStar ish vaqti lokatsiyasi',
          notificationText: 'Ish vaqtida lokatsiya tejamkor intervalda qayd etilmoqda',
          enableWakeLock: false,
        ),
      );
    } else {
      settings = AppleSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distance,
        activityType: ActivityType.other,
        pauseLocationUpdatesAutomatically: true,
        showBackgroundLocationIndicator: false,
      );
    }
    _started = true;
    _sub = Geolocator.getPositionStream(locationSettings: settings).listen((p) async {
      try {
        await api.sendLocations([
          {
            'latitude': p.latitude,
            'longitude': p.longitude,
            'accuracy_m': p.accuracy,
            'is_mocked': p.isMocked,
            'captured_at': DateTime.now().toUtc().toIso8601String(),
          }
        ]);
      } catch (_) {}
    });
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    _started = false;
  }
}

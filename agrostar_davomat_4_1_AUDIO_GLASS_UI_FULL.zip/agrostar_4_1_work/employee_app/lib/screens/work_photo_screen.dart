import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class WorkPhotoScreen extends StatefulWidget{const WorkPhotoScreen({super.key});@override State<WorkPhotoScreen> createState()=>_WorkPhotoScreenState();}
class _WorkPhotoScreenState extends State<WorkPhotoScreen>{CameraController? c;bool loading=true,taking=false;String? error;
@override void initState(){super.initState();init();}
Future<void> init()async{try{final cams=await availableCameras();if(cams.isEmpty)throw Exception('Kamera topilmadi');final cam=cams.firstWhere((x)=>x.lensDirection==CameraLensDirection.back,orElse:()=>cams.first);final cc=CameraController(cam,ResolutionPreset.high,enableAudio:false,imageFormatGroup:ImageFormatGroup.jpeg);await cc.initialize();await cc.setFlashMode(FlashMode.auto);c=cc;}catch(e){error='$e';}if(mounted)setState(()=>loading=false);}
Future<void> take()async{if(c==null||taking)return;setState(()=>taking=true);try{final x=await c!.takePicture();if(mounted)Navigator.pop(context,File(x.path));}catch(e){setState(()=>error='$e');}finally{if(mounted)setState(()=>taking=false);}}
@override void dispose(){c?.dispose();super.dispose();}
@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Hisobot uchun foto')),body:loading?const Center(child:CircularProgressIndicator()):error!=null?Center(child:Text(error!)):Column(children:[Expanded(child:Center(child:AspectRatio(aspectRatio:c!.value.aspectRatio,child:CameraPreview(c!)))),Padding(padding:const EdgeInsets.all(18),child:FilledButton.icon(onPressed:taking?null:take,icon:const Icon(Icons.camera_alt),label:const Text('RASM OLISH')))]));}

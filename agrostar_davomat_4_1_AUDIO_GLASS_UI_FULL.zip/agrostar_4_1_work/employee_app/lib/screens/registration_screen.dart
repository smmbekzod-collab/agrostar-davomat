import 'dart:io';
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import 'selfie_camera_screen.dart';

enum EntryMode { register, login }

class RegistrationScreen extends StatefulWidget {
  final ApiClient api;
  final VoidCallback onDone;
  final String? startupWarning;
  const RegistrationScreen({super.key, required this.api, required this.onDone, this.startupWarning});
  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  static const currentVersion = '4.1.0';
  final name = TextEditingController();
  final areaNote = TextEditingController();
  List<Organization> orgs = [];
  MobileConfig mobileConfig = const MobileConfig();
  int? orgId;
  File? selfie;
  bool loading = true;
  bool submitting = false;
  bool outsideArea = false;
  bool useNameFallback = false;
  EntryMode mode = EntryMode.register;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    name.dispose();
    areaNote.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        widget.api.organizations(),
        widget.api.mobileConfig(),
      ]);
      orgs = results[0] as List<Organization>;
      mobileConfig = results[1] as MobileConfig;
      if (orgs.isNotEmpty) orgId = orgs.first.id;
      if (!mobileConfig.allowNewEmployeeRegistration) {
        mode = EntryMode.login;
      }
    } catch (e) {
      if (mounted) _snack('$e');
    }
    if (mounted) setState(() => loading = false);
  }


  int _cmpVersion(String a,String b){
    List<int> p(String x)=>x.split('.').map((e)=>int.tryParse(RegExp(r'^\d+').stringMatch(e)??'0')??0).toList();
    final aa=p(a),bb=p(b); for(var i=0;i<3;i++){final av=i<aa.length?aa[i]:0,bv=i<bb.length?bb[i]:0;if(av!=bv)return av.compareTo(bv);}return 0;
  }
  bool get forcedUpdate => _cmpVersion(currentVersion,mobileConfig.employeeMinVersion)<0;
  bool get updateAvailable => _cmpVersion(currentVersion,mobileConfig.employeeLatestVersion)<0;

  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(s.replaceFirst('Exception: ', ''))),
      );

  void _setMode(EntryMode next) {
    if (next == EntryMode.register && !mobileConfig.allowNewEmployeeRegistration) {
      _snack('Yangi xodim ro‘yxatdan o‘tishi vaqtincha o‘chirilgan');
      return;
    }
    setState(() {
      mode = next;
      selfie = null;
      useNameFallback = false;
      if (mode == EntryMode.login) {
        outsideArea = false;
        areaNote.clear();
        if (mobileConfig.employeeReloginMode == 'name_and_face') {
          useNameFallback = true;
        }
      }
    });
  }

  Future<void> _selfie() async {
    final f = await Navigator.push<File>(
      context,
      MaterialPageRoute(
        builder: (_) => SelfieCameraScreen(
          title: mode == EntryMode.login
              ? 'Kirish uchun jonli selfi'
              : 'Ro‘yxatdan o‘tish selfisi',
        ),
      ),
    );
    if (f != null) setState(() => selfie = f);
  }

  Future<void> _submit() async {
    final isLogin = mode == EntryMode.login;
    final nameRequired = !isLogin || !mobileConfig.faceOnlyLogin || useNameFallback;

    if (orgId == null || selfie == null) {
      _snack('Tashkilot va jonli selfi talab qilinadi');
      return;
    }
    if (nameRequired && name.text.trim().length < 3) {
      _snack('F.I.O. ni to‘liq kiriting');
      return;
    }
    if (!isLogin && outsideArea && areaNote.text.trim().length < 3) {
      _snack('Belgilangan hududda emas bo‘lsangiz, sababini yozing');
      return;
    }
    if (forcedUpdate) { _snack(mobileConfig.updateMessage.isEmpty ? 'Ilovani yangilang' : mobileConfig.updateMessage); return; }
    if (mobileConfig.maintenanceEnabled) {
      _snack(mobileConfig.maintenanceMessage.isEmpty
          ? 'Tizimda vaqtinchalik texnik ishlar ketmoqda'
          : mobileConfig.maintenanceMessage);
      return;
    }

    setState(() => submitting = true);
    try {
      if (isLogin) {
        await widget.api.loginFace(
          fullName: nameRequired ? name.text.trim() : null,
          organizationId: orgId!,
          selfie: selfie!,
        );
      } else {
        await widget.api.register(
          fullName: name.text.trim(),
          organizationId: orgId!,
          selfie: selfie!,
          registrationOutsideArea: outsideArea,
          registrationAreaNote: outsideArea ? areaNote.text.trim() : '',
        );
      }
      widget.onDone();
    } catch (e) {
      final message = '$e'.replaceFirst('Exception: ', '');
      if (isLogin &&
          mobileConfig.employeeNameFallbackEnabled &&
          !useNameFallback &&
          message.toLowerCase().contains('aniq')) {
        setState(() => useNameFallback = true);
        _snack('$message F.I.O. bilan aniqlashtirish maydoni ochildi.');
      } else {
        _snack(message);
      }
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLogin = mode == EntryMode.login;
    final showName = !isLogin || !mobileConfig.faceOnlyLogin || useNameFallback;
    final segments = <ButtonSegment<EntryMode>>[
      if (mobileConfig.allowNewEmployeeRegistration)
        const ButtonSegment(
          value: EntryMode.register,
          icon: Icon(Icons.person_add_alt_1),
          label: Text('Yangi ro‘yxat'),
        ),
      const ButtonSegment(
        value: EntryMode.login,
        icon: Icon(Icons.face_retouching_natural),
        label: Text('Oldin ro‘yxatdan o‘tganman'),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Agro Star Hodim')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Xodim kabineti',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                if (widget.startupWarning != null && widget.startupWarning!.isNotEmpty) ...[
                  Card(
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(widget.startupWarning!),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
                if (segments.length > 1)
                  SegmentedButton<EntryMode>(
                    segments: segments,
                    selected: {mode},
                    onSelectionChanged: (v) => _setMode(v.first),
                    showSelectedIcon: false,
                  ),
                if (mobileConfig.bannerEnabled && mobileConfig.bannerMessage.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(mobileConfig.bannerMessage))),
                ],
                if (forcedUpdate || updateAvailable) ...[
                  const SizedBox(height: 12),
                  Card(color: forcedUpdate ? Theme.of(context).colorScheme.errorContainer : null, child: Padding(padding: const EdgeInsets.all(14), child: Text('${mobileConfig.updateMessage.isEmpty ? 'Yangi versiya mavjud.' : mobileConfig.updateMessage}\nJoriy: $currentVersion • Oxirgi: ${mobileConfig.employeeLatestVersion}${forcedUpdate ? '\nYangilash majburiy.' : ''}'))),
                ],
                if (mobileConfig.maintenanceEnabled) ...[
                  const SizedBox(height: 12),
                  Card(
                    color: Theme.of(context).colorScheme.errorContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text(
                        mobileConfig.maintenanceMessage.isEmpty
                            ? 'Tizimda vaqtinchalik texnik ishlar ketmoqda.'
                            : mobileConfig.maintenanceMessage,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(
                      isLogin
                          ? mobileConfig.reloginHelpText
                          : 'Birinchi marta foydalanayotgan xodim shu yerda ro‘yxatdan o‘tadi. Davomatni keyin istalgan tumandan qilishingiz mumkin.',
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                if (showName) ...[
                  TextField(
                    controller: name,
                    decoration: InputDecoration(
                      labelText: isLogin ? 'F.I.O. — aniqlashtirish uchun' : 'F.I.O.',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                ],
                DropdownButtonFormField<int>(
                  initialValue: orgId,
                  decoration: const InputDecoration(
                    labelText: 'Tashkilot',
                    border: OutlineInputBorder(),
                  ),
                  items: orgs
                      .map((o) => DropdownMenuItem(value: o.id, child: Text(o.name)))
                      .toList(),
                  onChanged: (v) => setState(() => orgId = v),
                ),
                const SizedBox(height: 14),
                if (!isLogin && mobileConfig.employeeRegistrationAreaToggle) ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(
                        children: [
                          CheckboxListTile(
                            value: outsideArea,
                            onChanged: (v) => setState(() {
                              outsideArea = v ?? false;
                              if (!outsideArea) areaNote.clear();
                            }),
                            title: const Text('Belgilangan hududda emasman'),
                            subtitle: const Text(
                              'Hududda bo‘lsangiz belgini qo‘ymang. Hududda emas bo‘lsangiz belgilang va sabab yozing.',
                            ),
                            controlAffinity: ListTileControlAffinity.leading,
                          ),
                          if (outsideArea)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                              child: TextField(
                                controller: areaNote,
                                minLines: 2,
                                maxLines: 4,
                                decoration: const InputDecoration(
                                  labelText: 'Sababi / izoh *',
                                  hintText: 'Masalan: xizmat safari, boshqa tumandagi obyekt...',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                OutlinedButton.icon(
                  onPressed: _selfie,
                  icon: const Icon(Icons.face),
                  label: Text(
                    selfie == null
                        ? (isLogin ? 'Jonli selfi orqali kirish' : 'Old kamera bilan selfi olish')
                        : 'Selfi olindi — qayta olish',
                  ),
                ),
                if (isLogin &&
                    mobileConfig.faceOnlyLogin &&
                    mobileConfig.employeeNameFallbackEnabled) ...[
                  const SizedBox(height: 6),
                  TextButton.icon(
                    onPressed: () => setState(() => useNameFallback = !useNameFallback),
                    icon: Icon(useNameFallback ? Icons.close : Icons.edit),
                    label: Text(useNameFallback
                        ? 'F.I.O. maydonini yopish'
                        : 'Yuzdan topilmasa F.I.O. bilan aniqlashtirish'),
                  ),
                ],
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: submitting || mobileConfig.maintenanceEnabled || forcedUpdate ? null : _submit,
                  icon: Icon(isLogin ? Icons.face_retouching_natural : Icons.person_add),
                  label: Text(
                    submitting
                        ? 'Tekshirilmoqda...'
                        : (isLogin ? 'SELFIDAN ANIQLAB KIRISH' : 'RO‘YXATDAN O‘TISH'),
                  ),
                ),
              ],
            ),
    );
  }
}

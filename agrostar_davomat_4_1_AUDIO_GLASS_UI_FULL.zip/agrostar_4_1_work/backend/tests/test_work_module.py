from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from app.db.session import Base
from app.models.entities import Organization, AdminUser, Employee, WorkTask, Idea, BonusAward
from app.services.permissions import effective_permissions


def test_work_tables_create():
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    assert 'work_tasks' in Base.metadata.tables
    assert 'work_reports' in Base.metadata.tables
    assert 'ideas' in Base.metadata.tables
    assert 'employee_locations' in Base.metadata.tables


def test_manager_permissions_include_work():
    perms = effective_permissions('org_admin', [])
    assert 'work.manage' in perms
    assert 'work.review' in perms
    assert 'bonus.manage' in perms

from functools import lru_cache
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Dual Face Attendance API"
    env: str = "production"
    api_v1_prefix: str = "/api/v1"
    database_url: str = "sqlite:///./attendance.db"
    secret_key: str = "dev-only-change-me"
    biometric_key: str = ""
    access_token_minutes: int = 30
    refresh_token_days: int = 30
    superadmin_username: str = "superadmin"
    superadmin_password: str = "ChangeMe123!"
    superadmin_full_name: str = "Super Admin"
    cors_origins: List[str] = []
    face_model: str = "Facenet512"
    face_detector: str = "retinaface"
    face_distance_metric: str = "cosine"
    face_threshold: float = 0.30
    max_upload_bytes: int = 8_000_000
    firebase_credentials_json: str = ""
    push_enabled: bool = False
    work_scheduler_enabled: bool = True

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

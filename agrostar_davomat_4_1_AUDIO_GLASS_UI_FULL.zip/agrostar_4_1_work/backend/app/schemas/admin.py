from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pydantic import BaseModel, Field, field_validator
from app.services.permissions import ALL_PERMISSIONS
from app.models.entities import DEFAULT_REPORT_COLUMNS

AdminRoleName = Literal["super_admin", "org_admin", "hr_manager", "auditor"]
ReasonMode = Literal["off", "optional", "required"]
AntiSpoofPolicy = Literal["required", "soft", "registration_only"]
EmployeeStatus = Literal["active", "leave", "business_trip", "sick", "terminated", "archived"]
ReviewStatus = Literal["approved", "pending_review", "rejected"]


def _valid_hhmm(value: str) -> str:
    value = value.strip()
    parts = value.split(":")
    if len(parts) != 2:
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak")
    try:
        hour, minute = int(parts[0]), int(parts[1])
    except ValueError as exc:
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak") from exc
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak")
    return f"{hour:02d}:{minute:02d}"


def _valid_timezone(value: str) -> str:
    value = value.strip()
    try:
        ZoneInfo(value)
    except ZoneInfoNotFoundError as exc:
        raise ValueError("Timezone noto'g'ri") from exc
    return value


def _valid_permissions(values: list[str]) -> list[str]:
    unknown = sorted(set(values) - set(ALL_PERMISSIONS))
    if unknown:
        raise ValueError(f"Noma'lum permission: {', '.join(unknown)}")
    return sorted(set(values))


def _valid_report_columns(values: list[str]) -> list[str]:
    allowed = set(DEFAULT_REPORT_COLUMNS)
    unknown = sorted(set(values) - allowed)
    if unknown:
        raise ValueError(f"Noma'lum hisobot ustuni: {', '.join(unknown)}")
    return list(dict.fromkeys(values))


class AdminLogin(BaseModel):
    username: str
    password: str


class AdminRegisterRequest(BaseModel):
    full_name: str = Field(min_length=3, max_length=200)
    username: str = Field(min_length=4, max_length=100)
    password: str = Field(min_length=8, max_length=128)
    organization_id: int


class OrganizationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    code: str = Field(min_length=2, max_length=50)
    location_mode: Literal["anywhere"] = "anywhere"
    employee_auto_approve: bool = True
    timezone: str = "Asia/Tashkent"
    work_start: str = "09:00"
    work_end: str = "18:00"
    grace_minutes: int = Field(default=10, ge=0, le=180)
    late_monitoring_enabled: bool = True
    early_leave_monitoring_enabled: bool = True
    late_reason_mode: ReasonMode = "optional"
    early_leave_reason_mode: ReasonMode = "optional"
    face_threshold_override: float | None = Field(default=None, ge=0.05, le=1.0)
    anti_spoof_policy: AntiSpoofPolicy = "required"
    selfie_retention_days: int = Field(default=90, ge=0, le=3650)
    suspicious_accuracy_m: float = Field(default=80.0, ge=5, le=5000)
    suspicious_face_margin: float = Field(default=0.03, ge=0, le=0.25)
    unusual_distance_km: float = Field(default=50.0, ge=1, le=5000)
    report_columns: list[str] = Field(default_factory=lambda: list(DEFAULT_REPORT_COLUMNS))
    custom_rules: dict = Field(default_factory=dict)

    _timezone = field_validator("timezone")(_valid_timezone)
    _work_start = field_validator("work_start")(_valid_hhmm)
    _work_end = field_validator("work_end")(_valid_hhmm)
    _report_columns = field_validator("report_columns")(_valid_report_columns)


class OrganizationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=200)
    code: str | None = Field(default=None, min_length=2, max_length=50)
    is_active: bool | None = None
    location_mode: Literal["anywhere"] | None = None
    employee_auto_approve: bool | None = None
    timezone: str | None = None
    work_start: str | None = None
    work_end: str | None = None
    grace_minutes: int | None = Field(default=None, ge=0, le=180)
    late_monitoring_enabled: bool | None = None
    early_leave_monitoring_enabled: bool | None = None
    late_reason_mode: ReasonMode | None = None
    early_leave_reason_mode: ReasonMode | None = None
    face_threshold_override: float | None = Field(default=None, ge=0.05, le=1.0)
    anti_spoof_policy: AntiSpoofPolicy | None = None
    selfie_retention_days: int | None = Field(default=None, ge=0, le=3650)
    suspicious_accuracy_m: float | None = Field(default=None, ge=5, le=5000)
    suspicious_face_margin: float | None = Field(default=None, ge=0, le=0.25)
    unusual_distance_km: float | None = Field(default=None, ge=1, le=5000)
    report_columns: list[str] | None = None
    custom_rules: dict | None = None

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, value: str | None) -> str | None:
        return None if value is None else _valid_timezone(value)

    @field_validator("work_start", "work_end")
    @classmethod
    def validate_time(cls, value: str | None) -> str | None:
        return None if value is None else _valid_hhmm(value)

    @field_validator("report_columns")
    @classmethod
    def validate_report_columns(cls, value: list[str] | None) -> list[str] | None:
        return None if value is None else _valid_report_columns(value)


class AdminCreate(BaseModel):
    full_name: str = Field(min_length=3, max_length=200)
    username: str = Field(min_length=4, max_length=100)
    password: str = Field(min_length=8, max_length=128)
    role: AdminRoleName = "org_admin"
    permissions: list[str] = Field(default_factory=list)
    organization_ids: list[int] = Field(default_factory=list)
    is_approved: bool = True

    _permissions = field_validator("permissions")(_valid_permissions)


class AdminUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=3, max_length=200)
    role: AdminRoleName | None = None
    permissions: list[str] | None = None
    organization_ids: list[int] | None = None
    is_active: bool | None = None
    is_approved: bool | None = None
    force_password_change: bool | None = None

    @field_validator("permissions")
    @classmethod
    def validate_permissions(cls, value: list[str] | None) -> list[str] | None:
        return None if value is None else _valid_permissions(value)


class ResetPassword(BaseModel):
    new_password: str = Field(min_length=8, max_length=128)


class EmployeeUpdate(BaseModel):
    job_title: str | None = Field(default=None, max_length=160)
    full_name: str | None = Field(default=None, min_length=3, max_length=200)
    organization_id: int | None = None
    is_active: bool | None = None
    is_approved: bool | None = None
    employment_status: EmployeeStatus | None = None
    status_note: str | None = Field(default=None, max_length=1000)
    status_until: str | None = None


class ChangeOwnPassword(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class MobileConfigUpdate(BaseModel):
    employee_relogin_mode: Literal["face_only", "name_and_face"] | None = None
    employee_name_fallback_enabled: bool | None = None
    employee_registration_area_toggle: bool | None = None
    allow_new_employee_registration: bool | None = None
    maintenance_enabled: bool | None = None
    maintenance_message: str | None = Field(default=None, max_length=500)
    relogin_help_text: str | None = Field(default=None, max_length=1000)
    employee_min_version: str | None = Field(default=None, max_length=30)
    employee_latest_version: str | None = Field(default=None, max_length=30)
    admin_min_version: str | None = Field(default=None, max_length=30)
    admin_latest_version: str | None = Field(default=None, max_length=30)
    update_message: str | None = Field(default=None, max_length=500)
    update_url: str | None = Field(default=None, max_length=500)
    banner_enabled: bool | None = None
    banner_message: str | None = Field(default=None, max_length=1000)
    message_texts: dict[str, str] | None = None


class SecurityConfigUpdate(BaseModel):
    max_failed_login_attempts: int | None = Field(default=None, ge=1, le=50)
    lockout_minutes: int | None = Field(default=None, ge=1, le=1440)
    password_expiry_days: int | None = Field(default=None, ge=0, le=3650)


class AttendanceNoteUpdate(BaseModel):
    admin_note: str = Field(default="", max_length=2000)


class AttendanceReviewUpdate(BaseModel):
    review_status: ReviewStatus
    admin_note: str | None = Field(default=None, max_length=2000)

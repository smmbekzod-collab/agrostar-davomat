from datetime import datetime
from pydantic import BaseModel, Field
from typing import Literal

class TaskCreate(BaseModel):
    organization_id: int
    title: str = Field(min_length=2,max_length=250)
    content: str = Field(default="",max_length=10000)
    task_type: Literal["short","long"] = "short"
    priority: Literal["normal","high","urgent"] = "normal"
    assigned_employee_id: int | None = None
    due_at: datetime | None = None
    expected_total: float | None = Field(default=None,ge=0)
    reminder_interval_minutes: int | None = Field(default=None,ge=5,le=10080)

class TaskUpdate(BaseModel):
    title: str | None = Field(default=None,min_length=2,max_length=250)
    content: str | None = Field(default=None,max_length=10000)
    status: Literal["assigned","in_progress","done","cancelled"] | None = None
    priority: Literal["normal","high","urgent"] | None = None
    assigned_employee_id: int | None = None
    due_at: datetime | None = None
    expected_total: float | None = Field(default=None,ge=0)
    reminder_interval_minutes: int | None = Field(default=None,ge=5,le=10080)

class ReportCreate(BaseModel):
    text: str = Field(default="",max_length=10000)
    progress_delta: float | None = None
    progress_total: float | None = None
    task_id: int | None = None
    business_trip_id: int | None = None

class IdeaCreate(BaseModel):
    title: str = Field(default="G‘oya",max_length=250)
    text: str = Field(default="",max_length=10000)

class BonusCreate(BaseModel):
    employee_id: int
    report_id: int | None = None
    task_id: int | None = None
    amount: float = Field(gt=0,le=1_000_000_000)
    emoji: str = Field(default="💵",max_length=20)
    note: str = Field(default="",max_length=2000)

class ReportReview(BaseModel):
    status: Literal["reviewed","accepted","rejected"] = "reviewed"
    manager_comment: str = Field(default="",max_length=3000)
    bonus_amount: float | None = Field(default=None,gt=0,le=1_000_000_000)
    bonus_emoji: str = Field(default="💵",max_length=20)

class TripCreate(BaseModel):
    organization_id: int
    employee_id: int
    title: str = Field(min_length=2,max_length=250)
    destination: str = Field(default="",max_length=250)
    purpose: str = Field(default="",max_length=5000)
    start_at: datetime
    end_at: datetime | None = None

class LocationPoint(BaseModel):
    latitude: float
    longitude: float
    accuracy_m: float | None = None
    is_mocked: bool = False
    captured_at: datetime | None = None

class LocationBatch(BaseModel):
    points: list[LocationPoint] = Field(min_length=1,max_length=100)

class PushTokenIn(BaseModel):
    token: str = Field(min_length=10,max_length=4096)
    platform: Literal["android","ios"] = "android"

class WorkConfigUpdate(BaseModel):
    short_task_reminder_minutes: int | None = Field(default=None,ge=5,le=10080)
    long_task_reminder_time: str | None = Field(default=None,pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    friday_quiet_enabled: bool | None = None
    friday_quiet_start: str | None = Field(default=None,pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    friday_quiet_end: str | None = Field(default=None,pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    working_hours_start: str | None = Field(default=None,pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    working_hours_end: str | None = Field(default=None,pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    location_tracking_enabled: bool | None = None
    location_interval_minutes: int | None = Field(default=None,ge=5,le=120)
    location_distance_m: int | None = Field(default=None,ge=20,le=5000)
    daily_idea_reminder_enabled: bool | None = None
    urgent_high_priority_push: bool | None = None
    task_module_enabled: bool | None = None
    idea_module_enabled: bool | None = None
    business_trip_module_enabled: bool | None = None
    bonus_module_enabled: bool | None = None

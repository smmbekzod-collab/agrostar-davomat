from __future__ import annotations
import random
from datetime import datetime, timezone, time
from zoneinfo import ZoneInfo
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import Response
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.api.deps import current_employee
from app.db.session import get_db
from app.models.entities import Employee, WorkTask, WorkReport, WorkAttachment, Idea, BonusAward, BusinessTrip, EmployeeLocation, PushDevice
from app.schemas.work import ReportCreate, IdeaCreate, LocationBatch, PushTokenIn
from app.services.work_config import get_work_config

router=APIRouter(prefix="/work",tags=["employee-work"])

def task_json(t:WorkTask)->dict:
    return {"id":t.id,"title":t.title,"content":t.content,"task_type":t.task_type,"priority":t.priority,"status":t.status,"due_at":t.due_at,"expected_total":t.expected_total,"progress_total":t.progress_total,"created_at":t.created_at,"last_report_at":t.last_report_at}

def report_json(r:WorkReport)->dict:
    return {"id":r.id,"task_id":r.task_id,"business_trip_id":r.business_trip_id,"report_type":r.report_type,"text":r.text,"progress_delta":r.progress_delta,"progress_total":r.progress_total,"status":r.status,"manager_comment":r.manager_comment,"created_at":r.created_at}

@router.get("/config")
def config(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    return get_work_config(db)

@router.get("/tasks")
def tasks(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    rows=db.scalars(select(WorkTask).where(WorkTask.organization_id==employee.organization_id).where((WorkTask.assigned_employee_id==employee.id)|(WorkTask.assigned_employee_id.is_(None))).order_by(WorkTask.created_at.desc())).all()
    return [task_json(x) for x in rows]

@router.post("/tasks/{task_id}/start")
def start_task(task_id:int,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    t=db.get(WorkTask,task_id)
    if not t or t.organization_id!=employee.organization_id or (t.assigned_employee_id not in {None,employee.id}): raise HTTPException(404,"Vazifa topilmadi")
    if t.status=="assigned": t.status="in_progress"; db.commit()
    return task_json(t)


@router.get("/tasks/{task_id}/attachments")
def task_attachments(task_id:int,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    t=db.get(WorkTask,task_id)
    if not t or t.organization_id!=employee.organization_id or t.assigned_employee_id not in {None,employee.id}: raise HTTPException(404,"Vazifa topilmadi")
    rows=db.scalars(select(WorkAttachment).where(WorkAttachment.owner_type=="task",WorkAttachment.owner_id==t.id).order_by(WorkAttachment.id)).all()
    return [{"id":x.id,"media_type":x.media_type,"filename":x.filename,"content_type":x.content_type,"size_bytes":x.size_bytes} for x in rows]

@router.get("/reports/{report_id}/attachments")
def employee_report_attachments(report_id:int,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    r=db.get(WorkReport,report_id)
    if not r or r.employee_id!=employee.id: raise HTTPException(404,"Hisobot topilmadi")
    rows=db.scalars(select(WorkAttachment).where(WorkAttachment.owner_type=="report",WorkAttachment.owner_id==r.id).order_by(WorkAttachment.id)).all()
    return [{"id":x.id,"media_type":x.media_type,"filename":x.filename,"content_type":x.content_type,"size_bytes":x.size_bytes} for x in rows]

@router.post("/ideas/{idea_id}/attachment")
async def idea_attachment(idea_id:int,media_type:str=Form("file"),file:UploadFile=File(...),employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    idea=db.get(Idea,idea_id)
    if not idea or idea.employee_id!=employee.id: raise HTTPException(404,"G‘oya topilmadi")
    data=await file.read()
    if len(data)>20_000_000: raise HTTPException(413,"Fayl 20 MB dan katta")
    a=WorkAttachment(organization_id=employee.organization_id,owner_type="idea",owner_id=idea.id,media_type=media_type,filename=file.filename or "file",content_type=file.content_type or "application/octet-stream",data=data,size_bytes=len(data))
    db.add(a);db.commit();return {"id":a.id,"filename":a.filename,"media_type":a.media_type}

@router.get("/ideas/{idea_id}/attachments")
def idea_attachments(idea_id:int,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    idea=db.get(Idea,idea_id)
    if not idea or idea.employee_id!=employee.id: raise HTTPException(404,"G‘oya topilmadi")
    rows=db.scalars(select(WorkAttachment).where(WorkAttachment.owner_type=="idea",WorkAttachment.owner_id==idea.id).order_by(WorkAttachment.id)).all()
    return [{"id":x.id,"media_type":x.media_type,"filename":x.filename,"content_type":x.content_type,"size_bytes":x.size_bytes} for x in rows]

@router.get("/reports")
def reports(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    return [report_json(x) for x in db.scalars(select(WorkReport).where(WorkReport.employee_id==employee.id).order_by(WorkReport.created_at.desc()).limit(300)).all()]

@router.post("/reports")
def create_report(body:ReportCreate,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    task=None
    report_type="proactive"
    if body.task_id is not None:
        task=db.get(WorkTask,body.task_id)
        if not task or task.organization_id!=employee.organization_id or task.assigned_employee_id not in {None,employee.id}: raise HTTPException(404,"Vazifa topilmadi")
        report_type="task"
    trip=None
    if body.business_trip_id is not None:
        trip=db.get(BusinessTrip,body.business_trip_id)
        if not trip or trip.employee_id!=employee.id: raise HTTPException(404,"Xizmat safari topilmadi")
        report_type="business_trip"
    r=WorkReport(organization_id=employee.organization_id,employee_id=employee.id,task_id=body.task_id,business_trip_id=body.business_trip_id,report_type=report_type,text=body.text,progress_delta=body.progress_delta,progress_total=body.progress_total)
    db.add(r); db.flush()
    if task:
        task.status="in_progress" if task.status!="done" else task.status
        if body.progress_total is not None: task.progress_total=body.progress_total
        elif body.progress_delta is not None: task.progress_total=(task.progress_total or 0)+body.progress_delta
        task.last_report_at=datetime.now(timezone.utc)
        if task.expected_total and task.progress_total>=task.expected_total: task.status="done"
    db.commit(); db.refresh(r); return report_json(r)

@router.post("/reports/{report_id}/attachment")
async def report_attachment(report_id:int,media_type:str=Form("file"),file:UploadFile=File(...),employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    r=db.get(WorkReport,report_id)
    if not r or r.employee_id!=employee.id: raise HTTPException(404,"Hisobot topilmadi")
    data=await file.read()
    if len(data)>20_000_000: raise HTTPException(413,"Fayl 20 MB dan katta")
    a=WorkAttachment(organization_id=employee.organization_id,owner_type="report",owner_id=r.id,media_type=media_type,filename=file.filename or "file",content_type=file.content_type or "application/octet-stream",data=data,size_bytes=len(data))
    db.add(a); db.commit(); return {"id":a.id,"filename":a.filename,"media_type":a.media_type}

@router.get("/attachments/{attachment_id}")
def attachment(attachment_id:int,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    a=db.get(WorkAttachment,attachment_id)
    if not a or a.organization_id!=employee.organization_id: raise HTTPException(404,"Fayl topilmadi")
    return Response(content=a.data,media_type=a.content_type,headers={"Content-Disposition":f'inline; filename="{a.filename}"'})

@router.get("/ideas")
def ideas(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    rows=db.scalars(select(Idea).where(Idea.employee_id==employee.id).order_by(Idea.created_at.desc())).all()
    return [{"id":x.id,"title":x.title,"text":x.text,"status":x.status,"created_at":x.created_at} for x in rows]

@router.post("/ideas")
def create_idea(body:IdeaCreate,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    x=Idea(organization_id=employee.organization_id,employee_id=employee.id,title=body.title,text=body.text);db.add(x);db.commit();db.refresh(x);return {"id":x.id,"title":x.title,"text":x.text,"created_at":x.created_at}

@router.get("/ideas/daily-reminder")
def idea_reminder(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    cfg=get_work_config(db)
    if not cfg.get("daily_idea_reminder_enabled",True): return {"idea":None}
    rows=list(db.scalars(select(Idea).where(Idea.employee_id==employee.id).order_by(Idea.created_at.asc())).all())
    if not rows:return {"idea":None}
    x=random.choice(rows);x.last_reminded_at=datetime.now(timezone.utc);db.commit()
    return {"idea":{"id":x.id,"title":x.title,"text":x.text,"created_at":x.created_at}}

@router.get("/business-trips")
def trips(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    rows=db.scalars(select(BusinessTrip).where(BusinessTrip.employee_id==employee.id).order_by(BusinessTrip.start_at.desc())).all()
    return [{"id":x.id,"title":x.title,"destination":x.destination,"purpose":x.purpose,"start_at":x.start_at,"end_at":x.end_at,"status":x.status} for x in rows]

@router.get("/bonuses")
def bonuses(employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    rows=list(db.scalars(select(BonusAward).where(BonusAward.employee_id==employee.id).order_by(BonusAward.created_at.desc())).all())
    return {"total":sum(float(x.amount) for x in rows),"items":[{"id":x.id,"amount":x.amount,"emoji":x.emoji,"note":x.note,"created_at":x.created_at,"task_id":x.task_id,"report_id":x.report_id} for x in rows]}

@router.post("/locations/batch")
def location_batch(body:LocationBatch,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    cfg=get_work_config(db)
    if not cfg.get("location_tracking_enabled",True): return {"saved":0}
    local=datetime.now(ZoneInfo("Asia/Tashkent")); start=str(cfg.get("working_hours_start","09:00")); end=str(cfg.get("working_hours_end","18:00")); hhmm=local.strftime("%H:%M")
    if not(start<=hhmm<=end): return {"saved":0,"reason":"outside_working_hours"}
    saved=0
    for p in body.points:
        if p.is_mocked: continue
        db.add(EmployeeLocation(organization_id=employee.organization_id,employee_id=employee.id,latitude=p.latitude,longitude=p.longitude,accuracy_m=p.accuracy_m,is_mocked=p.is_mocked,captured_at=p.captured_at or datetime.now(timezone.utc)));saved+=1
    db.commit();return {"saved":saved}

@router.post("/push-token")
def push_token(body:PushTokenIn,employee:Employee=Depends(current_employee),db:Session=Depends(get_db)):
    existing=db.scalar(select(PushDevice).where(PushDevice.actor_type=="employee",PushDevice.actor_id==employee.id,PushDevice.token==body.token))
    if existing: existing.enabled=True;existing.platform=body.platform;existing.last_seen_at=datetime.now(timezone.utc)
    else: db.add(PushDevice(actor_type="employee",actor_id=employee.id,platform=body.platform,token=body.token))
    db.commit();return {"detail":"Push qurilma saqlandi"}

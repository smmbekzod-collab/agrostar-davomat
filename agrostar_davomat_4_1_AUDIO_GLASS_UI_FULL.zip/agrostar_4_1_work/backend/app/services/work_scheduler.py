from __future__ import annotations
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from sqlalchemy import select
from app.db.session import SessionLocal
from app.models.entities import WorkTask
from app.services.work_config import get_work_config
from app.services.push import queue_push

_scheduler = None

def reminder_tick():
    db=SessionLocal()
    try:
        now=datetime.now(timezone.utc); cfg=get_work_config(db)
        tasks=list(db.scalars(select(WorkTask).where(WorkTask.status.in_(["assigned","in_progress"]))).all())
        for t in tasks:
            due=t.next_reminder_at
            if due is not None and (due.tzinfo or timezone.utc) and due <= now and t.assigned_employee_id:
                queue_push(db,"employee",t.assigned_employee_id,f"Vazifa: {t.title}",t.content[:180],category="task_reminder",urgent=t.priority=="urgent",data={"task_id":t.id})
                if t.task_type=="long":
                    local=datetime.now(ZoneInfo("Asia/Tashkent")); hh,mm=[int(x) for x in str(cfg.get("long_task_reminder_time","09:30")).split(':')]
                    nxt=(local+timedelta(days=1)).replace(hour=hh,minute=mm,second=0,microsecond=0)
                    t.next_reminder_at=nxt.astimezone(timezone.utc)
                else:
                    mins=t.reminder_interval_minutes or int(cfg.get("short_task_reminder_minutes",30)); t.next_reminder_at=now+timedelta(minutes=mins)
        db.commit()
    finally: db.close()

def start_scheduler():
    global _scheduler
    if _scheduler is not None: return
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        _scheduler=BackgroundScheduler(timezone="UTC")
        _scheduler.add_job(reminder_tick,"interval",minutes=5,id="task-reminders",replace_existing=True,max_instances=1)
        _scheduler.start()
    except Exception:
        _scheduler=None

def stop_scheduler():
    global _scheduler
    if _scheduler:
        try:_scheduler.shutdown(wait=False)
        except Exception:pass
    _scheduler=None

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "super_admin": {"*"},
    "org_admin": {"org.read", "org.create", "org.update", "employee.read", "employee.manage", "attendance.read", "attendance.manage", "report.read", "admin.read", "work.read", "work.manage", "work.review", "bonus.manage", "location.read"},
    "hr_manager": {"org.read", "employee.read", "employee.manage", "attendance.read", "attendance.manage", "report.read", "work.read", "work.manage", "work.review", "bonus.manage", "location.read"},
    "auditor": {"org.read", "employee.read", "attendance.read", "report.read", "work.read", "location.read"},
}

ALL_PERMISSIONS = sorted({p for values in ROLE_PERMISSIONS.values() for p in values if p != "*"} | {"admin.manage", "audit.read", "settings.manage", "work.read", "work.manage", "work.review", "bonus.manage", "location.read"})


def effective_permissions(role: str, custom: list[str]) -> set[str]:
    base = ROLE_PERMISSIONS.get(role, set())
    if "*" in base:
        return {"*"}
    return base | set(custom or [])

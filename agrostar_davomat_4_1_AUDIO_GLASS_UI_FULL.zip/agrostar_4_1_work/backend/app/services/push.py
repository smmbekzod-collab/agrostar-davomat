from __future__ import annotations
import json
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.entities import PushDevice, NotificationLog
from app.services.work_config import get_work_config

_firebase_ready = False

def _quiet_now(db: Session, urgent: bool) -> bool:
    if urgent: return False
    cfg = get_work_config(db)
    if not cfg.get("friday_quiet_enabled", True): return False
    now = datetime.now(ZoneInfo("Asia/Tashkent"))
    if now.weekday() != 4: return False
    hhmm = now.strftime("%H:%M")
    return str(cfg.get("friday_quiet_start","11:30")) <= hhmm < str(cfg.get("friday_quiet_end","13:30"))

def _firebase_init():
    global _firebase_ready
    if _firebase_ready or not settings.push_enabled or not settings.firebase_credentials_json: return _firebase_ready
    try:
        import firebase_admin
        from firebase_admin import credentials
        if not firebase_admin._apps:
            credentials_obj = credentials.Certificate(json.loads(settings.firebase_credentials_json))
            firebase_admin.initialize_app(credentials_obj)
        _firebase_ready = True
    except Exception:
        _firebase_ready = False
    return _firebase_ready

def queue_push(db: Session, actor_type: str, actor_id: int, title: str, body: str, *, category: str="general", urgent: bool=False, data: dict | None=None) -> NotificationLog:
    log = NotificationLog(actor_type=actor_type, actor_id=actor_id, title=title, body=body, category=category, urgent=urgent, data=data or {}, status="queued")
    db.add(log); db.flush()
    if _quiet_now(db, urgent):
        log.status = "quiet_deferred"; db.commit(); return log
    devices=list(db.scalars(select(PushDevice).where(PushDevice.actor_type==actor_type, PushDevice.actor_id==actor_id, PushDevice.enabled.is_(True))).all())
    if not devices:
        log.status="no_device"; db.commit(); return log
    if not _firebase_init():
        log.status="provider_not_configured"; db.commit(); return log
    try:
        from firebase_admin import messaging
        success=0
        for d in devices:
            msg=messaging.Message(
                token=d.token,
                notification=messaging.Notification(title=title, body=body),
                data={str(k):str(v) for k,v in (data or {}).items()},
                android=messaging.AndroidConfig(priority="high" if urgent else "normal", notification=messaging.AndroidNotification(channel_id="urgent" if urgent else "default", priority="max" if urgent else "default")),
                apns=messaging.APNSConfig(headers={"apns-priority":"10" if urgent else "5"}),
            )
            try: messaging.send(msg); success += 1
            except Exception: pass
        log.status="sent" if success else "failed"; log.sent_at=datetime.now(timezone.utc) if success else None
    except Exception as e:
        log.status="failed"; log.error=str(e)[:1500]
    db.commit(); return log

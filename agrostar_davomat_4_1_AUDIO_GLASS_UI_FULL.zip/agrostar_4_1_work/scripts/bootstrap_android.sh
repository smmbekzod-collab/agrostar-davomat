#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

make_android() {
  local dir="$1" project="$2" label="$3" needs_location="$4" needs_audio="$5"
  rm -rf "$ROOT/$dir/android"
  flutter create --platforms=android --org uz.bekzoddiki.agrostar --project-name "$project" "$TMP/$project" >/dev/null
  cp -R "$TMP/$project/android" "$ROOT/$dir/android"
  python "$ROOT/scripts/patch_android.py" "$ROOT/$dir/android" "$label" "$needs_location" "$needs_audio"
}

make_android employee_app employee "AgroStar Hodim" yes yes
make_android admin_app admin "AgroStar Admin" no yes

echo "Android platform fayllari tayyor."

# GitHub build — AgroStar 4.1.0

## Backend Railway
`zip_file`: `agrostar_davomat_4_1_AUDIO_GLASS_UI_FULL.zip`
`railway_service`: `grand-recreation`

Health: `https://grand-recreation-production-caad.up.railway.app/health` -> version `4.1.0`.

## Android APK
`zip_file`: `agrostar_davomat_4_1_AUDIO_GLASS_UI_FULL.zip`
`api_base_url`: `https://grand-recreation-production-caad.up.railway.app/api/v1`

Artifacts:
- `agrostar-hodim-apk`
- `davomat-admin-apk`

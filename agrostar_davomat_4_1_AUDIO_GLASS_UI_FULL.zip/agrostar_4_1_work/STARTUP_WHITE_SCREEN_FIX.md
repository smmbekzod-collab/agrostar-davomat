# AgroStar 4.0.1 startup white-screen fix

This patch hardens startup for both Flutter apps.

- Secure-storage reads are guarded and time-limited.
- Existing session validation is time-limited.
- Failed/expired sessions no longer leave the app in an indefinite loading/white screen state.
- Employee app falls back to registration / face re-login.
- Admin app falls back to the admin login screen.
- Startup now renders an explicit branded progress screen with status text.
- API connect timeout reduced from 25s to 10s to avoid an apparently frozen first screen.
- Existing attendance, selfie camera, Work 4.0, GPS and backend behavior are unchanged.
- Backend does not need a redeploy for this patch.

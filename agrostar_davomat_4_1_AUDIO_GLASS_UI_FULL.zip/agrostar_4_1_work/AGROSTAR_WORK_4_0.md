# AgroStar Davomat + Work 4.0

Bu versiya 3.6 davomat tizimini buzmasdan, uning ustiga vazifa boshqaruvi, gibrid hisobot, Eureka g‘oyalari, xizmat safari, bonus va ish-vaqti lokatsiyasini qo‘shadi.

## Arxitektura

- **Hodim Flutter ilovasi**: Face login/davomat + Vazifalar + Progress/Proaktiv hisobot + Foto/Ovoz attachment + Xizmat safari + Eureka + Bonus + ish-vaqti lokatsiyasi.
- **Admin Flutter ilovasi**: Super Admin/Org Admin/HR/Auditor + davomat + vazifa yaratish + hisobot ko‘rib chiqish + bonus + xizmat safari + g‘oyalar + lokatsiya + reminder sozlamalari.
- **FastAPI**: bitta REST backend.
- **PostgreSQL**: davomat va Work moduli uchun yagona baza.
- **DeepFace/FaceNet512**: mavjud server-side FaceID va liveness.
- **Railway**: mavjud deployment usuli saqlanadi.

## Yangi jadvallar

- `work_tasks`: sarlavha, matn, qisqa/uzoq turi, priority, xodim, deadline, progress va reminder.
- `work_reports`: vazifaga bog‘langan, proaktiv yoki xizmat-safari hisoboti; incremental progress va manager review.
- `work_attachments`: hisobotga biriktirilgan image/audio/file binary.
- `business_trips`: xodim, manzil, maqsad, muddat, status.
- `ideas`: Eureka g‘oyalari va daily-reminder metadata.
- `bonus_awards`: so‘m miqdori, emoji, sabab, task/report bog‘lanishi.
- `employee_locations`: tejamkor intervaldagi ish-vaqti GPS nuqtalari.
- `push_devices`: Android/iOS push tokenlar.
- `notification_logs`: yuborilgan/navbatdagi notification audit.

## Vazifalar

Manager vazifada `title`, `content`, `task_type`, `priority`, `employee`, `due_at`, `expected_total` belgilaydi. Uzoq ishda xodim masalan “bugun 500, jami 2000” ko‘rinishida progress beradi. `expected_total` ga yetilganda task serverda avtomatik `done` bo‘lishi mumkin.

## Gibrid hisobot

Hodim bitta hisobotda bir vaqtning o‘zida:

- matn;
- progress sonlari;
- foto;
- ovozli yozuv

yubora oladi. Proaktiv hisobot task bo‘lmasa ham yuboriladi. Xizmat safari hisobotlari `business_trip_id` bilan ajratiladi.

## Reminder va push

Backend `APScheduler` bilan 5 daqiqada due reminderlarni tekshiradi. Default:

- qisqa task: 30 minut;
- uzoq task: har kuni 09:30;
- Juma 11:30–13:30: oddiy reminder yuborilmaydi;
- `urgent`: quiet-windowdan ozod va Firebase’da high-priority sifatida yuboriladi.

`work_config` Admin paneldan o‘zgartiriladi, APK qayta build qilinmaydi.

### Muhim platforma cheklovi

“Silent/DND ni majburan buzish” oddiy app tomonidan kafolatlanmaydi. Android’da user DND/notification-policy yoki kanal ruxsatlarini berishi kerak. iOS’da haqiqiy **Critical Alerts** uchun Apple entitlement talab etiladi. 4.0 backend urgent pushni high-priority qilib yuborishga tayyor, lekin OS ruxsatisiz tizim cheklovini aylanib o‘tmaydi.

## Firebase pushni faollashtirish

Backendda `firebase-admin` integratsiyasi tayyor. Railway variablelari:

- `PUSH_ENABLED=true`
- `FIREBASE_CREDENTIALS_JSON=<service account JSON bir qatorda>`

Mobil tomonda `push-token` endpointlari tayyor. Closed/background pushni real qurilmada faollashtirish uchun FlutterFire konfiguratsiyasi (`google-services.json`, iOS `GoogleService-Info.plist`, APNs) kiritilishi kerak. Bu providerga tegishli credential bo‘lgani sabab ZIP ichiga maxfiy kalit qo‘yilmagan.

## GPS tracking

Ish-vaqti lokatsiya **doimiy real-time kuzatuv emas**. Default 15 minut yoki 100 m harakatda nuqta yuboradi. Backend faqat belgilangan ish oralig‘idagi nuqtalarni qabul qiladi. Mock-location yuborilmaydi. Admin faqat o‘z tashkiloti xodimlarini ko‘radi, Super Admin hammasini ko‘radi.

## Oldingi Davomat funksiyalari

3.6 dagi barcha funksiyalar saqlangan: 2 alohida app, Face-only re-login, anti-spoofing, selfie aspect-ratio fix, istalgan joydan Keldim/Ketdim, registration area toggle, selfie retention, Excel, review flags, remote config, admin permissions va audit.

import 'dart:ui';
import 'package:flutter/material.dart';

class AgroColors {
  static const orange = Color(0xFFF7921E);
  static const green = Color(0xFFA8E000);
  static const purple = Color(0xFF514277);
  static const charcoal = Color(0xFF2C2A29);
  static const cream = Color(0xFFF8FAF2);
}

ThemeData agroTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AgroColors.green,
    brightness: Brightness.light,
    primary: AgroColors.purple,
    secondary: AgroColors.orange,
    surface: AgroColors.cream,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AgroColors.cream,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      foregroundColor: AgroColors.charcoal,
      centerTitle: false,
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white.withValues(alpha: .78),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white.withValues(alpha: .72),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: AgroColors.purple.withValues(alpha: .16))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: AgroColors.orange, width: 1.5)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AgroColors.purple, foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white.withValues(alpha: .88),
      indicatorColor: AgroColors.green.withValues(alpha: .28),
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontWeight: FontWeight.w600)),
    ),
  );
}

class AgroBackground extends StatelessWidget {
  final Widget child;
  const AgroBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFFFFBF4), Color(0xFFF4F9E8), Color(0xFFF1EEF8)],
      ),
    ),
    child: child,
  );
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});
  @override
  Widget build(BuildContext context) {
    final card = ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .67),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withValues(alpha: .75)),
            boxShadow: [BoxShadow(color: AgroColors.purple.withValues(alpha: .08), blurRadius: 22, offset: const Offset(0, 8))],
          ),
          child: child,
        ),
      ),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: onTap == null ? card : InkWell(borderRadius: BorderRadius.circular(22), onTap: onTap, child: card),
    );
  }
}

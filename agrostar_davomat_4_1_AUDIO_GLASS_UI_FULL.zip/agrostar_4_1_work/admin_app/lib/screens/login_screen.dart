import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../models/models.dart';

class LoginScreen extends StatefulWidget {
  final ApiClient api; final VoidCallback onLogin; final String? startupWarning;
  const LoginScreen({super.key,required this.api,required this.onLogin,this.startupWarning});
  @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
  static const currentVersion='4.1.0';
  final u=TextEditingController(),p=TextEditingController(),full=TextEditingController();
  List<Organization> orgs=[];int? orgId;bool loading=false,register=false;Map<String,dynamic> cfg={};
  @override void initState(){super.initState();_load();}
  int cmp(String a,String b){List<int> v(String x)=>x.split('.').map((e)=>int.tryParse(RegExp(r'^\d+').stringMatch(e)??'0')??0).toList();final aa=v(a),bb=v(b);for(var i=0;i<3;i++){final x=i<aa.length?aa[i]:0,y=i<bb.length?bb[i]:0;if(x!=y)return x.compareTo(y);}return 0;}
  bool get forced=>cmp(currentVersion,cfg['admin_min_version']?.toString()??currentVersion)<0;
  bool get update=>cmp(currentVersion,cfg['admin_latest_version']?.toString()??currentVersion)<0;
  Future<void> _load()async{try{orgs=await widget.api.publicOrganizations();cfg=await widget.api.publicMobileConfig();if(orgs.isNotEmpty)orgId=orgs.first.id;}catch(_){ }if(mounted)setState((){});}
  void snack(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s.replaceFirst('Exception: ',''))));
  Future<void> submit()async{if(forced){snack(cfg['update_message']?.toString()??'Ilovani yangilang');return;}setState(()=>loading=true);try{if(register){if(orgId==null)throw Exception('Tashkilot tanlang');await widget.api.registerRequest(full.text.trim(),u.text.trim(),p.text,orgId!);snack("So'rov yuborildi. Super Admin tasdiqlashi kerak.");setState(()=>register=false);}else{await widget.api.login(u.text.trim(),p.text);widget.onLogin();}}catch(e){snack('$e');}if(mounted)setState(()=>loading=false);}
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:460),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
    Image.asset('assets/agrostar_logo.png',height:120,fit:BoxFit.contain),const SizedBox(height:12),Text(register?"Admin ro'yxatdan o'tish so'rovi":'AGROSTAR Admin',style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:10),
    if(widget.startupWarning!=null&&widget.startupWarning!.isNotEmpty)Card(color:Theme.of(context).colorScheme.secondaryContainer,child:Padding(padding:const EdgeInsets.all(10),child:Text(widget.startupWarning!))),
    if(cfg['banner_enabled']==true&&('${cfg['banner_message']??''}').isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(10),child:Text(cfg['banner_message'].toString()))),
    if(forced||update)Card(color:forced?Theme.of(context).colorScheme.errorContainer:null,child:Padding(padding:const EdgeInsets.all(10),child:Text('${cfg['update_message']??'Yangi versiya mavjud'}\nJoriy: $currentVersion • Oxirgi: ${cfg['admin_latest_version']??''}${forced?'\nYangilash majburiy.':''}'))),const SizedBox(height:10),
    if(register)...[TextField(controller:full,decoration:const InputDecoration(labelText:'F.I.O.',border:OutlineInputBorder())),const SizedBox(height:12),DropdownButtonFormField<int>(initialValue:orgId,decoration:const InputDecoration(labelText:'Tashkilot',border:OutlineInputBorder()),items:orgs.map((o)=>DropdownMenuItem(value:o.id,child:Text(o.name))).toList(),onChanged:(v)=>setState(()=>orgId=v)),const SizedBox(height:12)],
    TextField(controller:u,decoration:const InputDecoration(labelText:'Login',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Parol',border:OutlineInputBorder())),const SizedBox(height:18),
    FilledButton(onPressed:loading||forced?null:submit,child:Text(loading?'Kuting...':register?"So'rov yuborish":'Kirish')),TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Kirish oynasiga qaytish':"Admin bo'lish uchun ro'yxatdan o'tish"))
  ])))))));
}

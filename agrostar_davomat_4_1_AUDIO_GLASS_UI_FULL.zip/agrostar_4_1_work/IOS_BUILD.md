# iOS build

Flutter kodlari Android/iOS uchun yozilgan. iOS binarini build qilish uchun macOS + Xcode + Apple Developer signing kerak.

Mac'da har bir app papkasida:

```bash
flutter create --platforms=ios .
flutter pub get
flutter build ipa --release --dart-define=API_BASE_URL=https://grand-recreation-production-caad.up.railway.app/api/v1
```

`Info.plist` da camera, microphone, when-in-use location va background location izohlari kiritiladi. Background location faqat ish-vaqti tracking yoqilgan tashkilotlarda ishlatilishi kerak.

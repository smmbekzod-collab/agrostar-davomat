# AgroStar Davomat 3.4.0

## Xodim qayta kirishi

- `Oldin ro‘yxatdan o‘tganman` orqali F.I.O. + tashkilot + jonli selfi bilan qayta kirish ishlaydi.
- Yangi telefon yoki qayta o‘rnatilgan ilovada endi Admin device reset talab qilinmaydi.
- Yuz va liveness tekshiruvi muvaffaqiyatli bo‘lsa akkaunt yangi qurilmaga avtomatik bog‘lanadi.
- Qurilma o‘zgarganda `token_version` oshadi, shu sabab eski qurilmadagi sessiyalar avtomatik yaroqsiz bo‘ladi.
- Super Admin/Admin akkaunti va Hodim akkaunti alohida hisoblanadi; bir odam ikkala rolga ham ega bo‘lishi mumkin.

## Selfi kamera

- Android old kameradagi "tapaloq" preview tuzatildi.
- Kamera portret orientatsiyaga lock qilinadi.
- Portret preview uchun sensor aspect ratio teskari qo‘llanadi.
- Autofocus va auto-exposure yoqiladi.
- Yuzni to‘g‘ri joylashtirish uchun oval yo‘riqnoma qo‘shildi.

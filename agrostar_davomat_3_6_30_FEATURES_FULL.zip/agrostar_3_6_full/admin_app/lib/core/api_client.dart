import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import '../models/models.dart';
import 'config.dart';
import 'session_store.dart';

class ApiClient {
  final Dio dio=Dio(BaseOptions(baseUrl:AppConfig.apiBaseUrl,connectTimeout:const Duration(seconds:20),receiveTimeout:const Duration(seconds:90)));
  final SessionStore session; ApiClient(this.session);
  String msg(Object e){
    if(e is DioException){
      final d=e.response?.data;
      if(d is Map&&d['detail']!=null){
        final detail=d['detail'];
        if(detail is Map&&detail['message']!=null)return detail['message'].toString();
        if(detail is List&&detail.isNotEmpty){final first=detail.first;if(first is Map)return first['msg']?.toString()??'Kiritilgan ma’lumot noto‘g‘ri.';}
        return detail.toString();
      }
      return e.message??'Server xatosi';
    }
    return e.toString();
  }
  Future<Options> opts()async=>Options(headers:{'Authorization':'Bearer ${await session.accessToken()}'});
  Future<void> login(String u,String p)async{try{final r=await dio.post('/admin-auth/login',data:{'username':u,'password':p});await session.save(r.data['access_token'],r.data['refresh_token']);}catch(e){throw Exception(msg(e));}}
  Future<void> registerRequest(String fullName,String username,String password,int orgId)async{try{await dio.post('/admin-auth/register-request',data:{'full_name':fullName,'username':username,'password':password,'organization_id':orgId});}catch(e){throw Exception(msg(e));}}
  Future<bool> refresh()async{final t=await session.refreshToken();if(t==null)return false;try{final r=await dio.post('/admin-auth/refresh',data:{'refresh_token':t});await session.save(r.data['access_token'],r.data['refresh_token']);return true;}catch(_){await session.clear();return false;}}
  Future<Response> _req(String method,String path,{dynamic data,Map<String,dynamic>? query})async{try{return await dio.request(path,data:data,queryParameters:query,options:(await opts()).copyWith(method:method));}on DioException catch(e){if(e.response?.statusCode==401&&await refresh())return dio.request(path,data:data,queryParameters:query,options:(await opts()).copyWith(method:method));throw Exception(msg(e));}}
  Future<Uint8List> _bytes(String path)async{try{Response r;try{r=await dio.get(path,options:(await opts()).copyWith(responseType:ResponseType.bytes));}on DioException catch(e){if(e.response?.statusCode==401&&await refresh()){r=await dio.get(path,options:(await opts()).copyWith(responseType:ResponseType.bytes));}else{rethrow;}}return Uint8List.fromList(List<int>.from(r.data));}catch(e){throw Exception(msg(e));}}
  Future<File> _download(String path,String filename,{Map<String,dynamic>? query})async{final dir=await getTemporaryDirectory();final f=File('${dir.path}/$filename');try{Response r;try{r=await dio.get(path,queryParameters:query,options:(await opts()).copyWith(responseType:ResponseType.bytes));}on DioException catch(e){if(e.response?.statusCode==401&&await refresh()){r=await dio.get(path,queryParameters:query,options:(await opts()).copyWith(responseType:ResponseType.bytes));}else{rethrow;}}await f.writeAsBytes(List<int>.from(r.data));return f;}catch(e){throw Exception(msg(e));}}

  Future<Map<String,dynamic>> me()async=>Map<String,dynamic>.from((await _req('GET','/admin/me')).data);
  Future<Map<String,dynamic>> dashboard()async=>Map<String,dynamic>.from((await _req('GET','/admin/dashboard')).data);
  Future<List<Map<String,dynamic>>> orgDashboard()async{final r=await _req('GET','/admin/organization-dashboard');return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}
  Future<List<Map<String,dynamic>>> todayStatus({int? orgId,String? status})async{final q=<String,dynamic>{};if(orgId!=null)q['organization_id']=orgId;if(status!=null&&status.isNotEmpty)q['status']=status;final r=await _req('GET','/admin/today-status',query:q.isEmpty?null:q);return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}
  Future<Map<String,dynamic>> permissionCatalog()async=>Map<String,dynamic>.from((await _req('GET','/admin/permissions')).data);
  Future<Map<String,dynamic>> mobileConfig()async=>Map<String,dynamic>.from((await _req('GET','/admin/mobile-config')).data);
  Future<Map<String,dynamic>> updateMobileConfig(Map<String,dynamic> data)async=>Map<String,dynamic>.from((await _req('PATCH','/admin/mobile-config',data:data)).data);
  Future<Map<String,dynamic>> securityConfig()async=>Map<String,dynamic>.from((await _req('GET','/admin/security-config')).data);
  Future<Map<String,dynamic>> updateSecurityConfig(Map<String,dynamic> data)async=>Map<String,dynamic>.from((await _req('PATCH','/admin/security-config',data:data)).data);
  Future<void> changeOwnPassword(String current,String next)async=>_req('POST','/admin/change-password',data:{'current_password':current,'new_password':next});

  Future<List<Organization>> publicOrganizations()async{final r=await dio.get('/public/organizations');return(r.data as List).map((e)=>Organization.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<Map<String,dynamic>> publicMobileConfig()async=>Map<String,dynamic>.from((await dio.get('/public/mobile-config')).data);
  Future<List<Organization>> organizations()async{final r=await _req('GET','/admin/organizations');return(r.data as List).map((e)=>Organization.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<void> createOrganization(Map<String,dynamic> data)async=>_req('POST','/admin/organizations',data:data);
  Future<void> updateOrganization(int id,Map<String,dynamic> data)async=>_req('PATCH','/admin/organizations/$id',data:data);
  Future<void> deactivateOrganization(int id)async=>_req('DELETE','/admin/organizations/$id');
  Future<Map<String,dynamic>> reportColumns()async=>Map<String,dynamic>.from((await _req('GET','/admin/report-columns')).data);

  Future<List<AdminAccount>> admins()async{final r=await _req('GET','/admin/admins');return(r.data as List).map((e)=>AdminAccount.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<void> createAdmin(Map<String,dynamic> data)async=>_req('POST','/admin/admins',data:data);
  Future<void> updateAdmin(int id,Map<String,dynamic> data)async=>_req('PATCH','/admin/admins/$id',data:data);
  Future<void> approveAdmin(int id)async=>_req('POST','/admin/admins/$id/approve');
  Future<void> resetAdminPassword(int id,String p)async=>_req('POST','/admin/admins/$id/reset-password',data:{'new_password':p});
  Future<void> terminateAdminSessions(int id)async=>_req('POST','/admin/admins/$id/terminate-sessions');
  Future<void> deactivateAdmin(int id)async=>_req('DELETE','/admin/admins/$id');

  Future<List<EmployeeItem>> employees({int? orgId,String? status})async{final q=<String,dynamic>{};if(orgId!=null)q['organization_id']=orgId;if(status!=null)q['status']=status;final r=await _req('GET','/admin/employees',query:q.isEmpty?null:q);return(r.data as List).map((e)=>EmployeeItem.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<Uint8List> employeeRegistrationSelfie(int id)async=>_bytes('/admin/employees/$id/registration-selfie');
  Future<void> approveEmployee(int id)async=>_req('POST','/admin/employees/$id/approve');
  Future<void> resetEmployeeDevice(int id)async=>_req('POST','/admin/employees/$id/reset-device');
  Future<void> updateEmployee(int id,Map<String,dynamic> data)async=>_req('PATCH','/admin/employees/$id',data:data);
  Future<void> archiveEmployee(int id)async=>_req('POST','/admin/employees/$id/archive');
  Future<List<Map<String,dynamic>>> employeeHistory(int id)async{final r=await _req('GET','/admin/employees/$id/history');return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}

  Future<List<AttendanceItem>> attendance({int? orgId,String? reviewStatus})async{final q=<String,dynamic>{'limit':1000};if(orgId!=null)q['organization_id']=orgId;if(reviewStatus!=null&&reviewStatus.isNotEmpty)q['review_status']=reviewStatus;final r=await _req('GET','/admin/attendance',query:q);return(r.data as List).map((e)=>AttendanceItem.fromJson(Map<String,dynamic>.from(e))).toList();}
  Future<Uint8List> attendanceSelfie(int id)async=>_bytes('/admin/attendance/$id/selfie');
  Future<void> attendanceNote(int id,String note)async=>_req('PATCH','/admin/attendance/$id/note',data:{'admin_note':note});
  Future<void> attendanceReview(int id,String status,{String? note})async=>_req('PATCH','/admin/attendance/$id/review',data:{'review_status':status,'admin_note':note});
  Future<List<Map<String,dynamic>>> employeeStats(String start,String end,{int? orgId})async{final q={'start_date':start,'end_date':end};if(orgId!=null)q['organization_id']=orgId.toString();final r=await _req('GET','/admin/stats/employees',query:q);return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}

  Future<File> monthlyReport(int orgId,int year,int month)async=>_download('/admin/reports/monthly.xlsx','davomat_${orgId}_${year}_${month.toString().padLeft(2,'0')}.xlsx',query:{'organization_id':orgId,'year':year,'month':month});
  Future<File> rangeReport(int orgId,String start,String end)async=>_download('/admin/reports/range.xlsx','davomat_${orgId}_${start}_$end.xlsx',query:{'organization_id':orgId,'start_date':start,'end_date':end});
  Future<File> allOrgReport(String start,String end)async=>_download('/admin/reports/all-organizations.xlsx','davomat_barcha_${start}_$end.xlsx',query:{'start_date':start,'end_date':end});
  Future<Map<String,dynamic>> cleanupSelfies()async=>Map<String,dynamic>.from((await _req('POST','/admin/maintenance/cleanup-selfies')).data);
  Future<List<Map<String,dynamic>>> audit()async{final r=await _req('GET','/admin/audit');return(r.data as List).map((e)=>Map<String,dynamic>.from(e)).toList();}
}

class Organization {
  final int id; final String name; final String code; final bool isActive; final String locationMode; final bool autoApprove;
  final String timezone; final String workStart; final String workEnd; final int graceMinutes;
  final bool lateMonitoring; final bool earlyLeaveMonitoring; final String lateReasonMode; final String earlyLeaveReasonMode;
  final double? faceThreshold; final String antiSpoofPolicy; final int selfieRetentionDays; final double suspiciousAccuracyM;
  final double suspiciousFaceMargin; final double unusualDistanceKm; final List<String> reportColumns;
  Organization({required this.id,required this.name,required this.code,required this.isActive,required this.locationMode,required this.autoApprove,
    required this.timezone,required this.workStart,required this.workEnd,required this.graceMinutes,required this.lateMonitoring,
    required this.earlyLeaveMonitoring,required this.lateReasonMode,required this.earlyLeaveReasonMode,this.faceThreshold,
    required this.antiSpoofPolicy,required this.selfieRetentionDays,required this.suspiciousAccuracyM,required this.suspiciousFaceMargin,
    required this.unusualDistanceKm,required this.reportColumns});
  factory Organization.fromJson(Map<String,dynamic> j)=>Organization(
    id:j['id'],name:j['name'],code:j['code'],isActive:j['is_active'],locationMode:j['location_mode'],autoApprove:j['employee_auto_approve'],
    timezone:j['timezone']??'Asia/Tashkent',workStart:j['work_start']??'09:00',workEnd:j['work_end']??'18:00',graceMinutes:j['grace_minutes']??10,
    lateMonitoring:j['late_monitoring_enabled']??true,earlyLeaveMonitoring:j['early_leave_monitoring_enabled']??true,
    lateReasonMode:j['late_reason_mode']?.toString()??'optional',earlyLeaveReasonMode:j['early_leave_reason_mode']?.toString()??'optional',
    faceThreshold:(j['face_threshold_override'] as num?)?.toDouble(),antiSpoofPolicy:j['anti_spoof_policy']?.toString()??'required',
    selfieRetentionDays:(j['selfie_retention_days'] as num?)?.toInt()??90,suspiciousAccuracyM:(j['suspicious_accuracy_m'] as num?)?.toDouble()??80,
    suspiciousFaceMargin:(j['suspicious_face_margin'] as num?)?.toDouble()??0.03,unusualDistanceKm:(j['unusual_distance_km'] as num?)?.toDouble()??50,
    reportColumns:List<String>.from(j['report_columns']??const[]));
}

class AdminAccount {
  final int id; final String fullName; final String username; final String role; final List<String> permissions; final List<int> organizationIds; final bool isActive; final bool isApproved;
  final bool forcePasswordChange;
  AdminAccount({required this.id,required this.fullName,required this.username,required this.role,required this.permissions,required this.organizationIds,required this.isActive,required this.isApproved,required this.forcePasswordChange});
  factory AdminAccount.fromJson(Map<String,dynamic> j)=>AdminAccount(id:j['id'],fullName:j['full_name'],username:j['username'],role:j['role'],permissions:List<String>.from(j['permissions']??[]),organizationIds:List<int>.from(j['organization_ids']??[]),isActive:j['is_active'],isApproved:j['is_approved'],forcePasswordChange:j['force_password_change']==true);
}

class EmployeeItem {
  final int id; final String fullName; final String code; final int orgId; final String orgName; final bool active; final bool approved; final bool deviceBound;
  final bool registrationOutsideArea; final String? registrationAreaNote; final bool registrationSelfieAvailable;
  final String employmentStatus; final String? statusNote; final DateTime? statusUntil; final DateTime? archivedAt;
  EmployeeItem({required this.id,required this.fullName,required this.code,required this.orgId,required this.orgName,required this.active,required this.approved,required this.deviceBound,required this.registrationOutsideArea,this.registrationAreaNote,required this.registrationSelfieAvailable,required this.employmentStatus,this.statusNote,this.statusUntil,this.archivedAt});
  factory EmployeeItem.fromJson(Map<String,dynamic> j)=>EmployeeItem(
    id:j['id'],fullName:j['full_name'],code:j['employee_code'],orgId:j['organization_id'],orgName:j['organization_name'],active:j['is_active'],approved:j['is_approved'],deviceBound:j['device_bound']??false,
    registrationOutsideArea:j['registration_outside_area']??false,registrationAreaNote:j['registration_area_note']?.toString(),registrationSelfieAvailable:j['registration_selfie_available']==true,
    employmentStatus:j['employment_status']?.toString()??'active',statusNote:j['status_note']?.toString(),statusUntil:j['status_until']==null?null:DateTime.tryParse(j['status_until'].toString()),archivedAt:j['archived_at']==null?null:DateTime.tryParse(j['archived_at'].toString()));
}

class AttendanceItem {
  final int id; final int employeeId; final String employeeName; final String orgName; final String type; final DateTime at; final double lat; final double lon; final double? accuracy; final double? distance; final double? threshold; final String? scheduleStatus; final int? minutesDelta; final bool selfieAvailable;
  final String? employeeReason; final String? adminNote; final String reviewStatus; final List<String> suspiciousFlags;
  AttendanceItem({required this.id,required this.employeeId,required this.employeeName,required this.orgName,required this.type,required this.at,required this.lat,required this.lon,this.accuracy,this.distance,this.threshold,this.scheduleStatus,this.minutesDelta,required this.selfieAvailable,this.employeeReason,this.adminNote,required this.reviewStatus,required this.suspiciousFlags});
  factory AttendanceItem.fromJson(Map<String,dynamic> j)=>AttendanceItem(id:j['id'],employeeId:j['employee_id'],employeeName:j['employee_name'],orgName:j['organization_name'],type:j['event_type'],at:DateTime.parse(j['occurred_at']),lat:(j['latitude'] as num).toDouble(),lon:(j['longitude'] as num).toDouble(),accuracy:(j['accuracy_m'] as num?)?.toDouble(),distance:(j['face_distance'] as num?)?.toDouble(),threshold:(j['face_threshold'] as num?)?.toDouble(),scheduleStatus:j['schedule_status'],minutesDelta:j['minutes_delta'],selfieAvailable:j['selfie_available']==true,employeeReason:j['employee_reason']?.toString(),adminNote:j['admin_note']?.toString(),reviewStatus:j['review_status']?.toString()??'approved',suspiciousFlags:List<String>.from(j['suspicious_flags']??const[]));
}

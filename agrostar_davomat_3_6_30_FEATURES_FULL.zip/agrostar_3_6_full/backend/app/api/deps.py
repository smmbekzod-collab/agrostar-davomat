from datetime import datetime, timezone
from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import decode_token
from app.db.session import get_db
from app.models.entities import AdminUser, Employee
from app.services.permissions import effective_permissions

bearer = HTTPBearer(auto_error=False)


def _payload(credentials: HTTPAuthorizationCredentials | None, actor: str, token_type: str = "access") -> dict:
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token talab qilinadi")
    try:
        payload = decode_token(credentials.credentials)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token yaroqsiz")
    if payload.get("actor") != actor or payload.get("typ") != token_type:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token turi mos emas")
    return payload


def current_admin(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> AdminUser:
    p = _payload(credentials, "admin")
    admin = db.scalar(select(AdminUser).where(AdminUser.id == int(p["sub"])))
    if not admin or not admin.is_active or not admin.is_approved or admin.token_version != int(p.get("ver", 0)):
        raise HTTPException(status_code=401, detail="Admin sessiyasi yaroqsiz")
    return admin


def current_employee(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), x_device_id: str = Header(..., alias="X-Device-ID"), db: Session = Depends(get_db)) -> Employee:
    p = _payload(credentials, "employee")
    emp = db.scalar(select(Employee).where(Employee.id == int(p["sub"])))
    if not emp or not emp.is_active or emp.token_version != int(p.get("ver", 0)):
        raise HTTPException(status_code=401, detail="Xodim sessiyasi yaroqsiz")
    if emp.employment_status in {"leave", "business_trip", "sick"} and emp.status_until is not None:
        until = emp.status_until if emp.status_until.tzinfo else emp.status_until.replace(tzinfo=timezone.utc)
        if until <= datetime.now(timezone.utc):
            emp.employment_status = "active"; emp.status_until = None; emp.status_note = None
            db.commit(); db.refresh(emp)
    if not emp.device_id or emp.device_id != x_device_id:
        raise HTTPException(status_code=401, detail="Ushbu akkaunt boshqa qurilmaga bog'langan")
    return emp


def require_permission(permission: str):
    def dep(admin: AdminUser = Depends(current_admin)) -> AdminUser:
        perms = effective_permissions(admin.role, admin.permissions)
        if "*" not in perms and permission not in perms:
            raise HTTPException(status_code=403, detail="Bu amal uchun huquq yetarli emas")
        return admin
    return dep

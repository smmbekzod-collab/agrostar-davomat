from __future__ import annotations
from datetime import date, datetime, time, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from zoneinfo import ZoneInfo

from app.api.deps import current_admin, require_permission
from app.core.security import hash_password, verify_password
from app.db.session import get_db
from app.models.entities import Organization, AdminUser, AdminOrganization, Employee, Attendance, AuditLog, DEFAULT_REPORT_COLUMNS
from app.schemas.admin import (
    OrganizationCreate, OrganizationUpdate, AdminCreate, AdminUpdate, ResetPassword,
    EmployeeUpdate, ChangeOwnPassword, MobileConfigUpdate, SecurityConfigUpdate,
    AttendanceNoteUpdate, AttendanceReviewUpdate,
)
from app.services.audit import add_audit
from app.services.permissions import ALL_PERMISSIONS, effective_permissions
from app.services.report import monthly_xlsx, range_xlsx
from app.services.biometric_crypto import decrypt_bytes
from app.services.mobile_config import (
    get_mobile_config, save_mobile_config, get_security_config, save_security_config,
)
from app.services.retention import cleanup_expired_selfies

router = APIRouter(prefix="/admin", tags=["admin"])


def org_ids(admin: AdminUser) -> set[int]:
    return {x.organization_id for x in admin.org_links}


def can_access_org(admin: AdminUser, organization_id: int):
    if admin.role != "super_admin" and organization_id not in org_ids(admin):
        raise HTTPException(403, "Bu tashkilotga kirish huquqi yo'q")


def admin_json(a: AdminUser) -> dict:
    return {
        "id": a.id, "full_name": a.full_name, "username": a.username, "role": a.role,
        "permissions": a.permissions or [], "organization_ids": sorted(org_ids(a)),
        "is_active": a.is_active, "is_approved": a.is_approved, "created_at": a.created_at,
        "last_login_at": a.last_login_at, "force_password_change": a.force_password_change,
        "locked_until": a.locked_until,
    }


def _org_query_scope(q, admin: AdminUser, column):
    if admin.role != "super_admin":
        q = q.where(column.in_(list(org_ids(admin))))
    return q


def _parse_date(value: str, field: str) -> date:
    try:
        return date.fromisoformat(value)
    except Exception as exc:
        raise HTTPException(422, f"{field} YYYY-MM-DD formatida bo'lishi kerak") from exc


def _org_day_bounds(org: Organization, day: date | None = None) -> tuple[datetime, datetime, ZoneInfo]:
    try:
        tz = ZoneInfo(org.timezone or "Asia/Tashkent")
    except Exception:
        tz = ZoneInfo("Asia/Tashkent")
    if day is None:
        day = datetime.now(timezone.utc).astimezone(tz).date()
    start_local = datetime.combine(day, time.min, tzinfo=tz)
    end_local = start_local + timedelta(days=1)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc), tz


def _today_rows(db: Session, admin: AdminUser, organization_id: int | None = None, status_filter: str | None = None) -> list[dict]:
    q = select(Employee).where(Employee.is_active.is_(True)).order_by(Employee.organization_id, Employee.full_name)
    if organization_id is not None:
        can_access_org(admin, organization_id)
        q = q.where(Employee.organization_id == organization_id)
    elif admin.role != "super_admin":
        q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    employees = list(db.scalars(q).all())
    now = datetime.now(timezone.utc)
    changed = False
    for employee in employees:
        if employee.employment_status in {"leave", "business_trip", "sick"} and employee.status_until is not None:
            until = employee.status_until if employee.status_until.tzinfo else employee.status_until.replace(tzinfo=timezone.utc)
            if until <= now:
                employee.employment_status = "active"; employee.status_until = None; employee.status_note = None; changed = True
    if changed: db.commit()
    by_org: dict[int, list[Employee]] = {}
    for employee in employees:
        by_org.setdefault(employee.organization_id, []).append(employee)

    output: list[dict] = []
    for oid, org_employees in by_org.items():
        org = org_employees[0].organization
        start_utc, end_utc, _ = _org_day_bounds(org)
        emp_ids = [e.id for e in org_employees]
        events = list(db.scalars(
            select(Attendance)
            .where(Attendance.employee_id.in_(emp_ids))
            .where(Attendance.occurred_at >= start_utc, Attendance.occurred_at < end_utc)
            .where(Attendance.review_status != "rejected")
            .order_by(Attendance.occurred_at.asc())
        ).all())
        grouped: dict[int, list[Attendance]] = {}
        for event in events:
            grouped.setdefault(event.employee_id, []).append(event)

        for employee in org_employees:
            own = grouped.get(employee.id, [])
            checkins = [x for x in own if x.event_type == "checkin"]
            checkouts = [x for x in own if x.event_type == "checkout"]
            first_checkin = checkins[0] if checkins else None
            last_checkout = checkouts[-1] if checkouts else None
            late = any(x.schedule_status == "late" for x in checkins)
            early = any(x.schedule_status == "early_leave" for x in checkouts)
            pending = any(x.review_status == "pending_review" for x in own)
            exempt = employee.employment_status != "active"
            if exempt:
                final_status = "exempt"
            elif first_checkin and last_checkout:
                final_status = "complete"
            elif first_checkin:
                final_status = "only_checkin"
            elif last_checkout:
                final_status = "only_checkout"
            else:
                final_status = "absent"
            row = {
                "employee_id": employee.id,
                "employee_name": employee.full_name,
                "employee_code": employee.employee_code,
                "organization_id": employee.organization_id,
                "organization_name": org.name,
                "is_approved": employee.is_approved,
                "employment_status": employee.employment_status,
                "status_note": employee.status_note,
                "checkin_done": first_checkin is not None,
                "checkout_done": last_checkout is not None,
                "checkin_at": first_checkin.occurred_at if first_checkin else None,
                "checkout_at": last_checkout.occurred_at if last_checkout else None,
                "checkin_attendance_id": first_checkin.id if first_checkin else None,
                "checkout_attendance_id": last_checkout.id if last_checkout else None,
                "checkin_selfie_available": bool(first_checkin and first_checkin.selfie_enc),
                "checkout_selfie_available": bool(last_checkout and last_checkout.selfie_enc),
                "registration_selfie_available": bool(employee.registration_selfie_enc),
                "final_status": final_status,
                "late": late,
                "early_leave": early,
                "pending_review": pending,
                "registration_outside_area": employee.registration_outside_area,
                "registration_area_note": employee.registration_area_note,
            }
            match status_filter:
                case "keldi": include = row["checkin_done"]
                case "kelmadi": include = not row["checkin_done"] and not exempt
                case "ketdi": include = row["checkout_done"]
                case "ketmadi": include = not row["checkout_done"] and not exempt
                case "kechikdi": include = late
                case "erta_ketdi": include = early
                case "tekshiruvda": include = pending
                case "toliq": include = final_status == "complete"
                case "faqat_keldim": include = final_status == "only_checkin"
                case "faqat_ketdim": include = final_status == "only_checkout"
                case "davomat_qilmagan": include = final_status == "absent"
                case _: include = True
            if include:
                output.append(row)
    return output


@router.get("/me")
def me(admin: AdminUser = Depends(current_admin)):
    return {**admin_json(admin), "effective_permissions": sorted(effective_permissions(admin.role, admin.permissions))}


@router.post("/change-password")
def change_password(body: ChangeOwnPassword, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if not verify_password(body.current_password, admin.password_hash):
        raise HTTPException(403, "Joriy parol noto'g'ri")
    admin.password_hash = hash_password(body.new_password)
    admin.password_changed_at = datetime.now(timezone.utc)
    admin.force_password_change = False
    admin.token_version += 1
    add_audit(db, admin.id, "admin.change_own_password", "admin", str(admin.id))
    db.commit()
    return {"detail": "Parol almashtirildi. Qayta kiring."}


@router.get("/permissions")
def permissions(_: AdminUser = Depends(current_admin)):
    return {"permissions": ALL_PERMISSIONS, "roles": ["super_admin", "org_admin", "hr_manager", "auditor"]}


@router.get("/mobile-config")
def admin_mobile_config(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    return get_mobile_config(db)


@router.patch("/mobile-config")
def update_mobile_config(body: MobileConfigUpdate, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    patch = body.model_dump(exclude_unset=True)
    result = save_mobile_config(db, patch)
    add_audit(db, admin.id, "mobile_config.update", "system", "mobile_config", patch)
    return result


@router.get("/security-config")
def security_config(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    return get_security_config(db)


@router.patch("/security-config")
def update_security_config(body: SecurityConfigUpdate, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    patch = body.model_dump(exclude_unset=True)
    result = save_security_config(db, patch)
    add_audit(db, admin.id, "security_config.update", "system", "security_config", patch)
    return result


@router.get("/dashboard")
def dashboard(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    cleanup_expired_selfies(db)
    ids = None if admin.role == "super_admin" else list(org_ids(admin))
    oq = select(func.count(Organization.id)).where(Organization.is_active.is_(True))
    eq = select(func.count(Employee.id)).where(Employee.is_active.is_(True))
    if ids is not None:
        oq = oq.where(Organization.id.in_(ids)); eq = eq.where(Employee.organization_id.in_(ids))
    rows = _today_rows(db, admin)
    active_rows = [x for x in rows if x["employment_status"] == "active"]
    return {
        "organizations": db.scalar(oq) or 0,
        "employees": db.scalar(eq) or 0,
        "pending_admins": db.scalar(select(func.count(AdminUser.id)).where(AdminUser.is_approved.is_(False))) if admin.role == "super_admin" else 0,
        "today_events": sum(int(x["checkin_done"]) + int(x["checkout_done"]) for x in rows),
        "today": {
            "total": len(active_rows),
            "arrived": sum(1 for x in active_rows if x["checkin_done"]),
            "absent": sum(1 for x in active_rows if not x["checkin_done"]),
            "left": sum(1 for x in active_rows if x["checkout_done"]),
            "not_left": sum(1 for x in active_rows if x["checkin_done"] and not x["checkout_done"]),
            "late": sum(1 for x in active_rows if x["late"]),
            "early_leave": sum(1 for x in active_rows if x["early_leave"]),
            "pending_review": sum(1 for x in active_rows if x["pending_review"]),
            "exempt": sum(1 for x in rows if x["employment_status"] != "active"),
        },
    }


@router.get("/organization-dashboard")
def organization_dashboard(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    organizations = list(db.scalars(select(Organization).where(Organization.is_active.is_(True)).order_by(Organization.name)).all())
    if admin.role != "super_admin":
        allowed = org_ids(admin); organizations = [o for o in organizations if o.id in allowed]
    result = []
    for org in organizations:
        rows = _today_rows(db, admin, organization_id=org.id)
        active = [x for x in rows if x["employment_status"] == "active"]
        result.append({
            "organization_id": org.id, "organization_name": org.name,
            "total": len(active), "arrived": sum(x["checkin_done"] for x in active),
            "absent": sum(not x["checkin_done"] for x in active),
            "left": sum(x["checkout_done"] for x in active),
            "late": sum(x["late"] for x in active), "early_leave": sum(x["early_leave"] for x in active),
            "pending_review": sum(x["pending_review"] for x in active),
        })
    return result


@router.get("/organizations")
def list_organizations(admin: AdminUser = Depends(require_permission("org.read")), db: Session = Depends(get_db)):
    q = select(Organization).order_by(Organization.name)
    if admin.role != "super_admin": q = q.where(Organization.id.in_(list(org_ids(admin))))
    return list(db.scalars(q).all())


@router.post("/organizations")
def create_organization(body: OrganizationCreate, admin: AdminUser = Depends(require_permission("org.create")), db: Session = Depends(get_db)):
    if db.scalar(select(Organization).where((Organization.name == body.name) | (Organization.code == body.code.upper()))):
        raise HTTPException(409, "Tashkilot nomi yoki kodi mavjud")
    org = Organization(**body.model_dump())
    org.name = org.name.strip(); org.code = org.code.upper().strip()
    db.add(org); db.flush()
    if admin.role != "super_admin": db.add(AdminOrganization(admin_id=admin.id, organization_id=org.id))
    add_audit(db, admin.id, "organization.create", "organization", str(org.id), body.model_dump())
    db.commit(); db.refresh(org); return org


@router.patch("/organizations/{organization_id}")
def update_organization(organization_id: int, body: OrganizationUpdate, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items(): setattr(org, k, v.upper() if k == "code" and isinstance(v, str) else v)
    add_audit(db, admin.id, "organization.update", "organization", str(org.id), data)
    db.commit(); db.refresh(org); return org


@router.delete("/organizations/{organization_id}")
def delete_organization(organization_id: int, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    org.is_active = False
    add_audit(db, admin.id, "organization.deactivate", "organization", str(org.id))
    db.commit(); return {"detail": "Tashkilot faolsizlantirildi"}


@router.get("/admins")
def list_admins(admin: AdminUser = Depends(require_permission("admin.read")), db: Session = Depends(get_db)):
    rows = db.scalars(select(AdminUser).order_by(AdminUser.created_at.desc())).unique().all()
    if admin.role == "super_admin": return [admin_json(a) for a in rows]
    mine = org_ids(admin); return [admin_json(a) for a in rows if org_ids(a) & mine]


@router.post("/admins")
def create_admin(body: AdminCreate, admin: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin admin yarata oladi")
    if db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip())): raise HTTPException(409, "Login band")
    a = AdminUser(full_name=body.full_name.strip(), username=body.username.lower().strip(), password_hash=hash_password(body.password),
                  role=body.role, permissions=body.permissions, is_approved=body.is_approved,
                  password_changed_at=datetime.now(timezone.utc))
    db.add(a); db.flush()
    for oid in sorted(set(body.organization_ids)):
        if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
        db.add(AdminOrganization(admin_id=a.id, organization_id=oid))
    add_audit(db, admin.id, "admin.create", "admin", str(a.id), {"username": a.username, "role": a.role, "organization_ids": body.organization_ids})
    db.commit(); db.refresh(a); return admin_json(a)


@router.patch("/admins/{admin_id}")
def update_admin(admin_id: int, body: AdminUpdate, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    if target.role == "super_admin" and target.id != actor.id: raise HTTPException(403, "Boshqa Super Adminni o'zgartirib bo'lmaydi")
    data = body.model_dump(exclude_unset=True); orgs = data.pop("organization_ids", None)
    for k, v in data.items(): setattr(target, k, v)
    if orgs is not None:
        target.org_links.clear(); db.flush()
        for oid in sorted(set(orgs)):
            if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
            target.org_links.append(AdminOrganization(organization_id=oid))
    target.token_version += 1
    add_audit(db, actor.id, "admin.update", "admin", str(target.id), body.model_dump(exclude_unset=True))
    db.commit(); db.refresh(target); return admin_json(target)


@router.post("/admins/{admin_id}/approve")
def approve_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_approved = True; target.is_active = True; target.token_version += 1
    add_audit(db, actor.id, "admin.approve", "admin", str(target.id)); db.commit(); return {"detail": "Tasdiqlandi"}


@router.post("/admins/{admin_id}/reset-password")
def reset_admin_password(admin_id: int, body: ResetPassword, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.password_hash = hash_password(body.new_password); target.password_changed_at = datetime.now(timezone.utc)
    target.force_password_change = True; target.token_version += 1
    add_audit(db, actor.id, "admin.reset_password", "admin", str(target.id)); db.commit(); return {"detail": "Parol almashtirildi"}


@router.post("/admins/{admin_id}/terminate-sessions")
def terminate_admin_sessions(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.token_version += 1
    add_audit(db, actor.id, "admin.terminate_sessions", "admin", str(target.id)); db.commit()
    return {"detail": "Barcha sessiyalar tugatildi"}


@router.delete("/admins/{admin_id}")
def deactivate_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_active = False; target.token_version += 1
    add_audit(db, actor.id, "admin.deactivate", "admin", str(target.id)); db.commit(); return {"detail": "Admin faolsizlantirildi"}


@router.get("/employees")
def list_employees(organization_id: int | None = None, status: str | None = None, admin: AdminUser = Depends(require_permission("employee.read")), db: Session = Depends(get_db)):
    q = select(Employee).order_by(Employee.full_name)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Employee.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    if status: q = q.where(Employee.employment_status == status)
    rows = db.scalars(q).all()
    return [{
        "id": e.id, "full_name": e.full_name, "employee_code": e.employee_code, "organization_id": e.organization_id,
        "organization_name": e.organization.name, "is_active": e.is_active, "is_approved": e.is_approved,
        "device_bound": bool(e.device_id), "created_at": e.created_at,
        "registration_outside_area": e.registration_outside_area, "registration_area_note": e.registration_area_note,
        "registration_selfie_available": bool(e.registration_selfie_enc),
        "employment_status": e.employment_status, "status_note": e.status_note, "status_until": e.status_until,
        "archived_at": e.archived_at,
    } for e in rows]


@router.get("/today-status")
def today_status(organization_id: int | None = None, status: str | None = None, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    return _today_rows(db, admin, organization_id=organization_id, status_filter=status)


@router.patch("/employees/{employee_id}")
def update_employee(employee_id: int, body: EmployeeUpdate, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id)
    data = body.model_dump(exclude_unset=True)
    if "organization_id" in data: can_access_org(admin, data["organization_id"])
    if data.get("status_until"):
        try: data["status_until"] = datetime.fromisoformat(data["status_until"])
        except Exception: raise HTTPException(422, "status_until ISO sana/vaqt formatida bo'lishi kerak")
    for k, v in data.items(): setattr(e, k, v)
    if "employment_status" in data:
        e.is_active = data["employment_status"] not in {"terminated", "archived"}
        if data["employment_status"] == "archived": e.archived_at = datetime.now(timezone.utc)
    e.token_version += 1
    add_audit(db, admin.id, "employee.update", "employee", str(e.id), data)
    db.commit(); db.refresh(e); return {"detail": "Saqlandi"}


@router.post("/employees/{employee_id}/approve")
def approve_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.is_approved = True; e.is_active = True; e.employment_status = "active"; e.token_version += 1
    add_audit(db, admin.id, "employee.approve", "employee", str(e.id)); db.commit(); return {"detail": "Tasdiqlandi"}


@router.post("/employees/{employee_id}/reset-device")
def reset_device(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.device_id = None; e.token_version += 1
    add_audit(db, admin.id, "employee.reset_device", "employee", str(e.id)); db.commit(); return {"detail": "Qurilma bog'lanishi bekor qilindi"}


@router.post("/employees/{employee_id}/archive")
def archive_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id)
    e.employment_status = "archived"; e.is_active = False; e.archived_at = datetime.now(timezone.utc); e.token_version += 1
    add_audit(db, admin.id, "employee.archive", "employee", str(e.id)); db.commit(); return {"detail": "Xodim arxivlandi"}


@router.delete("/employees/{employee_id}")
def delete_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    # Historical data is preserved; delete action now archives instead of deleting.
    return archive_employee(employee_id, admin, db)


@router.get("/employees/{employee_id}/history")
def employee_history(employee_id: int, limit: int = Query(1000, ge=1, le=5000), admin: AdminUser = Depends(require_permission("employee.read")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id)
    rows = list(db.scalars(select(Attendance).where(Attendance.employee_id == employee_id).order_by(Attendance.occurred_at.desc()).limit(limit)).all())
    return [{
        "id": r.id, "event_type": r.event_type, "occurred_at": r.occurred_at, "latitude": r.latitude, "longitude": r.longitude,
        "accuracy_m": r.accuracy_m, "is_mocked": r.is_mocked, "face_distance": r.face_distance, "face_threshold": r.face_threshold,
        "anti_spoof_score": r.anti_spoof_score, "schedule_status": r.schedule_status, "minutes_delta": r.minutes_delta,
        "employee_reason": r.employee_reason, "admin_note": r.admin_note, "review_status": r.review_status,
        "suspicious_flags": r.suspicious_flags or [], "selfie_available": bool(r.selfie_enc),
    } for r in rows]


@router.get("/employees/{employee_id}/registration-selfie")
def employee_registration_selfie(employee_id: int, admin: AdminUser = Depends(require_permission("employee.read")), db: Session = Depends(get_db)):
    employee = db.get(Employee, employee_id)
    if not employee: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, employee.organization_id)
    if not employee.registration_selfie_enc: raise HTTPException(404, "Ro'yxatdan o'tish selfisi saqlanmagan")
    return Response(content=decrypt_bytes(employee.registration_selfie_enc), media_type="image/jpeg", headers={"Cache-Control": "private, no-store"})


@router.get("/attendance/{attendance_id}/selfie")
def attendance_selfie(attendance_id: int, admin: AdminUser = Depends(require_permission("attendance.read")), db: Session = Depends(get_db)):
    row = db.get(Attendance, attendance_id)
    if not row: raise HTTPException(404, "Davomat yozuvi topilmadi")
    can_access_org(admin, row.organization_id)
    if not row.selfie_enc: raise HTTPException(404, "Bu yozuv uchun selfi saqlanmagan")
    return Response(content=decrypt_bytes(row.selfie_enc), media_type="image/jpeg", headers={"Cache-Control": "private, no-store"})


@router.get("/attendance")
def attendance(organization_id: int | None = None, review_status: str | None = None, limit: int = Query(500, ge=1, le=5000), admin: AdminUser = Depends(require_permission("attendance.read")), db: Session = Depends(get_db)):
    q = select(Attendance).order_by(Attendance.occurred_at.desc()).limit(limit)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Attendance.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Attendance.organization_id.in_(list(org_ids(admin))))
    if review_status: q = q.where(Attendance.review_status == review_status)
    rows = db.scalars(q).all()
    return [{
        "id": r.id, "employee_id": r.employee_id, "employee_name": r.employee.full_name,
        "organization_id": r.organization_id, "organization_name": r.organization.name, "event_type": r.event_type,
        "occurred_at": r.occurred_at, "latitude": r.latitude, "longitude": r.longitude,
        "accuracy_m": r.accuracy_m, "is_mocked": r.is_mocked, "face_distance": r.face_distance,
        "face_threshold": r.face_threshold, "anti_spoof_score": r.anti_spoof_score,
        "schedule_status": r.schedule_status, "minutes_delta": r.minutes_delta,
        "employee_reason": r.employee_reason, "admin_note": r.admin_note, "review_status": r.review_status,
        "suspicious_flags": r.suspicious_flags or [], "selfie_available": bool(r.selfie_enc),
    } for r in rows]


@router.patch("/attendance/{attendance_id}/note")
def attendance_note(attendance_id: int, body: AttendanceNoteUpdate, admin: AdminUser = Depends(require_permission("attendance.manage")), db: Session = Depends(get_db)):
    row = db.get(Attendance, attendance_id)
    if not row: raise HTTPException(404, "Davomat topilmadi")
    can_access_org(admin, row.organization_id)
    row.admin_note = body.admin_note.strip() or None
    add_audit(db, admin.id, "attendance.note", "attendance", str(row.id), {"admin_note": row.admin_note})
    db.commit(); return {"detail": "Izoh saqlandi"}


@router.patch("/attendance/{attendance_id}/review")
def attendance_review(attendance_id: int, body: AttendanceReviewUpdate, admin: AdminUser = Depends(require_permission("attendance.manage")), db: Session = Depends(get_db)):
    row = db.get(Attendance, attendance_id)
    if not row: raise HTTPException(404, "Davomat topilmadi")
    can_access_org(admin, row.organization_id)
    row.review_status = body.review_status; row.reviewed_by_admin_id = admin.id; row.reviewed_at = datetime.now(timezone.utc)
    if body.admin_note is not None: row.admin_note = body.admin_note.strip() or None
    add_audit(db, admin.id, "attendance.review", "attendance", str(row.id), {"review_status": row.review_status, "note": row.admin_note})
    db.commit(); return {"detail": "Tekshiruv holati saqlandi"}


@router.get("/stats/employees")
def employee_stats(start_date: str, end_date: str, organization_id: int | None = None, employee_id: int | None = None,
                   admin: AdminUser = Depends(require_permission("attendance.read")), db: Session = Depends(get_db)):
    start = _parse_date(start_date, "start_date"); end = _parse_date(end_date, "end_date")
    if end < start: raise HTTPException(422, "end_date start_date dan oldin")
    q = select(Employee).where(Employee.is_active.is_(True) | (Employee.employment_status == "archived"))
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Employee.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    if employee_id: q = q.where(Employee.id == employee_id)
    employees = list(db.scalars(q).all())
    result = []
    for e in employees:
        s_utc, e_utc, _ = _org_day_bounds(e.organization, start)
        _, end_utc, _ = _org_day_bounds(e.organization, end)
        rows = list(db.scalars(select(Attendance).where(Attendance.employee_id == e.id, Attendance.occurred_at >= s_utc, Attendance.occurred_at < end_utc, Attendance.review_status != "rejected")).all())
        days = set(); late = early = late_min = early_min = 0
        for r in rows:
            tz = _org_day_bounds(e.organization)[2]
            if r.event_type == "checkin": days.add(r.occurred_at.astimezone(tz).date())
            if r.schedule_status == "late": late += 1; late_min += r.minutes_delta or 0
            if r.schedule_status == "early_leave": early += 1; early_min += r.minutes_delta or 0
        result.append({"employee_id": e.id, "employee_name": e.full_name, "organization_name": e.organization.name,
                       "worked_days": len(days), "late_count": late, "late_minutes": late_min,
                       "early_leave_count": early, "early_leave_minutes": early_min, "events": len(rows)})
    return result


@router.get("/reports/monthly.xlsx")
def report_monthly(organization_id: int, year: int, month: int, admin: AdminUser = Depends(require_permission("report.read")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    if month < 1 or month > 12: raise HTTPException(422, "Oy 1..12 bo'lishi kerak")
    data = monthly_xlsx(db, organization_id, year, month)
    return Response(content=data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="davomat_{organization_id}_{year}_{month:02d}.xlsx"'})


@router.get("/reports/range.xlsx")
def report_range(organization_id: int, start_date: str, end_date: str, admin: AdminUser = Depends(require_permission("report.read")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    start = _parse_date(start_date, "start_date"); end = _parse_date(end_date, "end_date")
    data = range_xlsx(db, [organization_id], start, end)
    return Response(content=data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="davomat_{organization_id}_{start}_{end}.xlsx"'})


@router.get("/reports/all-organizations.xlsx")
def report_all(start_date: str, end_date: str, admin: AdminUser = Depends(require_permission("report.read")), db: Session = Depends(get_db)):
    start = _parse_date(start_date, "start_date"); end = _parse_date(end_date, "end_date")
    if admin.role == "super_admin":
        ids = list(db.scalars(select(Organization.id).where(Organization.is_active.is_(True))).all())
    else:
        ids = sorted(org_ids(admin))
    data = range_xlsx(db, ids, start, end, all_orgs=True)
    return Response(content=data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="davomat_barcha_{start}_{end}.xlsx"'})


@router.post("/maintenance/cleanup-selfies")
def cleanup_selfies(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    result = cleanup_expired_selfies(db)
    add_audit(db, admin.id, "maintenance.cleanup_selfies", "system", "selfies", result)
    return result


@router.get("/report-columns")
def report_columns(_: AdminUser = Depends(current_admin)):
    return {"available": DEFAULT_REPORT_COLUMNS}


@router.get("/audit")
def audit(limit: int = Query(500, ge=1, le=3000), admin: AdminUser = Depends(require_permission("audit.read")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)).all()
    return [{"id": x.id, "actor_admin_id": x.actor_admin_id, "action": x.action, "target_type": x.target_type,
             "target_id": x.target_id, "details": x.details, "created_at": x.created_at} for x in rows]

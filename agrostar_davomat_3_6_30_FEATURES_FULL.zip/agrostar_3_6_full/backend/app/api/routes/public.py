from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Organization
from app.schemas.common import OrganizationOut
from app.services.mobile_config import get_mobile_config

router = APIRouter(prefix="/public", tags=["public"])

@router.get("/organizations", response_model=list[OrganizationOut])
def organizations(db: Session = Depends(get_db)):
    return list(db.scalars(select(Organization).where(Organization.is_active.is_(True)).order_by(Organization.name)).all())

@router.get("/mobile-config")
def mobile_config(db: Session = Depends(get_db)):
    """Mobil ilovalar uchun serverdan boshqariladigan feature-flaglar.

    Shu endpoint tufayli login rejimi, ro'yxatdan o'tish hududi checkboxi,
    maintenance xabari kabi mayda UX o'zgarishlari APK qayta build qilmasdan
    Super Admin panelidan o'zgartirilishi mumkin.
    """
    return get_mobile_config(db)

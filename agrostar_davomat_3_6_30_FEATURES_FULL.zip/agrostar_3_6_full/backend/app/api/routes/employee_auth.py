import secrets
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.db.session import get_db
from app.models.entities import Employee, Organization
from app.schemas.common import TokenPair, RefreshRequest
from app.services.biometric_crypto import encrypt_embedding, decrypt_embedding, encrypt_bytes
from app.services.face import extract_embedding, analyze_selfie, verify_embedding, FaceError
from app.services.mobile_config import get_mobile_config

router = APIRouter(prefix="/employee-auth", tags=["employee-auth"])


def _login_probe(image_bytes: bytes, org: Organization) -> list[float]:
    policy = getattr(org, "anti_spoof_policy", "required") or "required"
    strict = policy == "required"
    soft = policy == "soft"
    embedding, _, _ = analyze_selfie(image_bytes, require_liveness=strict, soft_liveness=soft)
    return embedding


def tokens(emp: Employee) -> TokenPair:
    return TokenPair(
        access_token=create_access_token(str(emp.id), "employee", emp.token_version),
        refresh_token=create_refresh_token(str(emp.id), "employee", emp.token_version),
    )

@router.post("/register", response_model=TokenPair)
async def register(
    full_name: str = Form(...),
    organization_id: int = Form(...),
    device_id: str = Form(...),
    registration_outside_area: bool = Form(False),
    registration_area_note: str | None = Form(None),
    selfie: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    cfg = get_mobile_config(db)
    if not cfg.get("allow_new_employee_registration", True):
        raise HTTPException(403, "Yangi xodim ro'yxatdan o'tishi vaqtincha o'chirilgan")
    name = " ".join(full_name.split()).strip()
    if len(name) < 3:
        raise HTTPException(422, "F.I.O. noto'g'ri")
    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    area_note = " ".join((registration_area_note or "").split()).strip()
    if registration_outside_area and len(area_note) < 3:
        raise HTTPException(422, "Belgilangan hududda emas bo'lsangiz, sababini yozing")
    if not registration_outside_area:
        area_note = ""
    try:
        selfie_bytes = await selfie.read()
        embedding, _, registration_selfie_jpeg = analyze_selfie(selfie_bytes, require_liveness=True)
    except FaceError as exc:
        raise HTTPException(422, str(exc))
    existing_people = db.scalars(select(Employee).where(Employee.organization_id == organization_id)).all()
    for existing in existing_people:
        try:
            matched, _, _ = verify_embedding(decrypt_embedding(existing.face_embedding_enc), embedding, threshold=org.face_threshold_override)
        except Exception:
            matched = False
        if matched:
            raise HTTPException(409, "Bu xodim avval ro'yxatdan o'tgan. Qayta ro'yxatdan o'tish mumkin emas; 'Oldin ro'yxatdan o'tganman' orqali kiring yoki Admin orqali profil holatini tiklang.")
    emp = Employee(
        full_name=name,
        employee_code=f"EMP-{secrets.token_hex(4).upper()}",
        organization_id=organization_id,
        face_embedding_enc=encrypt_embedding(embedding),
        device_id=device_id,
        registration_outside_area=registration_outside_area,
        registration_area_note=area_note or None,
        registration_selfie_enc=encrypt_bytes(registration_selfie_jpeg),
        is_approved=org.employee_auto_approve,
    )
    db.add(emp); db.commit(); db.refresh(emp)
    return tokens(emp)


@router.post("/login-face", response_model=TokenPair)
async def login_face(
    organization_id: int = Form(...),
    device_id: str = Form(...),
    selfie: UploadFile = File(...),
    full_name: str | None = Form(None),
    db: Session = Depends(get_db),
):
    """Oldin ro'yxatdan o'tgan xodimni jonli selfi orqali aniqlaydi.

    Standart rejimda F.I.O. talab qilinmaydi: tashkilotdagi faol xodimlarning
    embeddinglari orasidan eng yaxshi yagona moslik topiladi. Remote config
    orqali eski `name_and_face` rejimiga APK qayta build qilmasdan qaytish mumkin.
    """
    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")

    cfg = get_mobile_config(db)
    name = " ".join((full_name or "").split()).strip()
    require_name = cfg.get("employee_relogin_mode") == "name_and_face"
    if require_name and len(name) < 3:
        raise HTTPException(422, "F.I.O. talab qilinadi")

    query = select(Employee).where(
        Employee.organization_id == organization_id,
        Employee.is_active.is_(True),
    )
    if name:
        query = query.where(Employee.full_name.ilike(name))
    candidates = list(db.scalars(query).all())
    if not candidates:
        raise HTTPException(404, "Mos xodim topilmadi")

    try:
        probe = _login_probe(await selfie.read(), org)
    except FaceError as exc:
        raise HTTPException(422, str(exc))

    matches: list[tuple[float, Employee, float]] = []
    for candidate in candidates:
        try:
            ok, distance, threshold = verify_embedding(
                decrypt_embedding(candidate.face_embedding_enc), probe, threshold=org.face_threshold_override
            )
        except Exception:
            ok, distance, threshold = False, 999.0, 0.0
        if ok:
            matches.append((distance, candidate, threshold))

    if not matches:
        if name:
            raise HTTPException(403, "Yuz kiritilgan F.I.O. profiliga mos kelmadi")
        raise HTTPException(403, "Yuz bo'yicha xodim aniqlanmadi")

    matches.sort(key=lambda x: x[0])
    best_distance, emp, _ = matches[0]
    # F.I.O.siz biometrik qidiruvda juda yaqin ikkita moslik bo'lsa xodimni
    # taxmin bilan tanlamaymiz. Ixtiyoriy F.I.O. fallback shuni aniqlashtiradi.
    if not name and len(matches) > 1:
        second_distance = matches[1][0]
        if second_distance - best_distance < 0.025:
            raise HTTPException(
                409,
                detail={
                    "code": "ambiguous_face",
                    "message": "Yuz bo'yicha xodimni aniq ajratib bo'lmadi. F.I.O. bilan aniqlashtirib yana urinib ko'ring.",
                },
            )

    if emp.device_id != device_id:
        emp.device_id = device_id
        emp.token_version += 1
        db.commit(); db.refresh(emp)
    return tokens(emp)


@router.post("/relink", response_model=TokenPair)
async def relink(full_name: str = Form(...), organization_id: int = Form(...), device_id: str = Form(...), selfie: UploadFile = File(...), db: Session = Depends(get_db)):
    name = " ".join(full_name.split()).strip()
    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    candidates = db.scalars(select(Employee).where(Employee.organization_id == organization_id, Employee.full_name.ilike(name), Employee.is_active.is_(True))).all()
    if not candidates:
        raise HTTPException(404, "Xodim topilmadi")
    try:
        probe = _login_probe(await selfie.read(), org)
    except FaceError as exc:
        raise HTTPException(422, str(exc))
    best = None
    best_distance = 999.0
    for candidate in candidates:
        ok, distance, _ = verify_embedding(decrypt_embedding(candidate.face_embedding_enc), probe, threshold=org.face_threshold_override)
        if ok and distance < best_distance:
            best, best_distance = candidate, distance
    if best is None:
        raise HTTPException(403, "F.I.O. bo'yicha topilgan profillarning hech biriga yuz mos kelmadi")
    emp = best
    if emp.device_id != device_id:
        emp.device_id = device_id
        emp.token_version += 1
        db.commit(); db.refresh(emp)
    return tokens(emp)

@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        p = decode_token(body.refresh_token)
        if p.get("actor") != "employee" or p.get("typ") != "refresh": raise ValueError()
    except Exception:
        raise HTTPException(401, "Refresh token yaroqsiz")
    emp = db.get(Employee, int(p["sub"]))
    if not emp or not emp.is_active or emp.token_version != int(p.get("ver", 0)):
        raise HTTPException(401, "Sessiya yaroqsiz")
    return tokens(emp)

from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import verify_password, hash_password, create_access_token, create_refresh_token, decode_token
from app.db.session import get_db
from app.models.entities import AdminUser, AdminOrganization, Organization
from app.schemas.admin import AdminLogin, AdminRegisterRequest
from app.schemas.common import TokenPair, RefreshRequest
from app.services.mobile_config import get_security_config
from app.services.audit import add_audit

router = APIRouter(prefix="/admin-auth", tags=["admin-auth"])


def tokens(admin: AdminUser) -> TokenPair:
    return TokenPair(
        access_token=create_access_token(str(admin.id), "admin", admin.token_version),
        refresh_token=create_refresh_token(str(admin.id), "admin", admin.token_version),
    )


@router.post("/register-request")
def register_request(body: AdminRegisterRequest, db: Session = Depends(get_db)):
    if db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip())):
        raise HTTPException(409, "Bu login band")
    org = db.get(Organization, body.organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    admin = AdminUser(full_name=" ".join(body.full_name.split()), username=body.username.lower().strip(),
                      password_hash=hash_password(body.password), role="auditor", permissions=[], is_approved=False,
                      password_changed_at=datetime.now(timezone.utc))
    db.add(admin); db.flush()
    db.add(AdminOrganization(admin_id=admin.id, organization_id=org.id))
    db.commit()
    return {"detail": "So'rov yuborildi. Super Admin tasdiqlashi kerak.", "admin_id": admin.id}


@router.post("/login", response_model=TokenPair)
def login(body: AdminLogin, db: Session = Depends(get_db)):
    username = body.username.lower().strip()
    admin = db.scalar(select(AdminUser).where(AdminUser.username == username))
    security = get_security_config(db)
    now = datetime.now(timezone.utc)
    if admin and admin.locked_until and admin.locked_until > now:
        minutes = max(1, int((admin.locked_until - now).total_seconds() // 60) + 1)
        raise HTTPException(429, f"Ko'p noto'g'ri urinish. {minutes} daqiqadan keyin qayta urinib ko'ring")
    if not admin or not verify_password(body.password, admin.password_hash):
        if admin:
            admin.failed_login_attempts = int(admin.failed_login_attempts or 0) + 1
            max_attempts = int(security.get("max_failed_login_attempts", 5))
            if admin.failed_login_attempts >= max_attempts:
                admin.locked_until = now + timedelta(minutes=int(security.get("lockout_minutes", 15)))
                admin.failed_login_attempts = 0
            add_audit(db, admin.id, "admin.login_failed", "admin", str(admin.id), {"username": username})
            db.commit()
        raise HTTPException(401, "Login yoki parol noto'g'ri")
    if not admin.is_active:
        raise HTTPException(403, "Admin bloklangan")
    if not admin.is_approved:
        raise HTTPException(403, "Super Admin tasdiqlashi kutilmoqda")
    admin.failed_login_attempts = 0
    admin.locked_until = None
    admin.last_login_at = now
    expiry_days = int(security.get("password_expiry_days", 90))
    if expiry_days > 0 and admin.password_changed_at and admin.password_changed_at + timedelta(days=expiry_days) <= now:
        admin.force_password_change = True
    add_audit(db, admin.id, "admin.login_success", "admin", str(admin.id))
    db.commit()
    return tokens(admin)


@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        p = decode_token(body.refresh_token)
        if p.get("actor") != "admin" or p.get("typ") != "refresh": raise ValueError()
    except Exception:
        raise HTTPException(401, "Refresh token yaroqsiz")
    admin = db.get(AdminUser, int(p["sub"]))
    if not admin or not admin.is_active or not admin.is_approved or admin.token_version != int(p.get("ver", 0)):
        raise HTTPException(401, "Sessiya yaroqsiz")
    return tokens(admin)

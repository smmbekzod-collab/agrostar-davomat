from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session
from zoneinfo import ZoneInfo
from app.api.deps import current_employee
from app.db.session import get_db
from app.models.entities import Employee, Attendance, AttendanceType
from app.services.biometric_crypto import decrypt_embedding, encrypt_bytes
from app.services.face import analyze_selfie, verify_embedding, FaceError
from app.services.geo import haversine_km
from app.services.mobile_config import get_mobile_config
from app.services.retention import cleanup_expired_selfies

router = APIRouter(prefix="/attendance", tags=["attendance"])


def _schedule_status(emp: Employee, event_type: str, occurred_at: datetime) -> tuple[str | None, int | None]:
    org = emp.organization
    try:
        tz = ZoneInfo(org.timezone or "Asia/Tashkent")
    except Exception:
        tz = ZoneInfo("Asia/Tashkent")
    local = occurred_at.astimezone(tz)
    try:
        sh, sm = [int(x) for x in (org.work_start or "09:00").split(":", 1)]
        eh, em = [int(x) for x in (org.work_end or "18:00").split(":", 1)]
    except Exception:
        sh, sm, eh, em = 9, 0, 18, 0
    if event_type == AttendanceType.checkin.value:
        if not getattr(org, "late_monitoring_enabled", True):
            return "checkin", 0
        scheduled = local.replace(hour=sh, minute=sm, second=0, microsecond=0) + timedelta(minutes=org.grace_minutes or 0)
        if local <= scheduled:
            return "on_time", 0
        minutes = max(1, int((local - scheduled).total_seconds() // 60))
        return "late", minutes
    if not getattr(org, "early_leave_monitoring_enabled", True):
        return "checkout", 0
    scheduled_end = local.replace(hour=eh, minute=em, second=0, microsecond=0)
    if local < scheduled_end:
        minutes = max(1, int((scheduled_end - local).total_seconds() // 60))
        return "early_leave", minutes
    return "normal_checkout", 0


def _reason_mode(emp: Employee, event_type: str, status: str | None) -> str:
    if event_type == "checkin" and status == "late":
        return getattr(emp.organization, "late_reason_mode", "optional") or "optional"
    if event_type == "checkout" and status == "early_leave":
        return getattr(emp.organization, "early_leave_reason_mode", "optional") or "optional"
    return "off"


@router.get("/context")
def attendance_context(event_type: str, emp: Employee = Depends(current_employee)):
    if event_type not in {"checkin", "checkout"}:
        raise HTTPException(422, "event_type checkin yoki checkout bo'lishi kerak")
    now = datetime.now(timezone.utc)
    status, minutes = _schedule_status(emp, event_type, now)
    mode = _reason_mode(emp, event_type, status)
    return {
        "event_type": event_type,
        "schedule_status": status,
        "minutes_delta": minutes,
        "reason_mode": mode,
        "reason_required": mode == "required",
        "reason_prompt": (
            f"{minutes or 0} daqiqa kechikish sababini yozing" if status == "late"
            else f"{minutes or 0} daqiqa erta ketish sababini yozing" if status == "early_leave"
            else ""
        ),
    }


async def _record(event_type: str, latitude: float, longitude: float, accuracy_m: float | None, is_mocked: bool,
                  selfie: UploadFile, emp: Employee, device_id: str, db: Session, reason: str | None = None):
    if not emp.is_approved:
        raise HTTPException(403, "Admin xodim ro'yxatdan o'tishini hali tasdiqlamagan")
    if getattr(emp, "employment_status", "active") != "active":
        labels = {"leave":"Ta’til", "business_trip":"Xizmat safari", "sick":"Kasallik", "terminated":"Ishdan bo‘shagan", "archived":"Arxiv"}
        raise HTTPException(403, f"Davomat vaqtincha bloklangan. Holat: {labels.get(emp.employment_status, emp.employment_status)}")
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise HTTPException(422, "GPS koordinata noto'g'ri")
    if accuracy_m is not None and accuracy_m > 5000:
        raise HTTPException(422, "GPS aniqligi juda past")

    org = emp.organization
    occurred_at = datetime.now(timezone.utc)
    schedule_status, minutes_delta = _schedule_status(emp, event_type, occurred_at)
    reason_mode = _reason_mode(emp, event_type, schedule_status)
    cleaned_reason = " ".join((reason or "").split()).strip()
    if reason_mode == "required" and len(cleaned_reason) < 3:
        label = "Kechikish" if schedule_status == "late" else "Erta ketish"
        raise HTTPException(422, f"{label} sababini yozish majburiy")
    if reason_mode == "off":
        cleaned_reason = ""

    anti_policy = getattr(org, "anti_spoof_policy", "required") or "required"
    strict_liveness = anti_policy == "required"
    soft_liveness = anti_policy == "soft"
    try:
        selfie_bytes = await selfie.read()
        probe, anti_score, selfie_jpeg = analyze_selfie(
            selfie_bytes,
            require_liveness=strict_liveness,
            soft_liveness=soft_liveness,
        )
    except FaceError as exc:
        raise HTTPException(422, str(exc))

    threshold = getattr(org, "face_threshold_override", None)
    reference = decrypt_embedding(emp.face_embedding_enc)
    ok, distance, actual_threshold = verify_embedding(reference, probe, threshold=threshold)
    margin = float(getattr(org, "suspicious_face_margin", 0.03) or 0.03)
    suspicious: list[str] = []
    if not ok:
        # Borderline face matches can be recorded as pending instead of being silently lost.
        if distance <= actual_threshold + margin:
            suspicious.append("face_near_threshold")
        else:
            cfg = get_mobile_config(db)
            msg = cfg.get("message_texts", {}).get("face_fail", "Yuz xodimga mos kelmadi")
            raise HTTPException(403, f"{msg} ({distance:.3f} > {actual_threshold:.3f})")
    elif actual_threshold - distance <= margin:
        suspicious.append("face_near_threshold")

    accuracy_limit = float(getattr(org, "suspicious_accuracy_m", 80.0) or 80.0)
    if accuracy_m is None:
        suspicious.append("gps_accuracy_unknown")
    elif accuracy_m > accuracy_limit:
        suspicious.append("gps_accuracy_low")
    if is_mocked:
        suspicious.append("mock_gps")
    if soft_liveness and (anti_score is None or anti_score < 0.5):
        suspicious.append("anti_spoof_uncertain")

    last = db.scalar(
        select(Attendance)
        .where(Attendance.employee_id == emp.id, Attendance.review_status != "rejected")
        .order_by(Attendance.occurred_at.desc()).limit(1)
    )
    if event_type == AttendanceType.checkin.value and last and last.event_type == AttendanceType.checkin.value:
        raise HTTPException(409, "Oldin ishga kelish qayd etilgan. Avval ishdan ketishni bosing.")
    if event_type == AttendanceType.checkout.value and (not last or last.event_type != AttendanceType.checkin.value):
        raise HTTPException(409, "Ishdan ketishdan oldin ishga kelish qaydi bo'lishi kerak.")

    if last and last.latitude is not None and last.longitude is not None:
        last_at = last.occurred_at if last.occurred_at.tzinfo else last.occurred_at.replace(tzinfo=timezone.utc)
        hours = abs((occurred_at - last_at).total_seconds()) / 3600
        if hours <= 4:
            jump = haversine_km(last.latitude, last.longitude, latitude, longitude)
            if jump > float(getattr(org, "unusual_distance_km", 50.0) or 50.0):
                suspicious.append("unusual_location_jump")

    review_status = "pending_review" if suspicious else "approved"
    row = Attendance(
        employee_id=emp.id, organization_id=emp.organization_id, event_type=event_type,
        occurred_at=occurred_at, latitude=latitude, longitude=longitude,
        accuracy_m=accuracy_m, is_mocked=is_mocked, face_distance=distance,
        face_threshold=actual_threshold, anti_spoof_score=anti_score,
        schedule_status=schedule_status, minutes_delta=minutes_delta,
        employee_reason=cleaned_reason or None,
        review_status=review_status, suspicious_flags=suspicious,
        device_id=device_id, selfie_enc=encrypt_bytes(selfie_jpeg),
    )
    db.add(row); db.commit(); db.refresh(row)
    cleanup_expired_selfies(db)
    cfg = get_mobile_config(db)
    messages = cfg.get("message_texts", {})
    if review_status == "pending_review":
        message = messages.get("pending_review", "Davomat admin tekshiruviga yuborildi")
    else:
        message = messages.get("checkin_success" if event_type == "checkin" else "checkout_success", "Davomat saqlandi")
    return {
        "id": row.id, "event_type": row.event_type, "occurred_at": row.occurred_at,
        "latitude": row.latitude, "longitude": row.longitude, "face_distance": distance,
        "face_threshold": actual_threshold, "anti_spoof_score": anti_score,
        "schedule_status": schedule_status, "minutes_delta": minutes_delta,
        "employee_reason": row.employee_reason, "review_status": review_status,
        "suspicious_flags": suspicious, "message": message,
    }


@router.post("/checkin")
async def checkin(latitude: float = Form(...), longitude: float = Form(...), accuracy_m: float | None = Form(None),
                  is_mocked: bool = Form(False), reason: str | None = Form(None), selfie: UploadFile = File(...),
                  x_device_id: str = Header(..., alias="X-Device-ID"), emp: Employee = Depends(current_employee), db: Session = Depends(get_db)):
    return await _record("checkin", latitude, longitude, accuracy_m, is_mocked, selfie, emp, x_device_id, db, reason)


@router.post("/checkout")
async def checkout(latitude: float = Form(...), longitude: float = Form(...), accuracy_m: float | None = Form(None),
                   is_mocked: bool = Form(False), reason: str | None = Form(None), selfie: UploadFile = File(...),
                   x_device_id: str = Header(..., alias="X-Device-ID"), emp: Employee = Depends(current_employee), db: Session = Depends(get_db)):
    return await _record("checkout", latitude, longitude, accuracy_m, is_mocked, selfie, emp, x_device_id, db, reason)

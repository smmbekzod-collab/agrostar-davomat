from __future__ import annotations
from copy import deepcopy
from sqlalchemy.orm import Session
from app.models.entities import SystemSetting

MOBILE_CONFIG_KEY = "mobile_config"
SECURITY_CONFIG_KEY = "security_config"

DEFAULT_MOBILE_CONFIG: dict = {
    "version": 2,
    "employee_relogin_mode": "face_only",
    "employee_name_fallback_enabled": True,
    "employee_registration_area_toggle": True,
    "allow_new_employee_registration": True,
    "maintenance_enabled": False,
    "maintenance_message": "",
    "relogin_help_text": (
        "Oldin ro‘yxatdan o‘tgan bo‘lsangiz, tashkilotni tanlang va jonli selfi oling. "
        "Tizim yuzingiz orqali akkauntingizni avtomatik aniqlaydi."
    ),
    "employee_min_version": "3.6.0",
    "employee_latest_version": "3.6.0",
    "admin_min_version": "3.6.0",
    "admin_latest_version": "3.6.0",
    "update_message": "Ilovaning yangi versiyasi mavjud.",
    "update_url": "",
    "banner_enabled": False,
    "banner_message": "",
    "message_texts": {
        "checkin_success": "Ishga kelish muvaffaqiyatli qayd etildi",
        "checkout_success": "Ishdan ketish muvaffaqiyatli qayd etildi",
        "pending_review": "Davomat saqlandi va admin tekshiruviga yuborildi",
        "low_gps": "GPS aniqligi past. Ochiq joyda qayta urinib ko‘ring.",
        "face_fail": "Yuz mosligi yetarli emas.",
        "maintenance": "Texnik ishlar olib borilmoqda.",
    },
}

DEFAULT_SECURITY_CONFIG: dict = {
    "max_failed_login_attempts": 5,
    "lockout_minutes": 15,
    "password_expiry_days": 90,
}


def _get_setting(db: Session, key: str, default: dict) -> dict:
    cfg = deepcopy(default)
    row = db.get(SystemSetting, key)
    if row and isinstance(row.value, dict):
        cfg.update(row.value)
    return cfg


def _save_setting(db: Session, key: str, default: dict, patch: dict) -> dict:
    cfg = _get_setting(db, key, default)
    cfg.update({k: v for k, v in patch.items() if v is not None})
    row = db.get(SystemSetting, key)
    if row is None:
        row = SystemSetting(key=key, value=cfg)
        db.add(row)
    else:
        row.value = cfg
    db.commit()
    db.refresh(row)
    return _get_setting(db, key, default)


def get_mobile_config(db: Session) -> dict:
    cfg = _get_setting(db, MOBILE_CONFIG_KEY, DEFAULT_MOBILE_CONFIG)
    if cfg.get("employee_relogin_mode") not in {"face_only", "name_and_face"}:
        cfg["employee_relogin_mode"] = "face_only"
    if not isinstance(cfg.get("message_texts"), dict):
        cfg["message_texts"] = deepcopy(DEFAULT_MOBILE_CONFIG["message_texts"])
    else:
        merged = deepcopy(DEFAULT_MOBILE_CONFIG["message_texts"])
        merged.update(cfg["message_texts"])
        cfg["message_texts"] = merged
    return cfg


def save_mobile_config(db: Session, patch: dict) -> dict:
    if "message_texts" in patch and patch["message_texts"] is not None:
        merged = get_mobile_config(db).get("message_texts", {}).copy()
        merged.update(patch["message_texts"])
        patch = {**patch, "message_texts": merged}
    result = _save_setting(db, MOBILE_CONFIG_KEY, DEFAULT_MOBILE_CONFIG, patch)
    if result.get("employee_relogin_mode") not in {"face_only", "name_and_face"}:
        result["employee_relogin_mode"] = "face_only"
    return result


def get_security_config(db: Session) -> dict:
    return _get_setting(db, SECURITY_CONFIG_KEY, DEFAULT_SECURITY_CONFIG)


def save_security_config(db: Session, patch: dict) -> dict:
    return _save_setting(db, SECURITY_CONFIG_KEY, DEFAULT_SECURITY_CONFIG, patch)

from __future__ import annotations
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Attendance, Employee, Organization


def cleanup_expired_selfies(db: Session) -> dict:
    """Delete old encrypted selfie blobs according to each organization's policy.

    retention_days=0 means keep permanently. Metadata and attendance rows are never deleted.
    """
    now = datetime.now(timezone.utc)
    deleted_attendance = 0
    deleted_registration = 0
    orgs = list(db.scalars(select(Organization)).all())
    for org in orgs:
        days = int(org.selfie_retention_days or 0)
        if days <= 0:
            continue
        cutoff = now - timedelta(days=days)
        rows = list(db.scalars(
            select(Attendance).where(
                Attendance.organization_id == org.id,
                Attendance.occurred_at < cutoff,
                Attendance.selfie_enc.is_not(None),
            )
        ).all())
        for row in rows:
            row.selfie_enc = None
            deleted_attendance += 1
        employees = list(db.scalars(
            select(Employee).where(
                Employee.organization_id == org.id,
                Employee.created_at < cutoff,
                Employee.registration_selfie_enc.is_not(None),
            )
        ).all())
        for employee in employees:
            employee.registration_selfie_enc = None
            deleted_registration += 1
    if deleted_attendance or deleted_registration:
        db.commit()
    return {"attendance_selfies_deleted": deleted_attendance, "registration_selfies_deleted": deleted_registration}

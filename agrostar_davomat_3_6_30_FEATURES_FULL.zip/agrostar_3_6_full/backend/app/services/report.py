from collections import defaultdict
from io import BytesIO
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Attendance, Organization, Employee, DEFAULT_REPORT_COLUMNS
from app.services.biometric_crypto import decrypt_bytes

COLUMN_LABELS = {
    "organization": "Tashkilot",
    "employee_code": "Xodim kodi",
    "employee_name": "Xodim",
    "registration_area": "Ro'yxatdan o'tish hududi",
    "registration_note": "Ro'yxat izohi",
    "event_type": "Turi",
    "selfie": "Selfi",
    "local_time": "Mahalliy vaqt",
    "utc_time": "UTC vaqt",
    "schedule_status": "Status",
    "minutes_delta": "Daqiqa",
    "employee_reason": "Xodim sababi",
    "admin_note": "Admin izohi",
    "review_status": "Tekshiruv holati",
    "suspicious_flags": "Shubhali belgilar",
    "latitude": "Latitude",
    "longitude": "Longitude",
    "accuracy_m": "Aniqlik(m)",
    "mock_gps": "Mock GPS",
    "face_distance": "Face distance",
    "face_threshold": "Threshold",
    "anti_spoof_score": "Anti-spoof score",
    "google_maps": "Google Maps",
}
ALL_REPORT_COLUMNS = ["organization"] + list(DEFAULT_REPORT_COLUMNS) + ["utc_time"]


def _tz(org: Organization) -> ZoneInfo:
    try:
        return ZoneInfo(org.timezone or "Asia/Tashkent")
    except Exception:
        return ZoneInfo("Asia/Tashkent")


def _registration_label(employee: Employee) -> str:
    return "Belgilangan hududda emas" if employee.registration_outside_area else "Belgilangan hududda"


def _range_utc(start: date, end: date, tz: ZoneInfo) -> tuple[datetime, datetime]:
    start_local = datetime.combine(start, datetime.min.time(), tzinfo=tz)
    end_local = datetime.combine(end + timedelta(days=1), datetime.min.time(), tzinfo=tz)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc)


def _row_value(col: str, r: Attendance, org: Organization, local_at: datetime):
    emp = r.employee
    values = {
        "organization": org.name,
        "employee_code": emp.employee_code if emp else "",
        "employee_name": emp.full_name if emp else str(r.employee_id),
        "registration_area": _registration_label(emp) if emp else "",
        "registration_note": (emp.registration_area_note or "") if emp else "",
        "event_type": r.event_type,
        "selfie": "",
        "local_time": local_at.strftime("%d.%m.%Y %H:%M:%S"),
        "utc_time": r.occurred_at.astimezone(timezone.utc).isoformat(),
        "schedule_status": r.schedule_status or "",
        "minutes_delta": r.minutes_delta or 0,
        "employee_reason": r.employee_reason or "",
        "admin_note": r.admin_note or "",
        "review_status": r.review_status or "approved",
        "suspicious_flags": ", ".join(r.suspicious_flags or []),
        "latitude": r.latitude,
        "longitude": r.longitude,
        "accuracy_m": r.accuracy_m,
        "mock_gps": "HA" if r.is_mocked else "YO'Q",
        "face_distance": r.face_distance,
        "face_threshold": r.face_threshold,
        "anti_spoof_score": r.anti_spoof_score,
        "google_maps": f"https://maps.google.com/?q={r.latitude},{r.longitude}",
    }
    return values.get(col, "")


def range_xlsx(db: Session, organization_ids: list[int], start_date: date, end_date: date, *, all_orgs: bool = False) -> bytes:
    if end_date < start_date:
        raise ValueError("Tugash sanasi boshlanish sanasidan oldin")
    orgs = [db.get(Organization, oid) for oid in organization_ids]
    orgs = [o for o in orgs if o]
    if not orgs:
        raise ValueError("Tashkilot topilmadi")

    # Cross-org report uses the union/default set. Single org honors its configurable columns.
    if all_orgs or len(orgs) > 1:
        columns = ["organization"] + list(DEFAULT_REPORT_COLUMNS)
    else:
        columns = list(orgs[0].report_columns or DEFAULT_REPORT_COLUMNS)
    columns = [c for c in columns if c in COLUMN_LABELS]

    wb = Workbook()
    ws = wb.active
    ws.title = "Davomat"
    ws.append([COLUMN_LABELS[c] for c in columns])
    summary = defaultdict(lambda: {
        "org": "", "name": "", "code": "", "checkin_days": set(), "checkouts": 0,
        "late_days": 0, "late_minutes": 0, "early_leave_days": 0, "early_leave_minutes": 0,
        "pending": 0, "rejected": 0,
    })

    for org in orgs:
        tz = _tz(org)
        start_utc, end_utc = _range_utc(start_date, end_date, tz)
        rows = list(db.scalars(
            select(Attendance)
            .where(Attendance.organization_id == org.id)
            .where(Attendance.occurred_at >= start_utc)
            .where(Attendance.occurred_at < end_utc)
            .order_by(Attendance.occurred_at.asc())
        ).all())
        for r in rows:
            local_at = r.occurred_at.astimezone(tz)
            values = [_row_value(c, r, org, local_at) for c in columns]
            ws.append(values)
            excel_row = ws.max_row
            if "selfie" in columns and r.selfie_enc:
                col_idx = columns.index("selfie") + 1
                try:
                    photo = XLImage(BytesIO(decrypt_bytes(r.selfie_enc)))
                    photo.width = 72; photo.height = 72
                    cell = ws.cell(excel_row, col_idx).coordinate
                    ws.add_image(photo, cell)
                    ws.row_dimensions[excel_row].height = 58
                    ws.column_dimensions[ws.cell(1, col_idx).column_letter].width = 14
                except Exception:
                    ws.cell(excel_row, col_idx, "Rasmni joylab bo'lmadi")
            emp = r.employee
            key = (org.id, r.employee_id)
            s = summary[key]
            s["org"] = org.name
            s["name"] = emp.full_name if emp else str(r.employee_id)
            s["code"] = emp.employee_code if emp else ""
            if r.event_type == "checkin":
                s["checkin_days"].add(local_at.date())
                if r.schedule_status == "late":
                    s["late_days"] += 1; s["late_minutes"] += r.minutes_delta or 0
            else:
                s["checkouts"] += 1
                if r.schedule_status == "early_leave":
                    s["early_leave_days"] += 1; s["early_leave_minutes"] += r.minutes_delta or 0
            if r.review_status == "pending_review": s["pending"] += 1
            if r.review_status == "rejected": s["rejected"] += 1

    sum_ws = wb.create_sheet("Xodimlar xulosasi")
    sum_ws.append(["Tashkilot", "Xodim kodi", "F.I.O.", "Ishga kelgan kunlar", "Kechikkan kunlar", "Jami kechikish (daq)", "Ketish yozuvlari", "Erta ketgan kunlar", "Jami erta ketish (daq)", "Tekshiruvda", "Rad etilgan"])
    for _, s in sorted(summary.items(), key=lambda item: (item[1]["org"], item[1]["name"])):
        sum_ws.append([s["org"], s["code"], s["name"], len(s["checkin_days"]), s["late_days"], s["late_minutes"], s["checkouts"], s["early_leave_days"], s["early_leave_minutes"], s["pending"], s["rejected"]])

    roster_ws = wb.create_sheet("Xodimlar ro'yxati")
    roster_ws.append(["Tashkilot", "Xodim kodi", "F.I.O.", "Holati", "Status", "Status izohi", "Tasdiqlangan", "Ro'yxatdan o'tgan vaqt", "Ro'yxatdan o'tish hududi", "Hududdan tashqari sabab / izoh", "Ro'yxatdan o'tish selfisi"])
    for org in orgs:
        tz = _tz(org)
        employees = list(db.scalars(select(Employee).where(Employee.organization_id == org.id).order_by(Employee.full_name)).all())
        for employee in employees:
            created_local = employee.created_at.astimezone(tz) if employee.created_at.tzinfo else employee.created_at.replace(tzinfo=timezone.utc).astimezone(tz)
            roster_ws.append([
                org.name, employee.employee_code, employee.full_name,
                "Faol" if employee.is_active else "Faolsiz", employee.employment_status,
                employee.status_note or "", "HA" if employee.is_approved else "YO'Q",
                created_local.strftime("%d.%m.%Y %H:%M:%S"), _registration_label(employee),
                employee.registration_area_note or "", "",
            ])
            row_no = roster_ws.max_row
            if employee.registration_selfie_enc:
                try:
                    photo = XLImage(BytesIO(decrypt_bytes(employee.registration_selfie_enc)))
                    photo.width = 72; photo.height = 72
                    roster_ws.add_image(photo, f"K{row_no}")
                    roster_ws.row_dimensions[row_no].height = 58
                except Exception:
                    roster_ws.cell(row_no, 11, "Rasmni joylab bo'lmadi")
    roster_ws.column_dimensions["K"].width = 14

    info_ws = wb.create_sheet("Hisobot sozlamalari")
    info_ws.append(["Davr", f"{start_date.isoformat()} — {end_date.isoformat()}"])
    info_ws.append(["Tashkilotlar", ", ".join(o.name for o in orgs)])
    for org in orgs:
        info_ws.append([f"{org.name} ish vaqti", f"{org.work_start}–{org.work_end}; grace {org.grace_minutes} daq"])
        info_ws.append([f"{org.name} kechikish sababi", org.late_reason_mode])
        info_ws.append([f"{org.name} erta ketish sababi", org.early_leave_reason_mode])
        info_ws.append([f"{org.name} anti-spoof", org.anti_spoof_policy])
        info_ws.append([f"{org.name} selfi saqlash", "Doimiy" if not org.selfie_retention_days else f"{org.selfie_retention_days} kun"])
    info_ws.append(["GPS", "Istalgan joydan; koordinata audit uchun saqlanadi"])

    for sheet in (ws, sum_ws, roster_ws, info_ws):
        sheet.freeze_panes = "A2"
        for col in sheet.columns:
            try:
                width = min(max(len(str(c.value or "")) for c in col) + 2, 54)
                sheet.column_dimensions[col[0].column_letter].width = width
            except Exception:
                pass
    out = BytesIO(); wb.save(out); return out.getvalue()


def monthly_xlsx(db: Session, organization_id: int, year: int, month: int) -> bytes:
    start = date(year, month, 1)
    if month == 12:
        next_month = date(year + 1, 1, 1)
    else:
        next_month = date(year, month + 1, 1)
    return range_xlsx(db, [organization_id], start, next_month - timedelta(days=1))

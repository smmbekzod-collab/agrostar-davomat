# 3.6 API additions

Employee:
- `GET /api/v1/attendance/context?event_type=checkin|checkout` — current schedule status and reason requirement.
- `POST /api/v1/attendance/checkin|checkout` adds multipart `reason`.
- `GET /api/v1/employee/history` returns schedule/reason/review/suspicious flags.

Admin dashboard:
- `GET /api/v1/admin/dashboard`
- `GET /api/v1/admin/organization-dashboard`
- `GET /api/v1/admin/today-status?organization_id=&status=`

Attendance review:
- `PATCH /api/v1/admin/attendance/{id}/note`
- `PATCH /api/v1/admin/attendance/{id}/review`
- `GET /api/v1/admin/attendance?review_status=pending_review`

Employee lifecycle:
- `PATCH /api/v1/admin/employees/{id}` with `employment_status`, `status_note`, `status_until`
- `POST /api/v1/admin/employees/{id}/archive`
- `GET /api/v1/admin/employees/{id}/history`

Reports/stats:
- `GET /api/v1/admin/stats/employees?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD`
- `GET /api/v1/admin/reports/range.xlsx`
- `GET /api/v1/admin/reports/all-organizations.xlsx`
- `GET /api/v1/admin/report-columns`

Remote/security:
- `GET/PATCH /api/v1/admin/mobile-config`
- `GET/PATCH /api/v1/admin/security-config`
- `POST /api/v1/admin/admins/{id}/terminate-sessions`
- `POST /api/v1/admin/maintenance/cleanup-selfies`

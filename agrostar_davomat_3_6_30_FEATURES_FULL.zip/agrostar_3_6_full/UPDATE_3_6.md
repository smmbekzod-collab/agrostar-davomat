# AgroStar Davomat 3.6.0 — Policy, Review, Reporting & Remote Control

Bu versiya 3.5 bazasidagi barcha oldingi funksiyalarni saqlaydi, jumladan: ikki alohida Flutter ilova, Railway/FastAPI/PostgreSQL, DeepFace/FaceNet512, anti-spoof, portret va aspect-ratio saqlangan selfi kamera, istalgan joydan GPS davomat, selfilarni shifrlangan saqlash, Excel rasmlar, yuzdan qayta kirish, hududda emasman izohi va remote-config.

## 30 ta yangi/yangilangan talab

1. Tashkilot bo‘yicha ish boshlanish/tugash vaqti va grace daqiqasi.
2. Kechikish sababi: off / optional / required.
3. Erta ketish sababi: off / optional / required.
4. Bugungi filtrlar: Keldi, Kelmadi, Ketdi, Ketmadi, Kechikdi, Erta ketdi, Tekshiruvda.
5. Kunlik status: To‘liq, Faqat Keldim, Faqat Ketdim, Davomat qilmagan, Davomatdan ozod.
6. Admin kunlik statistikasi.
7. Super Admin tashkilotlar kesimidagi dashboard.
8. Har bir davomat yozuviga Admin xizmat izohi.
9. Xodim holati: faol, ta’til, xizmat safari, kasallik, ishdan bo‘shagan, arxiv. Vaqtinchalik status uchun qaytish sanasi berilsa avtomatik faollashadi.
10. Shubhali davomat pending_review bo‘ladi; Admin tasdiqlaydi yoki rad etadi.
11. Face threshold har tashkilot uchun serverdan boshqariladi.
12. Anti-spoof: required / soft / registration_only.
13. Selfi retention: 0=doimiy yoki N kun; avtomatik cleanup metadata va tarixni o‘chirmaydi.
14. Excel ustunlari tashkilot sozlamasidan tanlanadi.
15. Sana oralig‘i bo‘yicha xodim statistikasi: ishlagan kun, kechikish, erta ketish.
16. Excel eksport: ixtiyoriy sana oralig‘i.
17. Super Admin barcha tashkilotlarni bitta Excelga chiqaradi.
18. Yangi ro‘yxatdan o‘tishni remote-config orqali yopish/ochish.
19. Maintenance rejimi.
20. Hodim va Admin uchun min/latest app version orqali yangilanish ogohlantirishi; minimumdan eski versiyada Hodim davomat/login oqimi bloklanadi.
21. Server banner xabari.
22. Audit: login muvaffaqiyat/xato, admin/rol, xodim, davomat review/note, sozlamalar va cleanup.
23. Admin xavfsizlik: noto‘g‘ri login limiti, vaqtinchalik lockout, parol muddati, sessiyalarni majburan tugatish.
24. Org Admin faqat biriktirilgan tashkilotlarni ko‘radi; Super Admin hammasini ko‘radi.
25. Shubhali belgilar: mock GPS, yomon GPS accuracy, thresholdga yaqin yuz, anti-spoof noaniqligi, qisqa vaqt ichida noodatiy geografik sakrash.
26. Admin xodimning barcha Keldim/Ketdim tarixini GPS, status, sabab, izoh, flag va selfi bilan ko‘radi.
27. O‘chirish tarixni yo‘qotmaydi — xodim Arxivga o‘tadi.
28. Har bir tashkilotning qoidalari alohida.
29. Keldim/Ketdim/pending/face kabi xabar matnlari remote-config orqali serverdan boshqariladi.
30. Bir marta ro‘yxatdan o‘tgan yuz shu tashkilotda qayta ro‘yxatdan o‘ta olmaydi — shu kuni ham, keyin ham; mavjud akkauntga yuz orqali kiradi.

## Selfi kamera regressiya talabi

`employee_app/lib/screens/selfie_camera_screen.dart` dagi portret orientation, uniform aspect-ratio scale, autofocus, auto-exposure va oval face guide saqlanishi shart. Keyingi versiyalarda bu faylni tasodifan eski/cho‘zilgan previewga qaytarmang.

## Deploy

Backend: `Deploy Backend to Railway` workflow orqali ZIPni `grand-recreation` servicega yuboring. `/health` versiyasi `3.6.0` bo‘lishi kerak.

APK build: GitHub ZIP workflowda `API_BASE_URL=https://grand-recreation-production-caad.up.railway.app/api/v1` bilan build qiling.

class Organization {
  final int id;
  final String name;
  final String code;
  Organization({required this.id, required this.name, required this.code});
  factory Organization.fromJson(Map<String, dynamic> j) => Organization(
        id: j['id'], name: j['name'], code: j['code'],
      );
}

class MobileConfig {
  final String employeeReloginMode;
  final bool employeeNameFallbackEnabled;
  final bool employeeRegistrationAreaToggle;
  final bool allowNewEmployeeRegistration;
  final bool maintenanceEnabled;
  final String maintenanceMessage;
  final String reloginHelpText;
  final String employeeMinVersion;
  final String employeeLatestVersion;
  final String updateMessage;
  final String updateUrl;
  final bool bannerEnabled;
  final String bannerMessage;
  final Map<String,String> messageTexts;

  const MobileConfig({
    this.employeeReloginMode = 'face_only',
    this.employeeNameFallbackEnabled = true,
    this.employeeRegistrationAreaToggle = true,
    this.allowNewEmployeeRegistration = true,
    this.maintenanceEnabled = false,
    this.maintenanceMessage = '',
    this.reloginHelpText = 'Tashkilotni tanlang va jonli selfi oling. Tizim yuzingiz orqali akkauntingizni avtomatik aniqlaydi.',
    this.employeeMinVersion = '3.6.0',
    this.employeeLatestVersion = '3.6.0',
    this.updateMessage = '',
    this.updateUrl = '',
    this.bannerEnabled = false,
    this.bannerMessage = '',
    this.messageTexts = const {},
  });

  bool get faceOnlyLogin => employeeReloginMode == 'face_only';

  factory MobileConfig.fromJson(Map<String, dynamic> j) => MobileConfig(
        employeeReloginMode: j['employee_relogin_mode']?.toString() ?? 'face_only',
        employeeNameFallbackEnabled: j['employee_name_fallback_enabled'] ?? true,
        employeeRegistrationAreaToggle: j['employee_registration_area_toggle'] ?? true,
        allowNewEmployeeRegistration: j['allow_new_employee_registration'] ?? true,
        maintenanceEnabled: j['maintenance_enabled'] ?? false,
        maintenanceMessage: j['maintenance_message']?.toString() ?? '',
        reloginHelpText: j['relogin_help_text']?.toString() ?? 'Tashkilotni tanlang va jonli selfi oling.',
        employeeMinVersion: j['employee_min_version']?.toString() ?? '3.6.0',
        employeeLatestVersion: j['employee_latest_version']?.toString() ?? '3.6.0',
        updateMessage: j['update_message']?.toString() ?? '',
        updateUrl: j['update_url']?.toString() ?? '',
        bannerEnabled: j['banner_enabled'] ?? false,
        bannerMessage: j['banner_message']?.toString() ?? '',
        messageTexts: (j['message_texts'] is Map)
            ? Map<String,String>.from((j['message_texts'] as Map).map((k,v)=>MapEntry(k.toString(),v.toString())))
            : const {},
      );
}

class EmployeeMe {
  final int id;
  final String fullName;
  final String employeeCode;
  final String organizationName;
  final bool isApproved;
  final String employmentStatus;
  final String? statusNote;
  final DateTime? statusUntil;
  EmployeeMe({required this.id, required this.fullName, required this.employeeCode, required this.organizationName,
    required this.isApproved, required this.employmentStatus, this.statusNote, this.statusUntil});
  factory EmployeeMe.fromJson(Map<String, dynamic> j) => EmployeeMe(
        id: j['id'], fullName: j['full_name'], employeeCode: j['employee_code'],
        organizationName: j['organization_name'], isApproved: j['is_approved'] ?? false,
        employmentStatus: j['employment_status']?.toString() ?? 'active',
        statusNote: j['status_note']?.toString(),
        statusUntil: j['status_until'] == null ? null : DateTime.tryParse(j['status_until'].toString()),
      );
}

class AttendanceItem {
  final int id;
  final String eventType;
  final DateTime occurredAt;
  final double latitude;
  final double longitude;
  final double? accuracy;
  final String? scheduleStatus;
  final int? minutesDelta;
  final String? employeeReason;
  final String reviewStatus;
  final List<String> suspiciousFlags;
  AttendanceItem({required this.id,required this.eventType,required this.occurredAt,required this.latitude,required this.longitude,
    this.accuracy,this.scheduleStatus,this.minutesDelta,this.employeeReason,required this.reviewStatus,required this.suspiciousFlags});
  factory AttendanceItem.fromJson(Map<String, dynamic> j) => AttendanceItem(
        id:j['id'], eventType:j['event_type'], occurredAt:DateTime.parse(j['occurred_at']),
        latitude:(j['latitude'] as num).toDouble(), longitude:(j['longitude'] as num).toDouble(),
        accuracy:(j['accuracy_m'] as num?)?.toDouble(), scheduleStatus:j['schedule_status']?.toString(),
        minutesDelta:(j['minutes_delta'] as num?)?.toInt(), employeeReason:j['employee_reason']?.toString(),
        reviewStatus:j['review_status']?.toString()??'approved', suspiciousFlags:List<String>.from(j['suspicious_flags']??const[]),
      );
}

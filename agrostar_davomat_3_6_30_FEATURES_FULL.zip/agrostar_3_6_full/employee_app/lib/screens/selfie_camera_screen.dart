import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SelfieCameraScreen extends StatefulWidget {
  final String title;
  const SelfieCameraScreen({super.key, this.title = 'Jonli selfi'});

  @override
  State<SelfieCameraScreen> createState() => _SelfieCameraScreenState();
}

class _SelfieCameraScreenState extends State<SelfieCameraScreen> {
  CameraController? controller;
  String? error;
  bool taking = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final cams = await availableCameras();
      final front = cams
          .where((c) => c.lensDirection == CameraLensDirection.front)
          .toList();
      if (front.isEmpty) throw Exception('Old kamera topilmadi');

      final c = CameraController(
        front.first,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      await c.initialize();

      // Selfi har doim telefon tik turgan holatda olinadi. Bu Android
      // qurilmalardagi 90°/aspect-ratio farqlarini kamaytiradi.
      try {
        await c.lockCaptureOrientation(DeviceOrientation.portraitUp);
      } catch (_) {}
      try {
        await c.setFlashMode(FlashMode.off);
      } catch (_) {}
      try {
        await c.setFocusMode(FocusMode.auto);
      } catch (_) {}
      try {
        await c.setExposureMode(ExposureMode.auto);
      } catch (_) {}

      if (!mounted) {
        await c.dispose();
        return;
      }
      setState(() => controller = c);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> _capture() async {
    if (controller == null || taking) return;
    setState(() => taking = true);
    try {
      final file = await controller!.takePicture();
      if (mounted) Navigator.pop(context, File(file.path));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Rasm olishda xato: $e')),
        );
        setState(() => taking = false);
      }
    }
  }

  Widget _portraitPreview(CameraController c) {
    // CameraPreview o‘z aspect ratio sini saqlaydi. Uni cho‘zib yubormasdan
    // portret viewportni bir xil (uniform) scale bilan to‘ldiramiz.
    return LayoutBuilder(
      builder: (context, constraints) {
        final viewportAspect = constraints.maxWidth / constraints.maxHeight;
        final cameraAspect = c.value.aspectRatio;
        final denominator = cameraAspect * viewportAspect;
        final scale = denominator > 0
            ? (1 / denominator).clamp(1.0, 4.0).toDouble()
            : 1.0;

        return ClipRect(
          child: Stack(
            fit: StackFit.expand,
            children: [
              Center(
                child: Transform.scale(
                  scale: scale,
                  child: CameraPreview(c),
                ),
              ),
              IgnorePointer(
                child: Center(
                  child: Container(
                    width: 220,
                    height: 300,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(150),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.9),
                        width: 3,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(error!),
              ),
            )
          : controller == null
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: _portraitPreview(controller!),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 10, 16, 4),
                      child: Text(
                        'Telefonni tik tuting. Yuzingizni oval ichiga joylashtiring. '
                        'Kadrda faqat bitta odam bo‘lsin.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 28, top: 8),
                      child: FilledButton.icon(
                        onPressed: taking ? null : _capture,
                        icon: const Icon(Icons.camera_alt),
                        label: Text(taking ? 'Olinmoqda...' : 'Selfi olish'),
                      ),
                    ),
                  ],
                ),
    );
  }
}

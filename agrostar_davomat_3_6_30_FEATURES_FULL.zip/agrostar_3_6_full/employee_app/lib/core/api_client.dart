import 'dart:io';
import 'package:dio/dio.dart';
import '../models/models.dart';
import 'config.dart';
import 'session_store.dart';

class ApiClient {
  final Dio dio = Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl, connectTimeout: const Duration(seconds: 25), receiveTimeout: const Duration(seconds: 60)));
  final SessionStore session;
  ApiClient(this.session);

  String _message(Object e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map && data['detail'] != null) {
        final d = data['detail'];
        if (d is Map && d['message'] != null) return d['message'].toString();
        return d.toString();
      }
      return e.message ?? 'Server bilan aloqa xatosi';
    }
    return e.toString();
  }

  Future<Options> _authOptions() async {
    final token = await session.accessToken();
    final device = await session.deviceId();
    return Options(headers: {'Authorization': 'Bearer $token', 'X-Device-ID': device});
  }

  Future<List<Organization>> organizations() async {
    final r = await dio.get('/public/organizations');
    return (r.data as List).map((e) => Organization.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<MobileConfig> mobileConfig() async {
    try {
      final r = await dio.get('/public/mobile-config');
      return MobileConfig.fromJson(Map<String,dynamic>.from(r.data));
    } catch (_) {
      return const MobileConfig();
    }
  }

  Future<void> register({
    required String fullName,
    required int organizationId,
    required File selfie,
    required bool registrationOutsideArea,
    required String registrationAreaNote,
  }) async {
    try {
      final device = await session.deviceId();
      final form = FormData.fromMap({
        'full_name': fullName,
        'organization_id': organizationId,
        'device_id': device,
        'registration_outside_area': registrationOutsideArea,
        'registration_area_note': registrationAreaNote,
        'selfie': await MultipartFile.fromFile(selfie.path, filename: 'selfie.jpg'),
      });
      final r = await dio.post('/employee-auth/register', data: form);
      await session.saveTokens(r.data['access_token'], r.data['refresh_token']);
    } catch (e) { throw Exception(_message(e)); }
  }


  Future<void> loginFace({String? fullName, required int organizationId, required File selfie}) async {
    try {
      final device = await session.deviceId();
      final data = <String,dynamic>{
        'organization_id': organizationId,
        'device_id': device,
        'selfie': await MultipartFile.fromFile(selfie.path, filename: 'login-selfie.jpg'),
      };
      final cleaned = fullName?.trim() ?? '';
      if (cleaned.isNotEmpty) data['full_name'] = cleaned;
      final r = await dio.post('/employee-auth/login-face', data: FormData.fromMap(data));
      await session.saveTokens(r.data['access_token'], r.data['refresh_token']);
    } catch (e) {
      throw Exception(_message(e));
    }
  }

  Future<void> relink({required String fullName, required int organizationId, required File selfie}) async {
    try {
      final device = await session.deviceId();
      final form = FormData.fromMap({
        'full_name': fullName, 'organization_id': organizationId, 'device_id': device,
        'selfie': await MultipartFile.fromFile(selfie.path, filename: 'selfie.jpg'),
      });
      final r = await dio.post('/employee-auth/relink', data: form);
      await session.saveTokens(r.data['access_token'], r.data['refresh_token']);
    } catch (e) { throw Exception(_message(e)); }
  }

  Future<bool> refresh() async {
    final token = await session.refreshToken();
    if (token == null) return false;
    try {
      final r = await dio.post('/employee-auth/refresh', data: {'refresh_token': token});
      await session.saveTokens(r.data['access_token'], r.data['refresh_token']);
      return true;
    } catch (_) { await session.clearTokens(); return false; }
  }

  Future<Response<dynamic>> _get(String path) async {
    try { return await dio.get(path, options: await _authOptions()); }
    on DioException catch (e) {
      if (e.response?.statusCode == 401 && await refresh()) return dio.get(path, options: await _authOptions());
      throw Exception(_message(e));
    }
  }

  Future<EmployeeMe> me() async => EmployeeMe.fromJson(Map<String,dynamic>.from((await _get('/employee/me')).data));

  Future<List<AttendanceItem>> history() async {
    final r = await _get('/employee/history');
    return (r.data as List).map((e) => AttendanceItem.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<Map<String,dynamic>> attendanceContext(String type) async {
    final r = await _get('/attendance/context?event_type=$type');
    return Map<String,dynamic>.from(r.data);
  }

  Future<Map<String,dynamic>> attendance({required String type, required double latitude, required double longitude,
      required double accuracy, required bool isMocked, required File selfie, String? reason}) async {
    try {
      final form = FormData.fromMap({
        'latitude': latitude, 'longitude': longitude, 'accuracy_m': accuracy, 'is_mocked': isMocked,
        'reason': reason ?? '',
        'selfie': await MultipartFile.fromFile(selfie.path, filename: 'attendance.jpg'),
      });
      Response r;
      try { r = await dio.post('/attendance/$type', data: form, options: await _authOptions()); }
      on DioException catch (e) {
        if (e.response?.statusCode == 401 && await refresh()) {
          final form2 = FormData.fromMap({
            'latitude': latitude, 'longitude': longitude, 'accuracy_m': accuracy, 'is_mocked': isMocked,
            'reason': reason ?? '',
            'selfie': await MultipartFile.fromFile(selfie.path, filename: 'attendance.jpg'),
          });
          r = await dio.post('/attendance/$type', data: form2, options: await _authOptions());
        } else { rethrow; }
      }
      return Map<String,dynamic>.from(r.data);
    } catch (e) { throw Exception(_message(e)); }
  }
}

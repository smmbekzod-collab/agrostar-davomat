# 3.5.0 — Face-only re-login + Remote Config

## Xodim qayta kirishi

- `Oldin ro‘yxatdan o‘tganman` rejimida F.I.O. standart holatda talab qilinmaydi.
- Xodim tashkilotni tanlaydi va jonli selfi oladi.
- Backend shu tashkilotdagi faol xodimlarning FaceNet512 embeddinglari orasidan yagona eng yaxshi moslikni topadi.
- Ikki profil juda yaqin chiqsa, tizim taxmin bilan kiritmaydi; ixtiyoriy F.I.O. fallback orqali aniqlashtirish mumkin.
- Muvaffaqiyatli yuz tekshiruvida yangi qurilma avtomatik bog‘lanadi va eski qurilma sessiyasi bekor qilinadi.

## Remote Config

Super Admin `Admin App → Sozlamalar → Mobil ilova remote-config` orqali quyidagilarni APK qayta build qilmasdan o‘zgartira oladi:

- qayta kirish rejimi: `face_only` yoki `name_and_face`;
- F.I.O. fallbackni yoqish/o‘chirish;
- ro‘yxatdan o‘tishdagi `Belgilangan hududda emasman` checkboxini yoqish/o‘chirish;
- yangi xodim ro‘yxatdan o‘tishini vaqtincha yoqish/o‘chirish;
- maintenance rejimi va xabari;
- qayta kirish yordam matni.

Mobil ilova bu sozlamalarni `/api/v1/public/mobile-config` endpointidan oladi.

## Muhim cheklov

Remote config faqat APK ichida oldindan qo‘llab-quvvatlangan funksiyalarni boshqaradi. Yangi kamera funksiyasi, yangi native permission, yangi ekran turi yoki yangi platforma integratsiyasi kabi katta o‘zgarishlar uchun baribir yangi APK build kerak bo‘ladi.

# AgroStar Davomat 4.1.1 — UI / Audio / Branding

Ushbu versiya 4.0.1 ustiga qurilgan. Oldingi davomat, Face ID, GPS, Excel, remote config, Work 4.0 va selfie camera fixlar saqlangan.

## Yangi imkoniyatlar

- Admin/Rahbar vazifa yaratishda ovozli topshiriq yozib biriktira oladi.
- Hodim vazifadagi ovozli topshiriqni ilovaning o'zida Play/Pause/seek/1x/1.5x/2x bilan tinglaydi.
- Admin xodim yuborgan ovozli hisobotni ilovaning o'zida tinglaydi.
- Hodim o'z hisobotidagi ovozni ilovaning o'zida tinglay oladi.
- Eureka g'oyaga ovoz yozib biriktirish va keyin tinglash qo'shildi.
- Glassmorphism uslubidagi kartalar, AgroStar orange/green/purple ranglari va yangilangan Material 3 theme.
- AgroStar logotipi login/start ekranlarida ishlatiladi.
- Android launcher icon AgroStar quyosh+dala belgisi bilan almashtiriladi.
- Xodim profilida ro'yxatdan o'tish selfisi avatar bo'lib ko'rinadi.
- Admin xodimlar ro'yxatida xodim selfisi mini-avatar sifatida ko'rinadi.
- Rahbar/Admin drawer profilida, mos xodim profili mavjud bo'lsa, Face ID ro'yxat selfisi avatar sifatida ko'rinadi; aks holda AgroStar logo fallback bo'ladi.

## Backend yangi endpointlar

Employee:
- GET `/api/v1/work/tasks/{task_id}/attachments`
- GET `/api/v1/work/reports/{report_id}/attachments`
- POST `/api/v1/work/ideas/{idea_id}/attachment`
- GET `/api/v1/work/ideas/{idea_id}/attachments`
- GET `/api/v1/employee/profile-selfie`

Admin:
- POST `/api/v1/admin/work/tasks/{task_id}/attachment`
- GET `/api/v1/admin/work/tasks/{task_id}/attachments`
- GET `/api/v1/admin/work/ideas/{idea_id}/attachments`
- GET `/api/v1/admin/me/avatar`

## Build

Backend health versiyasi: `4.1.1`.

Railway deploy ZIP: aynan shu to'liq ZIP.
Android build workflow ham aynan shu ZIPni ochadi.

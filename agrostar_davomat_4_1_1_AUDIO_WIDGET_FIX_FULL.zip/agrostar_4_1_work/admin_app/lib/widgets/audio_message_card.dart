import 'dart:io';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../ui/agro_theme.dart';

class AudioMessageCard extends StatefulWidget {
  final String title;
  final String? subtitle;
  final Future<File> Function() loader;

  const AudioMessageCard({
    super.key,
    required this.title,
    this.subtitle,
    required this.loader,
  });

  @override
  State<AudioMessageCard> createState() => _AudioMessageCardState();
}

class _AudioMessageCardState extends State<AudioMessageCard> {
  final AudioPlayer player = AudioPlayer();

  bool loading = false;
  String? error;
  bool prepared = false;

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  String fmt(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds.remainder(60);
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  Future<void> toggle() async {
    try {
      if (!prepared) {
        if (mounted) {
          setState(() {
            loading = true;
            error = null;
          });
        }
        final file = await widget.loader();
        await player.setFilePath(file.path);
        prepared = true;
      }

      if (player.playing) {
        await player.pause();
      } else {
        await player.play();
      }
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AgroColors.orange.withValues(alpha: .16),
                  shape: BoxShape.circle,
                ),
                child: StreamBuilder<bool>(
                  stream: player.playingStream,
                  builder: (_, snapshot) {
                    return IconButton(
                      onPressed: loading ? null : toggle,
                      icon: loading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(
                              (snapshot.data ?? false)
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded,
                              color: AgroColors.orange,
                            ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    if ((widget.subtitle ?? '').isNotEmpty)
                      Text(
                        widget.subtitle!,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                  ],
                ),
              ),
              PopupMenuButton<double>(
                tooltip: 'Tezlik',
                onSelected: (value) => player.setSpeed(value),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 1.0, child: Text('1x')),
                  PopupMenuItem(value: 1.5, child: Text('1.5x')),
                  PopupMenuItem(value: 2.0, child: Text('2x')),
                ],
                child: const Padding(
                  padding: EdgeInsets.all(8),
                  child: Icon(Icons.speed),
                ),
              ),
            ],
          ),
          StreamBuilder<Duration>(
            stream: player.positionStream,
            builder: (_, positionSnapshot) {
              return StreamBuilder<Duration?>(
                stream: player.durationStream,
                builder: (_, durationSnapshot) {
                  final position = positionSnapshot.data ?? Duration.zero;
                  final duration = durationSnapshot.data ?? Duration.zero;
                  final max = duration.inMilliseconds <= 0
                      ? 1.0
                      : duration.inMilliseconds.toDouble();
                  final sliderValue = position.inMilliseconds
                      .clamp(0, max.toInt())
                      .toDouble();

                  return Row(
                    children: [
                      Text(
                        fmt(position),
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                      Expanded(
                        child: Slider(
                          value: sliderValue,
                          max: max,
                          onChanged: prepared
                              ? (value) => player.seek(
                                    Duration(milliseconds: value.toInt()),
                                  )
                              : null,
                        ),
                      ),
                      Text(
                        fmt(duration),
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ],
                  );
                },
              );
            },
          ),
          if (error != null)
            Text(
              error!,
              style: TextStyle(
                color: Theme.of(context).colorScheme.error,
                fontSize: 12,
              ),
            ),
        ],
      ),
    );
  }
}

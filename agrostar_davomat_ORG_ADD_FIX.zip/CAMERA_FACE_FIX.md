# Camera + Face Detection Fix 3.0.1

- Employee selfie preview portrait aspect ratio fixed (no horizontal squashing).
- Capture orientation locked to portrait; autofocus/exposure center point added.
- Face guide overlay added.
- Backend now tries EXIF-normalized image plus 90/270/180 degree rotations.
- RetinaFace detector falls back to OpenCV if a device-specific JPEG cannot be detected.
- Liveness/anti-spoofing remains mandatory after a single face is detected.

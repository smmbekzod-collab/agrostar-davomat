# Railway deploy

Backend Railway uchun tayyorlangan.

Backend service variables:

DATABASE_URL=${{Postgres.DATABASE_URL}}
ENV=production
API_V1_PREFIX=/api/v1
SECRET_KEY=<kamida 32 belgili maxfiy kalit>
BIOMETRIC_KEY=<Fernet key>
SUPERADMIN_USERNAME=superadmin
SUPERADMIN_PASSWORD=<kamida 12 belgili kuchli parol>
SUPERADMIN_FULL_NAME=Super Admin
CORS_ORIGINS=[]
FACE_MODEL=Facenet512
FACE_DETECTOR=retinaface
FACE_DISTANCE_METRIC=cosine
FACE_THRESHOLD=0.30
MAX_UPLOAD_BYTES=8000000

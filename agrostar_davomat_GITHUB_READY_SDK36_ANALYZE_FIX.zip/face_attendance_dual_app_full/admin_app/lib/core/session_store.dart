import 'package:flutter_secure_storage/flutter_secure_storage.dart';
class SessionStore {
  static const _s = FlutterSecureStorage();
  Future<String?> accessToken() => _s.read(key: 'admin_access_token');
  Future<String?> refreshToken() => _s.read(key: 'admin_refresh_token');
  Future<void> save(String a, String r) async { await _s.write(key: 'admin_access_token', value: a); await _s.write(key: 'admin_refresh_token', value: r); }
  Future<void> clear() async { await _s.delete(key: 'admin_access_token'); await _s.delete(key: 'admin_refresh_token'); }
}

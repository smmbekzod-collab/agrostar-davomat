import 'package:flutter/material.dart';
import 'core/api_client.dart';
import 'core/session_store.dart';
import 'screens/admin_home_screen.dart';
import 'screens/login_screen.dart';

void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const AdminApp());}
class AdminApp extends StatefulWidget{const AdminApp({super.key});@override State<AdminApp> createState()=>_AdminAppState();}
class _AdminAppState extends State<AdminApp>{final session=SessionStore();late final api=ApiClient(session);bool? logged;
@override void initState(){super.initState();check();}
Future<void> check()async{if(await session.accessToken()==null){if(mounted)setState(()=>logged=false);return;}try{await api.me();if(mounted)setState(()=>logged=true);}catch(_){final ok=await api.refresh();if(mounted)setState(()=>logged=ok);}}
@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Davomat Admin',theme:ThemeData(colorSchemeSeed:Colors.indigo,useMaterial3:true),home:logged==null?const Scaffold(body:Center(child:CircularProgressIndicator())):logged!?AdminHomeScreen(api:api,session:session,onLogout:()=>setState(()=>logged=false)):LoginScreen(api:api,onLogin:()=>setState(()=>logged=true)));}

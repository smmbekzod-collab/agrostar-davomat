class Organization {
  final int id; final String name; final String code; final bool isActive; final String locationMode; final bool autoApprove;
  final String timezone; final String workStart; final String workEnd; final int graceMinutes;
  Organization({required this.id,required this.name,required this.code,required this.isActive,required this.locationMode,required this.autoApprove,required this.timezone,required this.workStart,required this.workEnd,required this.graceMinutes});
  factory Organization.fromJson(Map<String,dynamic> j)=>Organization(id:j['id'],name:j['name'],code:j['code'],isActive:j['is_active'],locationMode:j['location_mode'],autoApprove:j['employee_auto_approve'],timezone:j['timezone']??'Asia/Tashkent',workStart:j['work_start']??'09:00',workEnd:j['work_end']??'18:00',graceMinutes:j['grace_minutes']??10);
}
class AdminAccount {
  final int id; final String fullName; final String username; final String role; final List<String> permissions; final List<int> organizationIds; final bool isActive; final bool isApproved;
  AdminAccount({required this.id,required this.fullName,required this.username,required this.role,required this.permissions,required this.organizationIds,required this.isActive,required this.isApproved});
  factory AdminAccount.fromJson(Map<String,dynamic> j)=>AdminAccount(id:j['id'],fullName:j['full_name'],username:j['username'],role:j['role'],permissions:List<String>.from(j['permissions']??[]),organizationIds:List<int>.from(j['organization_ids']??[]),isActive:j['is_active'],isApproved:j['is_approved']);
}
class EmployeeItem {
  final int id; final String fullName; final String code; final int orgId; final String orgName; final bool active; final bool approved; final bool deviceBound;
  EmployeeItem({required this.id,required this.fullName,required this.code,required this.orgId,required this.orgName,required this.active,required this.approved,required this.deviceBound});
  factory EmployeeItem.fromJson(Map<String,dynamic> j)=>EmployeeItem(id:j['id'],fullName:j['full_name'],code:j['employee_code'],orgId:j['organization_id'],orgName:j['organization_name'],active:j['is_active'],approved:j['is_approved'],deviceBound:j['device_bound']??false);
}
class AttendanceItem {
  final int id; final String employeeName; final String orgName; final String type; final DateTime at; final double lat; final double lon; final double? accuracy; final double? distance; final double? threshold; final String? scheduleStatus; final int? minutesDelta;
  AttendanceItem({required this.id,required this.employeeName,required this.orgName,required this.type,required this.at,required this.lat,required this.lon,this.accuracy,this.distance,this.threshold,this.scheduleStatus,this.minutesDelta});
  factory AttendanceItem.fromJson(Map<String,dynamic> j)=>AttendanceItem(id:j['id'],employeeName:j['employee_name'],orgName:j['organization_name'],type:j['event_type'],at:DateTime.parse(j['occurred_at']),lat:(j['latitude'] as num).toDouble(),lon:(j['longitude'] as num).toDouble(),accuracy:(j['accuracy_m'] as num?)?.toDouble(),distance:(j['face_distance'] as num?)?.toDouble(),threshold:(j['face_threshold'] as num?)?.toDouble(),scheduleStatus:j['schedule_status'],minutesDelta:j['minutes_delta']);
}

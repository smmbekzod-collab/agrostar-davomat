import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../models/models.dart';

class LoginScreen extends StatefulWidget {
  final ApiClient api; final VoidCallback onLogin;
  const LoginScreen({super.key,required this.api,required this.onLogin});
  @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
  final u=TextEditingController();final p=TextEditingController();final full=TextEditingController();
  List<Organization> orgs=[];int? orgId;bool loading=false;bool register=false;
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{try{orgs=await widget.api.publicOrganizations();if(orgs.isNotEmpty)orgId=orgs.first.id;}catch(_){ }if(mounted)setState((){});}
  void snack(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s.replaceFirst('Exception: ',''))));
  Future<void> submit()async{setState(()=>loading=true);try{if(register){if(orgId==null)throw Exception('Tashkilot tanlang');await widget.api.registerRequest(full.text.trim(),u.text.trim(),p.text,orgId!);snack("So'rov yuborildi. Super Admin tasdiqlashi kerak.");setState(()=>register=false);}else{await widget.api.login(u.text.trim(),p.text);widget.onLogin();}}catch(e){snack('$e');}if(mounted)setState(()=>loading=false);}
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:460),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
    const Icon(Icons.admin_panel_settings,size:64),const SizedBox(height:12),Text(register?"Admin ro'yxatdan o'tish so'rovi":'Davomat Admin',style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:20),
    if(register)...[TextField(controller:full,decoration:const InputDecoration(labelText:'F.I.O.',border:OutlineInputBorder())),const SizedBox(height:12),DropdownButtonFormField<int>(initialValue:orgId,decoration:const InputDecoration(labelText:'Tashkilot',border:OutlineInputBorder()),items:orgs.map((o)=>DropdownMenuItem(value:o.id,child:Text(o.name))).toList(),onChanged:(v)=>setState(()=>orgId=v)),const SizedBox(height:12)],
    TextField(controller:u,decoration:const InputDecoration(labelText:'Login',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Parol',border:OutlineInputBorder())),const SizedBox(height:18),
    FilledButton(onPressed:loading?null:submit,child:Text(loading?'Kuting...':register?"So'rov yuborish":'Kirish')),TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Kirish oynasiga qaytish':"Admin bo'lish uchun ro'yxatdan o'tish"))
  ])))))));
}

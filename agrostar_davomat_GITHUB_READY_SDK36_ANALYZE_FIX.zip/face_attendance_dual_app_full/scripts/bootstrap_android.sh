#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

make_android() {
  local dir="$1" project="$2" label="$3" needs_location="$4"
  rm -rf "$ROOT/$dir/android"
  flutter create --platforms=android --org uz.bekzoddiki.agrostar --project-name "$project" "$TMP/$project" >/dev/null
  cp -R "$TMP/$project/android" "$ROOT/$dir/android"
  python "$ROOT/scripts/patch_android.py" "$ROOT/$dir/android" "$label" "$needs_location"
}

make_android employee_app employee "Agro Star Hodim" yes
make_android admin_app admin "Davomat Admin" no

echo "Android platform fayllari tayyor."

import 'dart:io';
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import 'selfie_camera_screen.dart';

class RegistrationScreen extends StatefulWidget {
  final ApiClient api;
  final VoidCallback onDone;
  const RegistrationScreen({super.key, required this.api, required this.onDone});
  @override State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final name = TextEditingController();
  List<Organization> orgs = [];
  int? orgId;
  File? selfie;
  bool loading = true;
  bool submitting = false;
  bool relink = false;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try { orgs = await widget.api.organizations(); if (orgs.isNotEmpty) orgId = orgs.first.id; }
    catch (e) { if (mounted) _snack('$e'); }
    if (mounted) setState(() => loading = false);
  }
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.replaceFirst('Exception: ', ''))));
  Future<void> _selfie() async {
    final f = await Navigator.push<File>(context, MaterialPageRoute(builder: (_) => const SelfieCameraScreen(title: 'Ro‘yxatdan o‘tish selfisi')));
    if (f != null) setState(() => selfie = f);
  }
  Future<void> _submit() async {
    if (name.text.trim().length < 3 || orgId == null || selfie == null) { _snack('F.I.O., tashkilot va selfi talab qilinadi'); return; }
    setState(() => submitting = true);
    try {
      if (relink) {
        await widget.api.relink(fullName: name.text.trim(), organizationId: orgId!, selfie: selfie!);
      } else {
        await widget.api.register(fullName: name.text.trim(), organizationId: orgId!, selfie: selfie!);
      }
      widget.onDone();
    } catch (e) { _snack('$e'); }
    if (mounted) setState(() => submitting = false);
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Agro Star Hodim')),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Xodim ro‘yxatdan o‘tishi', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Istalgan tumandan davomat qilishingiz mumkin. Har kelish/ketishda GPS va jonli selfi tekshiriladi.'),
        const SizedBox(height: 20),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'F.I.O.', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        DropdownButtonFormField<int>(initialValue: orgId, decoration: const InputDecoration(labelText: 'Tashkilot', border: OutlineInputBorder()),
          items: orgs.map((o) => DropdownMenuItem(value: o.id, child: Text(o.name))).toList(), onChanged: (v) => setState(() => orgId = v)),
        const SizedBox(height: 14),
        OutlinedButton.icon(onPressed: _selfie, icon: const Icon(Icons.face), label: Text(selfie == null ? 'Old kamera bilan selfi olish' : 'Selfi olindi — qayta olish')),
        SwitchListTile(value: relink, onChanged: (v) => setState(() => relink = v), title: const Text('Admin qurilmani reset qilgan — eski profilimni qayta bog‘lash')),
        const SizedBox(height: 10),
        FilledButton(onPressed: submitting ? null : _submit, child: Text(submitting ? 'Tekshirilmoqda...' : 'Ro‘yxatdan o‘tish')),
      ]),
    );
  }
}

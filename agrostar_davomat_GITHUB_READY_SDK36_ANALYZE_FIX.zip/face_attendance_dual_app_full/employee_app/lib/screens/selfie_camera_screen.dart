import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class SelfieCameraScreen extends StatefulWidget {
  final String title;
  const SelfieCameraScreen({super.key, this.title = 'Jonli selfi'});
  @override State<SelfieCameraScreen> createState() => _SelfieCameraScreenState();
}

class _SelfieCameraScreenState extends State<SelfieCameraScreen> {
  CameraController? controller;
  String? error;
  bool taking = false;

  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    try {
      final cams = await availableCameras();
      final front = cams.where((c) => c.lensDirection == CameraLensDirection.front).toList();
      if (front.isEmpty) throw Exception('Old kamera topilmadi');
      final c = CameraController(front.first, ResolutionPreset.high, enableAudio: false, imageFormatGroup: ImageFormatGroup.jpeg);
      await c.initialize();
      try { await c.setFlashMode(FlashMode.off); } catch (_) {}
      if (!mounted) { await c.dispose(); return; }
      setState(() => controller = c);
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
  }

  Future<void> _capture() async {
    if (controller == null || taking) return;
    setState(() => taking = true);
    try {
      final file = await controller!.takePicture();
      if (mounted) Navigator.pop(context, File(file.path));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Rasm olishda xato: $e')));
      setState(() => taking = false);
    }
  }

  @override
  void dispose() { controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!)))
        : controller == null ? const Center(child: CircularProgressIndicator())
        : Column(children: [
            Expanded(child: Center(child: AspectRatio(aspectRatio: controller!.value.aspectRatio, child: CameraPreview(controller!)))),
            const Padding(padding: EdgeInsets.all(10), child: Text('Yuzingizni aniq ko‘rsating. Kadrda faqat bitta odam bo‘lsin.')),
            Padding(padding: const EdgeInsets.only(bottom: 28), child: FilledButton.icon(onPressed: taking ? null : _capture, icon: const Icon(Icons.camera_alt), label: Text(taking ? 'Olinmoqda...' : 'Selfi olish'))),
          ]),
    );
  }
}

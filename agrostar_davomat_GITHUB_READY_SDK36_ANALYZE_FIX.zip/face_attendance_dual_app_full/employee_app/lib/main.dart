import 'package:flutter/material.dart';
import 'core/api_client.dart';
import 'core/session_store.dart';
import 'screens/dashboard_screen.dart';
import 'screens/registration_screen.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const EmployeeApp()); }

class EmployeeApp extends StatefulWidget {
  const EmployeeApp({super.key});
  @override State<EmployeeApp> createState() => _EmployeeAppState();
}

class _EmployeeAppState extends State<EmployeeApp> {
  final session = SessionStore();
  late final ApiClient api = ApiClient(session);
  bool? loggedIn;

  @override void initState() { super.initState(); _check(); }
  Future<void> _check() async {
    final token = await session.accessToken();
    if (token == null) { if (mounted) setState(() => loggedIn = false); return; }
    try { await api.me(); if (mounted) setState(() => loggedIn = true); }
    catch (_) {
      final ok = await api.refresh();
      if (mounted) setState(() => loggedIn = ok);
    }
  }
  @override Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Agro Star Hodim',
      theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
      home: loggedIn == null ? const Scaffold(body: Center(child: CircularProgressIndicator()))
        : loggedIn! ? DashboardScreen(api: api, session: session, onLogout: () => setState(() => loggedIn = false))
        : RegistrationScreen(api: api, onDone: () => setState(() => loggedIn = true)),
    );
  }
}

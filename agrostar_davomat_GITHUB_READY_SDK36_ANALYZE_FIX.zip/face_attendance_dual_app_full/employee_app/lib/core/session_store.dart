import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

class SessionStore {
  static const _storage = FlutterSecureStorage();
  static const _access = 'employee_access_token';
  static const _refresh = 'employee_refresh_token';
  static const _device = 'employee_device_id';

  Future<String?> accessToken() => _storage.read(key: _access);
  Future<String?> refreshToken() => _storage.read(key: _refresh);
  Future<void> saveTokens(String access, String refresh) async {
    await _storage.write(key: _access, value: access);
    await _storage.write(key: _refresh, value: refresh);
  }
  Future<String> deviceId() async {
    var id = await _storage.read(key: _device);
    if (id == null || id.isEmpty) {
      id = const Uuid().v4();
      await _storage.write(key: _device, value: id);
    }
    return id;
  }
  Future<void> clearTokens() async {
    await _storage.delete(key: _access);
    await _storage.delete(key: _refresh);
  }
}

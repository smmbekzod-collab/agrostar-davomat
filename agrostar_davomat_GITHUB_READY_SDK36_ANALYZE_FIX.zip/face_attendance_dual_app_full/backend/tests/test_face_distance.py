from app.services.face import cosine_distance

def test_cosine_identical():
    assert abs(cosine_distance([1, 0], [1, 0])) < 1e-6

def test_cosine_orthogonal():
    assert abs(cosine_distance([1, 0], [0, 1]) - 1.0) < 1e-6

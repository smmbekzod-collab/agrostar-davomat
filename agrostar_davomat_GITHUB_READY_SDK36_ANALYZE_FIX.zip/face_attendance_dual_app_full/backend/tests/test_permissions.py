from app.services.permissions import effective_permissions

def test_superadmin_has_all():
    assert "*" in effective_permissions("super_admin", [])

def test_custom_permission_added():
    assert "admin.manage" in effective_permissions("auditor", ["admin.manage"])

from datetime import datetime
from pydantic import BaseModel, Field


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class OrganizationOut(BaseModel):
    id: int
    name: str
    code: str
    is_active: bool
    location_mode: str
    employee_auto_approve: bool
    timezone: str
    work_start: str
    work_end: str
    grace_minutes: int
    model_config = {"from_attributes": True}


class EmployeeOut(BaseModel):
    id: int
    full_name: str
    employee_code: str
    organization_id: int
    organization_name: str | None = None
    is_active: bool
    is_approved: bool
    created_at: datetime


class AttendanceOut(BaseModel):
    id: int
    employee_id: int
    employee_name: str | None = None
    organization_id: int
    organization_name: str | None = None
    event_type: str
    occurred_at: datetime
    latitude: float
    longitude: float
    accuracy_m: float | None
    is_mocked: bool
    face_distance: float | None
    face_threshold: float | None
    anti_spoof_score: float | None
    schedule_status: str | None = None
    minutes_delta: int | None = None


class AdminOut(BaseModel):
    id: int
    full_name: str
    username: str
    role: str
    permissions: list[str]
    organization_ids: list[int]
    is_active: bool
    is_approved: bool
    created_at: datetime


class RefreshRequest(BaseModel):
    refresh_token: str


class Message(BaseModel):
    detail: str

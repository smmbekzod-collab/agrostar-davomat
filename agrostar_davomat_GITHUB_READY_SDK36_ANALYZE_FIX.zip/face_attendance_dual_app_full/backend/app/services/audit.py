from sqlalchemy.orm import Session
from app.models.entities import AuditLog


def add_audit(db: Session, admin_id: int | None, action: str, target_type: str | None = None, target_id: str | None = None, details: dict | None = None):
    db.add(AuditLog(actor_admin_id=admin_id, action=action, target_type=target_type, target_id=target_id, details=details or {}))

from __future__ import annotations
import io
import numpy as np
from PIL import Image, ImageOps
from deepface import DeepFace
from app.core.config import settings


class FaceError(ValueError):
    pass


def _decode(image_bytes: bytes) -> np.ndarray:
    if not image_bytes or len(image_bytes) > settings.max_upload_bytes:
        raise FaceError("Rasm hajmi noto'g'ri yoki juda katta")
    try:
        with Image.open(io.BytesIO(image_bytes)) as opened:
            img = ImageOps.exif_transpose(opened).convert("RGB")
            if img.width < 160 or img.height < 160:
                raise FaceError("Rasm sifati juda past")
            if img.width * img.height > 24_000_000:
                raise FaceError("Rasm o'lchami juda katta")
            return np.asarray(img)
    except FaceError:
        raise
    except Exception as exc:
        raise FaceError("Rasmni o'qib bo'lmadi") from exc


def extract_embedding(image_bytes: bytes, require_liveness: bool = True) -> tuple[list[float], float | None]:
    img = _decode(image_bytes)
    try:
        faces = DeepFace.extract_faces(
            img_path=img,
            detector_backend=settings.face_detector,
            enforce_detection=True,
            align=True,
            anti_spoofing=require_liveness,
            max_faces=2,
        )
    except Exception as exc:
        raise FaceError(f"Yuz aniqlanmadi yoki liveness tekshiruvi o'tmadi: {exc}") from exc
    if len(faces) != 1:
        raise FaceError("Kadrda aynan bitta yuz bo'lishi kerak")
    anti_score = None
    if require_liveness:
        if faces[0].get("is_real") is not True:
            raise FaceError("Jonli yuz tasdiqlanmadi")
        anti_score = float(faces[0].get("antispoof_score", 0.0))
    try:
        reps = DeepFace.represent(
            img_path=img,
            model_name=settings.face_model,
            detector_backend=settings.face_detector,
            enforce_detection=True,
            align=True,
            normalization="base",
            max_faces=1,
        )
    except Exception as exc:
        raise FaceError(f"Yuz embeddingini yaratib bo'lmadi: {exc}") from exc
    if len(reps) != 1:
        raise FaceError("Yuz embeddingi yagona bo'lishi kerak")
    return [float(v) for v in reps[0]["embedding"]], anti_score


def cosine_distance(a: list[float], b: list[float]) -> float:
    av = np.asarray(a, dtype=np.float32)
    bv = np.asarray(b, dtype=np.float32)
    denom = float(np.linalg.norm(av) * np.linalg.norm(bv))
    if denom == 0:
        return 1.0
    return float(1.0 - np.dot(av, bv) / denom)


def verify_embedding(reference: list[float], probe: list[float]) -> tuple[bool, float, float]:
    distance = cosine_distance(reference, probe)
    threshold = float(settings.face_threshold)
    return distance <= threshold, distance, threshold

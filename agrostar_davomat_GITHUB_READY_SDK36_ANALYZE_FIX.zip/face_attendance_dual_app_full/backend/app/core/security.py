from datetime import datetime, timedelta, timezone
from typing import Any
import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from app.core.config import settings

_hasher = PasswordHasher()


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    try:
        return _hasher.verify(hashed, password)
    except VerifyMismatchError:
        return False


def create_token(*, subject: str, actor: str, token_type: str, token_version: int, expires_delta: timedelta) -> str:
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "actor": actor,
        "typ": token_type,
        "ver": token_version,
        "iat": int(now.timestamp()),
        "exp": int((now + expires_delta).timestamp()),
    }
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def create_access_token(subject: str, actor: str, token_version: int) -> str:
    return create_token(subject=subject, actor=actor, token_type="access", token_version=token_version,
                        expires_delta=timedelta(minutes=settings.access_token_minutes))


def create_refresh_token(subject: str, actor: str, token_version: int) -> str:
    return create_token(subject=subject, actor=actor, token_type="refresh", token_version=token_version,
                        expires_delta=timedelta(days=settings.refresh_token_days))


def decode_token(token: str) -> dict[str, Any]:
    return jwt.decode(token, settings.secret_key, algorithms=["HS256"])

from datetime import date, datetime, time, timezone
from io import BytesIO
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.api.deps import current_admin, require_permission
from app.core.security import hash_password, verify_password
from app.db.session import get_db
from app.models.entities import Organization, AdminUser, AdminOrganization, Employee, Attendance, AuditLog
from app.schemas.admin import OrganizationCreate, OrganizationUpdate, AdminCreate, AdminUpdate, ResetPassword, EmployeeUpdate, ChangeOwnPassword
from app.services.audit import add_audit
from app.services.permissions import ALL_PERMISSIONS, effective_permissions
from app.services.report import monthly_xlsx

router = APIRouter(prefix="/admin", tags=["admin"])


def org_ids(admin: AdminUser) -> set[int]:
    return {x.organization_id for x in admin.org_links}


def can_access_org(admin: AdminUser, organization_id: int):
    if admin.role != "super_admin" and organization_id not in org_ids(admin):
        raise HTTPException(403, "Bu tashkilotga kirish huquqi yo'q")


def admin_json(a: AdminUser) -> dict:
    return {"id": a.id, "full_name": a.full_name, "username": a.username, "role": a.role,
            "permissions": a.permissions or [], "organization_ids": sorted(org_ids(a)),
            "is_active": a.is_active, "is_approved": a.is_approved, "created_at": a.created_at}

@router.get("/me")
def me(admin: AdminUser = Depends(current_admin)):
    return {**admin_json(admin), "effective_permissions": sorted(effective_permissions(admin.role, admin.permissions))}

@router.post("/change-password")
def change_password(body: ChangeOwnPassword, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if not verify_password(body.current_password, admin.password_hash):
        raise HTTPException(403, "Joriy parol noto'g'ri")
    admin.password_hash = hash_password(body.new_password)
    admin.token_version += 1
    add_audit(db, admin.id, "admin.change_own_password", "admin", str(admin.id))
    db.commit()
    return {"detail": "Parol almashtirildi. Qayta kiring."}

@router.get("/permissions")
def permissions(_: AdminUser = Depends(current_admin)):
    return {"permissions": ALL_PERMISSIONS, "roles": ["super_admin", "org_admin", "hr_manager", "auditor"]}

@router.get("/dashboard")
def dashboard(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    ids = None if admin.role == "super_admin" else list(org_ids(admin))
    oq = select(func.count(Organization.id)).where(Organization.is_active.is_(True))
    eq = select(func.count(Employee.id)).where(Employee.is_active.is_(True))
    aq = select(func.count(Attendance.id))
    today = datetime.combine(date.today(), time.min, tzinfo=timezone.utc)
    aq = aq.where(Attendance.occurred_at >= today)
    if ids is not None:
        oq = oq.where(Organization.id.in_(ids)); eq = eq.where(Employee.organization_id.in_(ids)); aq = aq.where(Attendance.organization_id.in_(ids))
    return {"organizations": db.scalar(oq) or 0, "employees": db.scalar(eq) or 0, "today_events": db.scalar(aq) or 0,
            "pending_admins": db.scalar(select(func.count(AdminUser.id)).where(AdminUser.is_approved.is_(False))) if admin.role == "super_admin" else 0}

@router.get("/organizations")
def list_organizations(admin: AdminUser = Depends(require_permission("org.read")), db: Session = Depends(get_db)):
    q = select(Organization).order_by(Organization.name)
    if admin.role != "super_admin": q = q.where(Organization.id.in_(list(org_ids(admin))))
    return list(db.scalars(q).all())

@router.post("/organizations")
def create_organization(body: OrganizationCreate, admin: AdminUser = Depends(require_permission("org.create")), db: Session = Depends(get_db)):
    if db.scalar(select(Organization).where((Organization.name == body.name) | (Organization.code == body.code.upper()))):
        raise HTTPException(409, "Tashkilot nomi yoki kodi mavjud")
    org = Organization(
        name=body.name.strip(), code=body.code.upper().strip(), location_mode=body.location_mode,
        employee_auto_approve=body.employee_auto_approve, timezone=body.timezone,
        work_start=body.work_start, work_end=body.work_end, grace_minutes=body.grace_minutes,
    )
    db.add(org); db.flush()
    if admin.role != "super_admin": db.add(AdminOrganization(admin_id=admin.id, organization_id=org.id))
    add_audit(db, admin.id, "organization.create", "organization", str(org.id), {"name": org.name})
    db.commit(); db.refresh(org)
    return org

@router.patch("/organizations/{organization_id}")
def update_organization(organization_id: int, body: OrganizationUpdate, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    for k, v in body.model_dump(exclude_unset=True).items(): setattr(org, k, v.upper() if k == "code" and isinstance(v, str) else v)
    add_audit(db, admin.id, "organization.update", "organization", str(org.id), body.model_dump(exclude_unset=True))
    db.commit(); db.refresh(org); return org

@router.delete("/organizations/{organization_id}")
def delete_organization(organization_id: int, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    org.is_active = False
    add_audit(db, admin.id, "organization.deactivate", "organization", str(org.id))
    db.commit(); return {"detail": "Tashkilot faolsizlantirildi"}

@router.get("/admins")
def list_admins(admin: AdminUser = Depends(require_permission("admin.read")), db: Session = Depends(get_db)):
    rows = db.scalars(select(AdminUser).order_by(AdminUser.created_at.desc())).unique().all()
    if admin.role == "super_admin": return [admin_json(a) for a in rows]
    mine = org_ids(admin)
    return [admin_json(a) for a in rows if org_ids(a) & mine]

@router.post("/admins")
def create_admin(body: AdminCreate, admin: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin admin yarata oladi")
    if db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip())): raise HTTPException(409, "Login band")
    a = AdminUser(full_name=body.full_name.strip(), username=body.username.lower().strip(), password_hash=hash_password(body.password),
                  role=body.role, permissions=body.permissions, is_approved=body.is_approved)
    db.add(a); db.flush()
    for oid in sorted(set(body.organization_ids)):
        if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
        db.add(AdminOrganization(admin_id=a.id, organization_id=oid))
    add_audit(db, admin.id, "admin.create", "admin", str(a.id), {"username": a.username, "role": a.role})
    db.commit(); db.refresh(a); return admin_json(a)

@router.patch("/admins/{admin_id}")
def update_admin(admin_id: int, body: AdminUpdate, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin admin huquqlarini o'zgartira oladi")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    if target.role == "super_admin" and target.id != actor.id: raise HTTPException(403, "Boshqa Super Adminni bu endpoint orqali o'zgartirib bo'lmaydi")
    data = body.model_dump(exclude_unset=True)
    orgs = data.pop("organization_ids", None)
    for k, v in data.items(): setattr(target, k, v)
    if orgs is not None:
        target.org_links.clear(); db.flush()
        for oid in sorted(set(orgs)):
            if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
            target.org_links.append(AdminOrganization(organization_id=oid))
    target.token_version += 1
    add_audit(db, actor.id, "admin.update", "admin", str(target.id), body.model_dump(exclude_unset=True))
    db.commit(); db.refresh(target); return admin_json(target)

@router.post("/admins/{admin_id}/approve")
def approve_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_approved = True; target.is_active = True; target.token_version += 1
    add_audit(db, actor.id, "admin.approve", "admin", str(target.id)); db.commit(); return {"detail": "Tasdiqlandi"}

@router.post("/admins/{admin_id}/reset-password")
def reset_password(admin_id: int, body: ResetPassword, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.password_hash = hash_password(body.new_password); target.token_version += 1
    add_audit(db, actor.id, "admin.reset_password", "admin", str(target.id)); db.commit(); return {"detail": "Parol almashtirildi"}

@router.delete("/admins/{admin_id}")
def delete_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    if actor.id == admin_id: raise HTTPException(409, "O'zingizni o'chira olmaysiz")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_active = False; target.token_version += 1
    add_audit(db, actor.id, "admin.deactivate", "admin", str(target.id)); db.commit(); return {"detail": "Admin faolsizlantirildi"}

@router.get("/employees")
def list_employees(organization_id: int | None = None, admin: AdminUser = Depends(require_permission("employee.read")), db: Session = Depends(get_db)):
    q = select(Employee).order_by(Employee.full_name)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Employee.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    rows = db.scalars(q).all()
    return [{"id": e.id, "full_name": e.full_name, "employee_code": e.employee_code, "organization_id": e.organization_id,
             "organization_name": e.organization.name, "is_active": e.is_active, "is_approved": e.is_approved,
             "device_bound": bool(e.device_id), "created_at": e.created_at} for e in rows]

@router.patch("/employees/{employee_id}")
def update_employee(employee_id: int, body: EmployeeUpdate, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id)
    data = body.model_dump(exclude_unset=True)
    if "organization_id" in data: can_access_org(admin, data["organization_id"])
    for k, v in data.items(): setattr(e, k, v)
    e.token_version += 1
    add_audit(db, admin.id, "employee.update", "employee", str(e.id), data); db.commit(); db.refresh(e); return {"detail": "Saqlandi"}

@router.post("/employees/{employee_id}/approve")
def approve_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.is_approved = True; e.is_active = True; e.token_version += 1
    add_audit(db, admin.id, "employee.approve", "employee", str(e.id)); db.commit(); return {"detail": "Tasdiqlandi"}

@router.post("/employees/{employee_id}/reset-device")
def reset_device(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.device_id = None; e.token_version += 1
    add_audit(db, admin.id, "employee.reset_device", "employee", str(e.id)); db.commit(); return {"detail": "Qurilma bog'lanishi bekor qilindi"}

@router.delete("/employees/{employee_id}")
def delete_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.is_active = False; e.token_version += 1
    add_audit(db, admin.id, "employee.deactivate", "employee", str(e.id)); db.commit(); return {"detail": "Xodim faolsizlantirildi"}

@router.get("/attendance")
def attendance(organization_id: int | None = None, limit: int = Query(200, ge=1, le=1000), admin: AdminUser = Depends(require_permission("attendance.read")), db: Session = Depends(get_db)):
    q = select(Attendance).order_by(Attendance.occurred_at.desc()).limit(limit)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Attendance.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Attendance.organization_id.in_(list(org_ids(admin))))
    rows = db.scalars(q).all()
    return [{"id": r.id, "employee_id": r.employee_id, "employee_name": r.employee.full_name,
             "organization_id": r.organization_id, "organization_name": r.organization.name, "event_type": r.event_type,
             "occurred_at": r.occurred_at, "latitude": r.latitude, "longitude": r.longitude,
             "accuracy_m": r.accuracy_m, "is_mocked": r.is_mocked, "face_distance": r.face_distance,
             "face_threshold": r.face_threshold, "anti_spoof_score": r.anti_spoof_score,
             "schedule_status": r.schedule_status, "minutes_delta": r.minutes_delta} for r in rows]

@router.get("/reports/monthly.xlsx")
def report(organization_id: int, year: int, month: int, admin: AdminUser = Depends(require_permission("report.read")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    if month < 1 or month > 12: raise HTTPException(422, "Oy 1..12 bo'lishi kerak")
    data = monthly_xlsx(db, organization_id, year, month)
    filename = f"davomat_{organization_id}_{year}_{month:02d}.xlsx"
    return Response(content=data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})

@router.get("/audit")
def audit(limit: int = Query(300, ge=1, le=1000), admin: AdminUser = Depends(require_permission("audit.read")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)).all()
    return [{"id": x.id, "actor_admin_id": x.actor_admin_id, "action": x.action, "target_type": x.target_type,
             "target_id": x.target_id, "details": x.details, "created_at": x.created_at} for x in rows]

from datetime import datetime, timezone, timedelta, time as dtime
from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from zoneinfo import ZoneInfo
from app.api.deps import current_employee
from app.db.session import get_db
from app.models.entities import Employee, Attendance, AttendanceType
from app.services.biometric_crypto import decrypt_embedding
from app.services.face import extract_embedding, verify_embedding, FaceError

router = APIRouter(prefix="/attendance", tags=["attendance"])


def _schedule_status(emp: Employee, event_type: str, occurred_at: datetime) -> tuple[str | None, int | None]:
    org = emp.organization
    try:
        tz = ZoneInfo(org.timezone or "Asia/Tashkent")
    except Exception:
        tz = ZoneInfo("Asia/Tashkent")
    local = occurred_at.astimezone(tz)
    try:
        sh, sm = [int(x) for x in (org.work_start or "09:00").split(":", 1)]
        eh, em = [int(x) for x in (org.work_end or "18:00").split(":", 1)]
    except Exception:
        sh, sm, eh, em = 9, 0, 18, 0
    if event_type == AttendanceType.checkin.value:
        scheduled = local.replace(hour=sh, minute=sm, second=0, microsecond=0) + timedelta(minutes=org.grace_minutes or 0)
        if local <= scheduled:
            return "on_time", 0
        minutes = max(1, int((local - scheduled).total_seconds() // 60))
        return "late", minutes
    scheduled_end = local.replace(hour=eh, minute=em, second=0, microsecond=0)
    if local < scheduled_end:
        minutes = max(1, int((scheduled_end - local).total_seconds() // 60))
        return "early_leave", minutes
    return "normal_checkout", 0


async def _record(event_type: str, latitude: float, longitude: float, accuracy_m: float | None, is_mocked: bool,
                  selfie: UploadFile, emp: Employee, device_id: str, db: Session):
    if not emp.is_approved:
        raise HTTPException(403, "Admin xodim ro'yxatdan o'tishini hali tasdiqlamagan")
    if is_mocked:
        raise HTTPException(403, "Mock/Fake GPS aniqlangan")
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise HTTPException(422, "GPS koordinata noto'g'ri")
    if accuracy_m is not None and accuracy_m > 200:
        raise HTTPException(422, "GPS aniqligi juda past. Ochiq joyda qayta urinib ko'ring.")
    try:
        probe, anti_score = extract_embedding(await selfie.read(), require_liveness=True)
    except FaceError as exc:
        raise HTTPException(422, str(exc))
    ok, distance, threshold = verify_embedding(decrypt_embedding(emp.face_embedding_enc), probe)
    if not ok:
        raise HTTPException(403, f"Yuz xodimga mos kelmadi ({distance:.3f} > {threshold:.3f})")

    last = db.scalar(select(Attendance).where(Attendance.employee_id == emp.id).order_by(Attendance.occurred_at.desc()).limit(1))
    if event_type == AttendanceType.checkin.value and last and last.event_type == AttendanceType.checkin.value:
        raise HTTPException(409, "Oldin ishga kelish qayd etilgan. Avval ishdan ketishni bosing.")
    if event_type == AttendanceType.checkout.value and (not last or last.event_type != AttendanceType.checkin.value):
        raise HTTPException(409, "Ishdan ketishdan oldin ishga kelish qaydi bo'lishi kerak.")

    occurred_at = datetime.now(timezone.utc)
    schedule_status, minutes_delta = _schedule_status(emp, event_type, occurred_at)
    row = Attendance(employee_id=emp.id, organization_id=emp.organization_id, event_type=event_type,
                     occurred_at=occurred_at, latitude=latitude, longitude=longitude,
                     accuracy_m=accuracy_m, is_mocked=False, face_distance=distance,
                     face_threshold=threshold, anti_spoof_score=anti_score,
                     schedule_status=schedule_status, minutes_delta=minutes_delta, device_id=device_id)
    db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, "event_type": row.event_type, "occurred_at": row.occurred_at,
            "latitude": row.latitude, "longitude": row.longitude, "face_distance": distance,
            "face_threshold": threshold, "anti_spoof_score": anti_score,
            "schedule_status": schedule_status, "minutes_delta": minutes_delta}

@router.post("/checkin")
async def checkin(latitude: float = Form(...), longitude: float = Form(...), accuracy_m: float | None = Form(None),
                  is_mocked: bool = Form(False), selfie: UploadFile = File(...),
                  x_device_id: str = Header(..., alias="X-Device-ID"), emp: Employee = Depends(current_employee), db: Session = Depends(get_db)):
    return await _record("checkin", latitude, longitude, accuracy_m, is_mocked, selfie, emp, x_device_id, db)

@router.post("/checkout")
async def checkout(latitude: float = Form(...), longitude: float = Form(...), accuracy_m: float | None = Form(None),
                   is_mocked: bool = Form(False), selfie: UploadFile = File(...),
                   x_device_id: str = Header(..., alias="X-Device-ID"), emp: Employee = Depends(current_employee), db: Session = Depends(get_db)):
    return await _record("checkout", latitude, longitude, accuracy_m, is_mocked, selfie, emp, x_device_id, db)

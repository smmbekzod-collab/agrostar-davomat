import secrets
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.db.session import get_db
from app.models.entities import Employee, Organization
from app.schemas.common import TokenPair, RefreshRequest
from app.services.biometric_crypto import encrypt_embedding, decrypt_embedding
from app.services.face import extract_embedding, verify_embedding, FaceError

router = APIRouter(prefix="/employee-auth", tags=["employee-auth"])


def tokens(emp: Employee) -> TokenPair:
    return TokenPair(
        access_token=create_access_token(str(emp.id), "employee", emp.token_version),
        refresh_token=create_refresh_token(str(emp.id), "employee", emp.token_version),
    )

@router.post("/register", response_model=TokenPair)
async def register(full_name: str = Form(...), organization_id: int = Form(...), device_id: str = Form(...), selfie: UploadFile = File(...), db: Session = Depends(get_db)):
    name = " ".join(full_name.split()).strip()
    if len(name) < 3:
        raise HTTPException(422, "F.I.O. noto'g'ri")
    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    try:
        embedding, _ = extract_embedding(await selfie.read(), require_liveness=True)
    except FaceError as exc:
        raise HTTPException(422, str(exc))
    # Bir xil F.I.O. ga ruxsat beriladi, lekin bir yuz ikkinchi marta ro'yxatdan o'tolmaydi.
    existing_people = db.scalars(select(Employee).where(Employee.organization_id == organization_id, Employee.is_active.is_(True))).all()
    for existing in existing_people:
        try:
            matched, _, _ = verify_embedding(decrypt_embedding(existing.face_embedding_enc), embedding)
        except Exception:
            matched = False
        if matched:
            raise HTTPException(409, "Bu yuz ushbu tashkilotda allaqachon ro'yxatdan o'tgan. Qurilma almashtirilgan bo'lsa admin reset qilsin.")
    emp = Employee(
        full_name=name,
        employee_code=f"EMP-{secrets.token_hex(4).upper()}",
        organization_id=organization_id,
        face_embedding_enc=encrypt_embedding(embedding),
        device_id=device_id,
        is_approved=org.employee_auto_approve,
    )
    db.add(emp); db.commit(); db.refresh(emp)
    return tokens(emp)

@router.post("/relink", response_model=TokenPair)
async def relink(full_name: str = Form(...), organization_id: int = Form(...), device_id: str = Form(...), selfie: UploadFile = File(...), db: Session = Depends(get_db)):
    name = " ".join(full_name.split()).strip()
    candidates = db.scalars(select(Employee).where(Employee.organization_id == organization_id, Employee.full_name.ilike(name), Employee.is_active.is_(True))).all()
    if not candidates:
        raise HTTPException(404, "Xodim topilmadi")
    probe, _ = extract_embedding(await selfie.read(), require_liveness=True)
    best = None
    best_distance = 999.0
    best_threshold = 0.0
    for candidate in candidates:
        ok, distance, threshold = verify_embedding(decrypt_embedding(candidate.face_embedding_enc), probe)
        if ok and distance < best_distance:
            best, best_distance, best_threshold = candidate, distance, threshold
    if best is None:
        raise HTTPException(403, "F.I.O. bo'yicha topilgan profillarning hech biriga yuz mos kelmadi")
    emp = best
    if emp.device_id:
        raise HTTPException(409, "Yuz mos profil topildi, lekin qurilma hali admin tomonidan reset qilinmagan")
    emp.device_id = device_id; emp.token_version += 1
    db.commit(); db.refresh(emp)
    return tokens(emp)

@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        p = decode_token(body.refresh_token)
        if p.get("actor") != "employee" or p.get("typ") != "refresh": raise ValueError()
    except Exception:
        raise HTTPException(401, "Refresh token yaroqsiz")
    emp = db.get(Employee, int(p["sub"]))
    if not emp or not emp.is_active or emp.token_version != int(p.get("ver", 0)):
        raise HTTPException(401, "Sessiya yaroqsiz")
    return tokens(emp)

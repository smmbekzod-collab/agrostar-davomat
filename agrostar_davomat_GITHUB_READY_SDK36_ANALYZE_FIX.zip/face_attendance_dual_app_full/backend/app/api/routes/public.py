from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Organization
from app.schemas.common import OrganizationOut

router = APIRouter(prefix="/public", tags=["public"])

@router.get("/organizations", response_model=list[OrganizationOut])
def organizations(db: Session = Depends(get_db)):
    return list(db.scalars(select(Organization).where(Organization.is_active.is_(True)).order_by(Organization.name)).all())

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import verify_password, hash_password, create_access_token, create_refresh_token, decode_token
from app.db.session import get_db
from app.models.entities import AdminUser, AdminOrganization, Organization
from app.schemas.admin import AdminLogin, AdminRegisterRequest
from app.schemas.common import TokenPair, RefreshRequest

router = APIRouter(prefix="/admin-auth", tags=["admin-auth"])


def tokens(admin: AdminUser) -> TokenPair:
    return TokenPair(
        access_token=create_access_token(str(admin.id), "admin", admin.token_version),
        refresh_token=create_refresh_token(str(admin.id), "admin", admin.token_version),
    )

@router.post("/register-request")
def register_request(body: AdminRegisterRequest, db: Session = Depends(get_db)):
    if db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip())):
        raise HTTPException(409, "Bu login band")
    org = db.get(Organization, body.organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    admin = AdminUser(full_name=" ".join(body.full_name.split()), username=body.username.lower().strip(),
                      password_hash=hash_password(body.password), role="auditor", permissions=[], is_approved=False)
    db.add(admin); db.flush()
    db.add(AdminOrganization(admin_id=admin.id, organization_id=org.id))
    db.commit()
    return {"detail": "So'rov yuborildi. Super Admin tasdiqlashi kerak.", "admin_id": admin.id}

@router.post("/login", response_model=TokenPair)
def login(body: AdminLogin, db: Session = Depends(get_db)):
    admin = db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip()))
    if not admin or not verify_password(body.password, admin.password_hash):
        raise HTTPException(401, "Login yoki parol noto'g'ri")
    if not admin.is_active:
        raise HTTPException(403, "Admin bloklangan")
    if not admin.is_approved:
        raise HTTPException(403, "Super Admin tasdiqlashi kutilmoqda")
    return tokens(admin)

@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        p = decode_token(body.refresh_token)
        if p.get("actor") != "admin" or p.get("typ") != "refresh": raise ValueError()
    except Exception:
        raise HTTPException(401, "Refresh token yaroqsiz")
    admin = db.get(AdminUser, int(p["sub"]))
    if not admin or not admin.is_active or not admin.is_approved or admin.token_version != int(p.get("ver", 0)):
        raise HTTPException(401, "Sessiya yaroqsiz")
    return tokens(admin)

class Organization {
  final int id;
  final String name;
  final String code;
  Organization({required this.id, required this.name, required this.code});
  factory Organization.fromJson(Map<String, dynamic> j) => Organization(
        id: j['id'],
        name: j['name'],
        code: j['code'],
      );
}

class MobileConfig {
  final String employeeReloginMode;
  final bool employeeNameFallbackEnabled;
  final bool employeeRegistrationAreaToggle;
  final bool allowNewEmployeeRegistration;
  final bool maintenanceEnabled;
  final String maintenanceMessage;
  final String reloginHelpText;

  const MobileConfig({
    this.employeeReloginMode = 'face_only',
    this.employeeNameFallbackEnabled = true,
    this.employeeRegistrationAreaToggle = true,
    this.allowNewEmployeeRegistration = true,
    this.maintenanceEnabled = false,
    this.maintenanceMessage = '',
    this.reloginHelpText = 'Tashkilotni tanlang va jonli selfi oling. Tizim yuzingiz orqali akkauntingizni avtomatik aniqlaydi.',
  });

  bool get faceOnlyLogin => employeeReloginMode == 'face_only';

  factory MobileConfig.fromJson(Map<String, dynamic> j) => MobileConfig(
        employeeReloginMode: j['employee_relogin_mode']?.toString() ?? 'face_only',
        employeeNameFallbackEnabled: j['employee_name_fallback_enabled'] ?? true,
        employeeRegistrationAreaToggle: j['employee_registration_area_toggle'] ?? true,
        allowNewEmployeeRegistration: j['allow_new_employee_registration'] ?? true,
        maintenanceEnabled: j['maintenance_enabled'] ?? false,
        maintenanceMessage: j['maintenance_message']?.toString() ?? '',
        reloginHelpText: j['relogin_help_text']?.toString() ??
            'Tashkilotni tanlang va jonli selfi oling. Tizim yuzingiz orqali akkauntingizni avtomatik aniqlaydi.',
      );
}

class EmployeeMe {
  final int id;
  final String fullName;
  final String employeeCode;
  final String organizationName;
  final bool isApproved;
  EmployeeMe({
    required this.id,
    required this.fullName,
    required this.employeeCode,
    required this.organizationName,
    required this.isApproved,
  });
  factory EmployeeMe.fromJson(Map<String, dynamic> j) => EmployeeMe(
        id: j['id'],
        fullName: j['full_name'],
        employeeCode: j['employee_code'],
        organizationName: j['organization_name'],
        isApproved: j['is_approved'] ?? false,
      );
}

class AttendanceItem {
  final int id;
  final String eventType;
  final DateTime occurredAt;
  final double latitude;
  final double longitude;
  final double? accuracy;
  AttendanceItem({
    required this.id,
    required this.eventType,
    required this.occurredAt,
    required this.latitude,
    required this.longitude,
    this.accuracy,
  });
  factory AttendanceItem.fromJson(Map<String, dynamic> j) => AttendanceItem(
        id: j['id'],
        eventType: j['event_type'],
        occurredAt: DateTime.parse(j['occurred_at']),
        latitude: (j['latitude'] as num).toDouble(),
        longitude: (j['longitude'] as num).toDouble(),
        accuracy: (j['accuracy_m'] as num?)?.toDouble(),
      );
}

from __future__ import annotations
from copy import deepcopy
from sqlalchemy.orm import Session
from app.models.entities import SystemSetting

MOBILE_CONFIG_KEY = "mobile_config"

DEFAULT_MOBILE_CONFIG: dict = {
    "version": 1,
    "employee_relogin_mode": "face_only",
    "employee_name_fallback_enabled": True,
    "employee_registration_area_toggle": True,
    "allow_new_employee_registration": True,
    "maintenance_enabled": False,
    "maintenance_message": "",
    "relogin_help_text": (
        "Oldin ro‘yxatdan o‘tgan bo‘lsangiz, tashkilotni tanlang va jonli selfi oling. "
        "Tizim yuzingiz orqali akkauntingizni avtomatik aniqlaydi."
    ),
}


def get_mobile_config(db: Session) -> dict:
    cfg = deepcopy(DEFAULT_MOBILE_CONFIG)
    row = db.get(SystemSetting, MOBILE_CONFIG_KEY)
    if row and isinstance(row.value, dict):
        cfg.update(row.value)
    return cfg


def save_mobile_config(db: Session, patch: dict) -> dict:
    cfg = get_mobile_config(db)
    cfg.update({k: v for k, v in patch.items() if v is not None})
    # Server qo'llab-quvvatlaydigan rejimlar bilangina cheklaymiz.
    if cfg.get("employee_relogin_mode") not in {"face_only", "name_and_face"}:
        cfg["employee_relogin_mode"] = "face_only"
    row = db.get(SystemSetting, MOBILE_CONFIG_KEY)
    if row is None:
        row = SystemSetting(key=MOBILE_CONFIG_KEY, value=cfg)
        db.add(row)
    else:
        row.value = cfg
    db.commit()
    db.refresh(row)
    return get_mobile_config(db)

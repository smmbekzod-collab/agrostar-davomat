from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from sqlalchemy import String, Integer, Boolean, DateTime, Float, ForeignKey, Text, UniqueConstraint, JSON, LargeBinary
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.session import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class AdminRole(str, Enum):
    super_admin = "super_admin"
    org_admin = "org_admin"
    hr_manager = "hr_manager"
    auditor = "auditor"


class AttendanceType(str, Enum):
    checkin = "checkin"
    checkout = "checkout"


class LocationMode(str, Enum):
    anywhere = "anywhere"
    approved_areas = "approved_areas"
    single_site = "single_site"


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    location_mode: Mapped[str] = mapped_column(String(30), default=LocationMode.anywhere.value)
    employee_auto_approve: Mapped[bool] = mapped_column(Boolean, default=True)
    timezone: Mapped[str] = mapped_column(String(64), default="Asia/Tashkent")
    work_start: Mapped[str] = mapped_column(String(5), default="09:00")
    work_end: Mapped[str] = mapped_column(String(5), default="18:00")
    grace_minutes: Mapped[int] = mapped_column(Integer, default=10)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AdminUser(Base):
    __tablename__ = "admin_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    full_name: Mapped[str] = mapped_column(String(200))
    username: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default=AdminRole.auditor.value)
    permissions: Mapped[list[str]] = mapped_column(JSON, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_approved: Mapped[bool] = mapped_column(Boolean, default=False)
    token_version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    org_links: Mapped[list[AdminOrganization]] = relationship(back_populates="admin", cascade="all, delete-orphan")


class AdminOrganization(Base):
    __tablename__ = "admin_organizations"
    __table_args__ = (UniqueConstraint("admin_id", "organization_id", name="uq_admin_org"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    admin_id: Mapped[int] = mapped_column(ForeignKey("admin_users.id", ondelete="CASCADE"), index=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    admin: Mapped[AdminUser] = relationship(back_populates="org_links")
    organization: Mapped[Organization] = relationship()


class Employee(Base):
    __tablename__ = "employees"
    id: Mapped[int] = mapped_column(primary_key=True)
    full_name: Mapped[str] = mapped_column(String(200), index=True)
    employee_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    face_embedding_enc: Mapped[str] = mapped_column(Text)
    device_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_approved: Mapped[bool] = mapped_column(Boolean, default=True)
    token_version: Mapped[int] = mapped_column(Integer, default=1)
    # Ro'yxatdan o'tishda xodim hudud holatini o'zi belgilaydi. GPS bo'yicha avtomatik
    # geofence yo'q; bu faqat ma'muriy izoh va hisobot uchun saqlanadi.
    registration_outside_area: Mapped[bool] = mapped_column(Boolean, default=False)
    registration_area_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    registration_selfie_enc: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    organization: Mapped[Organization] = relationship()


class Attendance(Base):
    __tablename__ = "attendance"
    id: Mapped[int] = mapped_column(primary_key=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"), index=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(20), index=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    accuracy_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_mocked: Mapped[bool] = mapped_column(Boolean, default=False)
    face_distance: Mapped[float | None] = mapped_column(Float, nullable=True)
    face_threshold: Mapped[float | None] = mapped_column(Float, nullable=True)
    anti_spoof_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    schedule_status: Mapped[str | None] = mapped_column(String(30), nullable=True)
    minutes_delta: Mapped[int | None] = mapped_column(Integer, nullable=True)
    device_id: Mapped[str] = mapped_column(String(200))
    selfie_enc: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)
    employee: Mapped[Employee] = relationship()
    organization: Mapped[Organization] = relationship()


class SystemSetting(Base):
    __tablename__ = "system_settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_admin_id: Mapped[int | None] = mapped_column(ForeignKey("admin_users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(100), index=True)
    target_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    target_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

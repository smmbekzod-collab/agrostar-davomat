from datetime import date, datetime, time, timezone, timedelta
from io import BytesIO
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from zoneinfo import ZoneInfo
from app.api.deps import current_admin, require_permission
from app.core.security import hash_password, verify_password
from app.db.session import get_db
from app.models.entities import Organization, AdminUser, AdminOrganization, Employee, Attendance, AuditLog
from app.schemas.admin import OrganizationCreate, OrganizationUpdate, AdminCreate, AdminUpdate, ResetPassword, EmployeeUpdate, ChangeOwnPassword, MobileConfigUpdate
from app.services.audit import add_audit
from app.services.permissions import ALL_PERMISSIONS, effective_permissions
from app.services.report import monthly_xlsx
from app.services.biometric_crypto import decrypt_bytes
from app.services.mobile_config import get_mobile_config, save_mobile_config

router = APIRouter(prefix="/admin", tags=["admin"])


def org_ids(admin: AdminUser) -> set[int]:
    return {x.organization_id for x in admin.org_links}


def can_access_org(admin: AdminUser, organization_id: int):
    if admin.role != "super_admin" and organization_id not in org_ids(admin):
        raise HTTPException(403, "Bu tashkilotga kirish huquqi yo'q")


def admin_json(a: AdminUser) -> dict:
    return {"id": a.id, "full_name": a.full_name, "username": a.username, "role": a.role,
            "permissions": a.permissions or [], "organization_ids": sorted(org_ids(a)),
            "is_active": a.is_active, "is_approved": a.is_approved, "created_at": a.created_at}

@router.get("/me")
def me(admin: AdminUser = Depends(current_admin)):
    return {**admin_json(admin), "effective_permissions": sorted(effective_permissions(admin.role, admin.permissions))}

@router.post("/change-password")
def change_password(body: ChangeOwnPassword, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if not verify_password(body.current_password, admin.password_hash):
        raise HTTPException(403, "Joriy parol noto'g'ri")
    admin.password_hash = hash_password(body.new_password)
    admin.token_version += 1
    add_audit(db, admin.id, "admin.change_own_password", "admin", str(admin.id))
    db.commit()
    return {"detail": "Parol almashtirildi. Qayta kiring."}

@router.get("/permissions")
def permissions(_: AdminUser = Depends(current_admin)):
    return {"permissions": ALL_PERMISSIONS, "roles": ["super_admin", "org_admin", "hr_manager", "auditor"]}

@router.get("/mobile-config")
def admin_mobile_config(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin":
        raise HTTPException(403, "Faqat Super Admin ilova sozlamalarini boshqara oladi")
    return get_mobile_config(db)

@router.patch("/mobile-config")
def update_mobile_config(body: MobileConfigUpdate, admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    if admin.role != "super_admin":
        raise HTTPException(403, "Faqat Super Admin ilova sozlamalarini o'zgartira oladi")
    patch = body.model_dump(exclude_unset=True)
    result = save_mobile_config(db, patch)
    add_audit(db, admin.id, "mobile_config.update", "system", "mobile_config", patch)
    db.commit()
    return result

@router.get("/dashboard")
def dashboard(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    ids = None if admin.role == "super_admin" else list(org_ids(admin))
    oq = select(func.count(Organization.id)).where(Organization.is_active.is_(True))
    eq = select(func.count(Employee.id)).where(Employee.is_active.is_(True))
    aq = select(func.count(Attendance.id))
    today = datetime.combine(date.today(), time.min, tzinfo=timezone.utc)
    aq = aq.where(Attendance.occurred_at >= today)
    if ids is not None:
        oq = oq.where(Organization.id.in_(ids)); eq = eq.where(Employee.organization_id.in_(ids)); aq = aq.where(Attendance.organization_id.in_(ids))
    return {"organizations": db.scalar(oq) or 0, "employees": db.scalar(eq) or 0, "today_events": db.scalar(aq) or 0,
            "pending_admins": db.scalar(select(func.count(AdminUser.id)).where(AdminUser.is_approved.is_(False))) if admin.role == "super_admin" else 0}

@router.get("/organizations")
def list_organizations(admin: AdminUser = Depends(require_permission("org.read")), db: Session = Depends(get_db)):
    q = select(Organization).order_by(Organization.name)
    if admin.role != "super_admin": q = q.where(Organization.id.in_(list(org_ids(admin))))
    return list(db.scalars(q).all())

@router.post("/organizations")
def create_organization(body: OrganizationCreate, admin: AdminUser = Depends(require_permission("org.create")), db: Session = Depends(get_db)):
    if db.scalar(select(Organization).where((Organization.name == body.name) | (Organization.code == body.code.upper()))):
        raise HTTPException(409, "Tashkilot nomi yoki kodi mavjud")
    org = Organization(
        name=body.name.strip(), code=body.code.upper().strip(), location_mode=body.location_mode,
        employee_auto_approve=body.employee_auto_approve, timezone=body.timezone,
        work_start=body.work_start, work_end=body.work_end, grace_minutes=body.grace_minutes,
    )
    db.add(org); db.flush()
    if admin.role != "super_admin": db.add(AdminOrganization(admin_id=admin.id, organization_id=org.id))
    add_audit(db, admin.id, "organization.create", "organization", str(org.id), {"name": org.name})
    db.commit(); db.refresh(org)
    return org

@router.patch("/organizations/{organization_id}")
def update_organization(organization_id: int, body: OrganizationUpdate, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    for k, v in body.model_dump(exclude_unset=True).items(): setattr(org, k, v.upper() if k == "code" and isinstance(v, str) else v)
    add_audit(db, admin.id, "organization.update", "organization", str(org.id), body.model_dump(exclude_unset=True))
    db.commit(); db.refresh(org); return org

@router.delete("/organizations/{organization_id}")
def delete_organization(organization_id: int, admin: AdminUser = Depends(require_permission("org.update")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    org = db.get(Organization, organization_id)
    if not org: raise HTTPException(404, "Tashkilot topilmadi")
    org.is_active = False
    add_audit(db, admin.id, "organization.deactivate", "organization", str(org.id))
    db.commit(); return {"detail": "Tashkilot faolsizlantirildi"}

@router.get("/admins")
def list_admins(admin: AdminUser = Depends(require_permission("admin.read")), db: Session = Depends(get_db)):
    rows = db.scalars(select(AdminUser).order_by(AdminUser.created_at.desc())).unique().all()
    if admin.role == "super_admin": return [admin_json(a) for a in rows]
    mine = org_ids(admin)
    return [admin_json(a) for a in rows if org_ids(a) & mine]

@router.post("/admins")
def create_admin(body: AdminCreate, admin: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin admin yarata oladi")
    if db.scalar(select(AdminUser).where(AdminUser.username == body.username.lower().strip())): raise HTTPException(409, "Login band")
    a = AdminUser(full_name=body.full_name.strip(), username=body.username.lower().strip(), password_hash=hash_password(body.password),
                  role=body.role, permissions=body.permissions, is_approved=body.is_approved)
    db.add(a); db.flush()
    for oid in sorted(set(body.organization_ids)):
        if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
        db.add(AdminOrganization(admin_id=a.id, organization_id=oid))
    add_audit(db, admin.id, "admin.create", "admin", str(a.id), {"username": a.username, "role": a.role})
    db.commit(); db.refresh(a); return admin_json(a)

@router.patch("/admins/{admin_id}")
def update_admin(admin_id: int, body: AdminUpdate, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin admin huquqlarini o'zgartira oladi")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    if target.role == "super_admin" and target.id != actor.id: raise HTTPException(403, "Boshqa Super Adminni bu endpoint orqali o'zgartirib bo'lmaydi")
    data = body.model_dump(exclude_unset=True)
    orgs = data.pop("organization_ids", None)
    for k, v in data.items(): setattr(target, k, v)
    if orgs is not None:
        target.org_links.clear(); db.flush()
        for oid in sorted(set(orgs)):
            if not db.get(Organization, oid): raise HTTPException(404, f"Tashkilot {oid} topilmadi")
            target.org_links.append(AdminOrganization(organization_id=oid))
    target.token_version += 1
    add_audit(db, actor.id, "admin.update", "admin", str(target.id), body.model_dump(exclude_unset=True))
    db.commit(); db.refresh(target); return admin_json(target)

@router.post("/admins/{admin_id}/approve")
def approve_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_approved = True; target.is_active = True; target.token_version += 1
    add_audit(db, actor.id, "admin.approve", "admin", str(target.id)); db.commit(); return {"detail": "Tasdiqlandi"}

@router.post("/admins/{admin_id}/reset-password")
def reset_password(admin_id: int, body: ResetPassword, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.password_hash = hash_password(body.new_password); target.token_version += 1
    add_audit(db, actor.id, "admin.reset_password", "admin", str(target.id)); db.commit(); return {"detail": "Parol almashtirildi"}

@router.delete("/admins/{admin_id}")
def delete_admin(admin_id: int, actor: AdminUser = Depends(require_permission("admin.manage")), db: Session = Depends(get_db)):
    if actor.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    if actor.id == admin_id: raise HTTPException(409, "O'zingizni o'chira olmaysiz")
    target = db.get(AdminUser, admin_id)
    if not target: raise HTTPException(404, "Admin topilmadi")
    target.is_active = False; target.token_version += 1
    add_audit(db, actor.id, "admin.deactivate", "admin", str(target.id)); db.commit(); return {"detail": "Admin faolsizlantirildi"}

@router.get("/employees")
def list_employees(organization_id: int | None = None, admin: AdminUser = Depends(require_permission("employee.read")), db: Session = Depends(get_db)):
    q = select(Employee).order_by(Employee.full_name)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Employee.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    rows = db.scalars(q).all()
    return [{"id": e.id, "full_name": e.full_name, "employee_code": e.employee_code, "organization_id": e.organization_id,
             "organization_name": e.organization.name, "is_active": e.is_active, "is_approved": e.is_approved,
             "device_bound": bool(e.device_id), "created_at": e.created_at,
             "registration_outside_area": e.registration_outside_area,
             "registration_area_note": e.registration_area_note,
             "registration_selfie_available": bool(e.registration_selfie_enc)} for e in rows]


@router.get("/today-status")
def today_status(admin: AdminUser = Depends(current_admin), db: Session = Depends(get_db)):
    """Admin ko'ra oladigan barcha faol xodimlarning bugungi kelish/ketish holati.

    Kun chegarasi har bir tashkilotning timezone'i bo'yicha hisoblanadi.
    """
    q = select(Employee).where(Employee.is_active.is_(True)).order_by(Employee.organization_id, Employee.full_name)
    if admin.role != "super_admin":
        q = q.where(Employee.organization_id.in_(list(org_ids(admin))))
    employees = list(db.scalars(q).all())
    by_org: dict[int, list[Employee]] = {}
    for employee in employees:
        by_org.setdefault(employee.organization_id, []).append(employee)

    now_utc = datetime.now(timezone.utc)
    output: list[dict] = []
    for organization_id, org_employees in by_org.items():
        org = org_employees[0].organization
        try:
            tz = ZoneInfo(org.timezone or "Asia/Tashkent")
        except Exception:
            tz = ZoneInfo("Asia/Tashkent")
        local_now = now_utc.astimezone(tz)
        start_local = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
        end_local = start_local + timedelta(days=1)
        start_utc = start_local.astimezone(timezone.utc)
        end_utc = end_local.astimezone(timezone.utc)
        emp_ids = [e.id for e in org_employees]
        events = list(db.scalars(
            select(Attendance)
            .where(Attendance.employee_id.in_(emp_ids))
            .where(Attendance.occurred_at >= start_utc)
            .where(Attendance.occurred_at < end_utc)
            .order_by(Attendance.occurred_at.asc())
        ).all())
        grouped: dict[int, list[Attendance]] = {}
        for event in events:
            grouped.setdefault(event.employee_id, []).append(event)

        for employee in org_employees:
            own = grouped.get(employee.id, [])
            checkins = [x for x in own if x.event_type == "checkin"]
            checkouts = [x for x in own if x.event_type == "checkout"]
            first_checkin = checkins[0] if checkins else None
            last_checkout = checkouts[-1] if checkouts else None
            if first_checkin and last_checkout:
                state = "completed"
            elif first_checkin:
                state = "working"
            else:
                state = "not_started"
            output.append({
                "employee_id": employee.id,
                "employee_name": employee.full_name,
                "employee_code": employee.employee_code,
                "organization_id": employee.organization_id,
                "organization_name": org.name,
                "is_approved": employee.is_approved,
                "checkin_done": first_checkin is not None,
                "checkout_done": last_checkout is not None,
                "checkin_at": first_checkin.occurred_at if first_checkin else None,
                "checkout_at": last_checkout.occurred_at if last_checkout else None,
                "checkin_attendance_id": first_checkin.id if first_checkin else None,
                "checkout_attendance_id": last_checkout.id if last_checkout else None,
                "checkin_selfie_available": bool(first_checkin and first_checkin.selfie_enc),
                "checkout_selfie_available": bool(last_checkout and last_checkout.selfie_enc),
                "registration_selfie_available": bool(employee.registration_selfie_enc),
                "state": state,
                "registration_outside_area": employee.registration_outside_area,
                "registration_area_note": employee.registration_area_note,
            })
    return output

@router.patch("/employees/{employee_id}")
def update_employee(employee_id: int, body: EmployeeUpdate, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id)
    data = body.model_dump(exclude_unset=True)
    if "organization_id" in data: can_access_org(admin, data["organization_id"])
    for k, v in data.items(): setattr(e, k, v)
    e.token_version += 1
    add_audit(db, admin.id, "employee.update", "employee", str(e.id), data); db.commit(); db.refresh(e); return {"detail": "Saqlandi"}

@router.post("/employees/{employee_id}/approve")
def approve_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.is_approved = True; e.is_active = True; e.token_version += 1
    add_audit(db, admin.id, "employee.approve", "employee", str(e.id)); db.commit(); return {"detail": "Tasdiqlandi"}

@router.post("/employees/{employee_id}/reset-device")
def reset_device(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.device_id = None; e.token_version += 1
    add_audit(db, admin.id, "employee.reset_device", "employee", str(e.id)); db.commit(); return {"detail": "Qurilma bog'lanishi bekor qilindi"}

@router.delete("/employees/{employee_id}")
def delete_employee(employee_id: int, admin: AdminUser = Depends(require_permission("employee.manage")), db: Session = Depends(get_db)):
    e = db.get(Employee, employee_id)
    if not e: raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, e.organization_id); e.is_active = False; e.token_version += 1
    add_audit(db, admin.id, "employee.deactivate", "employee", str(e.id)); db.commit(); return {"detail": "Xodim faolsizlantirildi"}

@router.get("/employees/{employee_id}/registration-selfie")
def employee_registration_selfie(
    employee_id: int,
    admin: AdminUser = Depends(require_permission("employee.read")),
    db: Session = Depends(get_db),
):
    employee = db.get(Employee, employee_id)
    if not employee:
        raise HTTPException(404, "Xodim topilmadi")
    can_access_org(admin, employee.organization_id)
    if not employee.registration_selfie_enc:
        raise HTTPException(404, "Ro'yxatdan o'tish selfisi saqlanmagan")
    return Response(
        content=decrypt_bytes(employee.registration_selfie_enc),
        media_type="image/jpeg",
        headers={"Cache-Control": "private, no-store", "Content-Disposition": f'inline; filename="employee_{employee.id}_registration.jpg"'},
    )


@router.get("/attendance/{attendance_id}/selfie")
def attendance_selfie(
    attendance_id: int,
    admin: AdminUser = Depends(require_permission("attendance.read")),
    db: Session = Depends(get_db),
):
    row = db.get(Attendance, attendance_id)
    if not row:
        raise HTTPException(404, "Davomat yozuvi topilmadi")
    can_access_org(admin, row.organization_id)
    if not row.selfie_enc:
        raise HTTPException(404, "Bu yozuv uchun selfi saqlanmagan")
    return Response(
        content=decrypt_bytes(row.selfie_enc),
        media_type="image/jpeg",
        headers={"Cache-Control": "private, no-store", "Content-Disposition": f'inline; filename="attendance_{row.id}.jpg"'},
    )


@router.get("/attendance")
def attendance(organization_id: int | None = None, limit: int = Query(200, ge=1, le=1000), admin: AdminUser = Depends(require_permission("attendance.read")), db: Session = Depends(get_db)):
    q = select(Attendance).order_by(Attendance.occurred_at.desc()).limit(limit)
    if organization_id is not None:
        can_access_org(admin, organization_id); q = q.where(Attendance.organization_id == organization_id)
    elif admin.role != "super_admin": q = q.where(Attendance.organization_id.in_(list(org_ids(admin))))
    rows = db.scalars(q).all()
    return [{"id": r.id, "employee_id": r.employee_id, "employee_name": r.employee.full_name,
             "organization_id": r.organization_id, "organization_name": r.organization.name, "event_type": r.event_type,
             "occurred_at": r.occurred_at, "latitude": r.latitude, "longitude": r.longitude,
             "accuracy_m": r.accuracy_m, "is_mocked": r.is_mocked, "face_distance": r.face_distance,
             "face_threshold": r.face_threshold, "anti_spoof_score": r.anti_spoof_score,
             "schedule_status": r.schedule_status, "minutes_delta": r.minutes_delta,
             "selfie_available": bool(r.selfie_enc)} for r in rows]

@router.get("/reports/monthly.xlsx")
def report(organization_id: int, year: int, month: int, admin: AdminUser = Depends(require_permission("report.read")), db: Session = Depends(get_db)):
    can_access_org(admin, organization_id)
    if month < 1 or month > 12: raise HTTPException(422, "Oy 1..12 bo'lishi kerak")
    data = monthly_xlsx(db, organization_id, year, month)
    filename = f"davomat_{organization_id}_{year}_{month:02d}.xlsx"
    return Response(content=data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})

@router.get("/audit")
def audit(limit: int = Query(300, ge=1, le=1000), admin: AdminUser = Depends(require_permission("audit.read")), db: Session = Depends(get_db)):
    if admin.role != "super_admin": raise HTTPException(403, "Faqat Super Admin")
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)).all()
    return [{"id": x.id, "actor_admin_id": x.actor_admin_id, "action": x.action, "target_type": x.target_type,
             "target_id": x.target_id, "details": x.details, "created_at": x.created_at} for x in rows]

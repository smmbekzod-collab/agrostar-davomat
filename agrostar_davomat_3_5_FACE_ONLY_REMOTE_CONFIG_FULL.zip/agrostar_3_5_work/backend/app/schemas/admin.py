from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pydantic import BaseModel, Field, field_validator
from app.services.permissions import ALL_PERMISSIONS

AdminRoleName = Literal["super_admin", "org_admin", "hr_manager", "auditor"]


def _valid_hhmm(value: str) -> str:
    value = value.strip()
    parts = value.split(":")
    if len(parts) != 2:
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak")
    try:
        hour, minute = int(parts[0]), int(parts[1])
    except ValueError as exc:
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak") from exc
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("Vaqt HH:MM formatida bo'lishi kerak")
    return f"{hour:02d}:{minute:02d}"


def _valid_timezone(value: str) -> str:
    value = value.strip()
    try:
        ZoneInfo(value)
    except ZoneInfoNotFoundError as exc:
        raise ValueError("Timezone noto'g'ri") from exc
    return value


def _valid_permissions(values: list[str]) -> list[str]:
    unknown = sorted(set(values) - set(ALL_PERMISSIONS))
    if unknown:
        raise ValueError(f"Noma'lum permission: {', '.join(unknown)}")
    return sorted(set(values))


class AdminLogin(BaseModel):
    username: str
    password: str


class AdminRegisterRequest(BaseModel):
    full_name: str = Field(min_length=3, max_length=200)
    username: str = Field(min_length=4, max_length=100)
    password: str = Field(min_length=8, max_length=128)
    organization_id: int


class OrganizationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    code: str = Field(min_length=2, max_length=50)
    # Hozirgi biznes talabi: barcha xodimlar istalgan real GPS nuqtadan davomat qiladi.
    location_mode: Literal["anywhere"] = "anywhere"
    employee_auto_approve: bool = True
    timezone: str = "Asia/Tashkent"
    work_start: str = "09:00"
    work_end: str = "18:00"
    grace_minutes: int = Field(default=10, ge=0, le=180)

    _timezone = field_validator("timezone")(_valid_timezone)
    _work_start = field_validator("work_start")(_valid_hhmm)
    _work_end = field_validator("work_end")(_valid_hhmm)


class OrganizationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=200)
    code: str | None = Field(default=None, min_length=2, max_length=50)
    is_active: bool | None = None
    location_mode: Literal["anywhere"] | None = None
    employee_auto_approve: bool | None = None
    timezone: str | None = None
    work_start: str | None = None
    work_end: str | None = None
    grace_minutes: int | None = Field(default=None, ge=0, le=180)

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, value: str | None) -> str | None:
        return None if value is None else _valid_timezone(value)

    @field_validator("work_start", "work_end")
    @classmethod
    def validate_time(cls, value: str | None) -> str | None:
        return None if value is None else _valid_hhmm(value)


class AdminCreate(BaseModel):
    full_name: str = Field(min_length=3, max_length=200)
    username: str = Field(min_length=4, max_length=100)
    password: str = Field(min_length=8, max_length=128)
    role: AdminRoleName = "org_admin"
    permissions: list[str] = Field(default_factory=list)
    organization_ids: list[int] = Field(default_factory=list)
    is_approved: bool = True

    _permissions = field_validator("permissions")(_valid_permissions)


class AdminUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=3, max_length=200)
    role: AdminRoleName | None = None
    permissions: list[str] | None = None
    organization_ids: list[int] | None = None
    is_active: bool | None = None
    is_approved: bool | None = None

    @field_validator("permissions")
    @classmethod
    def validate_permissions(cls, value: list[str] | None) -> list[str] | None:
        return None if value is None else _valid_permissions(value)


class ResetPassword(BaseModel):
    new_password: str = Field(min_length=8, max_length=128)


class EmployeeUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=3, max_length=200)
    organization_id: int | None = None
    is_active: bool | None = None
    is_approved: bool | None = None


class ChangeOwnPassword(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class MobileConfigUpdate(BaseModel):
    employee_relogin_mode: Literal["face_only", "name_and_face"] | None = None
    employee_name_fallback_enabled: bool | None = None
    employee_registration_area_toggle: bool | None = None
    allow_new_employee_registration: bool | None = None
    maintenance_enabled: bool | None = None
    maintenance_message: str | None = Field(default=None, max_length=500)
    relogin_help_text: str | None = Field(default=None, max_length=1000)

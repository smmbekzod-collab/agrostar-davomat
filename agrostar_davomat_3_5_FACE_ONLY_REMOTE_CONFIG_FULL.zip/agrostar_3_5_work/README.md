# Dual Face Attendance — 2 ta Android ilova + FastAPI

Tizim uch qismdan iborat:

```text
employee_app/  -> Agro Star Hodim Android ilovasi
admin_app/     -> Davomat Admin Android ilovasi
backend/       -> FastAPI + PostgreSQL + DeepFace/FaceNet512 + XLSX
```

Android package ID lar:

- Hodim: `uz.bekzoddiki.agrostar.employee`
- Admin: `uz.bekzoddiki.agrostar.admin`

Ikki APK bir telefonga bir vaqtda o‘rnatilishi mumkin.

## 1. Siz so‘ragan ishlash tartibi

### Hodim

1. Ilovani ochadi.
2. F.I.O. kiritadi.
3. Tashkilotni tanlaydi. `Oltiariq-Agro Star` serverda avtomatik mavjud bo‘ladi.
4. Faqat old kamera orqali selfi oladi.
5. Server DeepFace anti-spoofing + FaceNet512 embedding yaratadi.
6. `ISHGA KELDIM` yoki `ISHDAN KETDIM` bosilganda telefon ayni GPS koordinatasini oladi va yana jonli selfi oladi.
7. Fake/mock GPS aniqlansa yozuv qabul qilinmaydi.
8. Yuz etalonga mos kelsa davomat saqlanadi.

**Muhim:** xodimlar turli tumanlarda ishlashi mumkin. Bitta markaziy GPS nuqta yoki radius yo‘q. GPS xodimni bloklash uchun emas, davomat qayerda qilinganini qayd etish uchun ishlatiladi.

### Admin

Admin App quyidagilarni bajaradi:

- Dashboard statistika.
- Tashkilot qo‘shish va faolsizlantirish.
- `Oltiariq-Agro Star` boshlang‘ich tashkiloti.
- Admin o‘zi tashkilotni tanlab ro‘yxatdan o‘tish so‘rovi yuborishi.
- Super Admin yangi admin yaratishi.
- Har bir adminni bir yoki bir nechta tashkilotga biriktirish.
- `org_admin`, `hr_manager`, `auditor`, `super_admin` rollari.
- Individual permissionlar.
- Adminni tasdiqlash, rol/huquq/tashkilotlarini o‘zgartirish, parolini reset qilish, faolsizlantirish.
- Xodimlarni ko‘rish/tasdiqlash/faolsizlantirish.
- Xodim qurilmasini zarurat bo‘lsa Admin paneldan reset qilish (endi majburiy emas; jonli yuz bilan qayta kirishda qurilma avtomatik ko‘chadi).
- Har bir kelish/ketish GPS koordinatasini ko‘rish.
- GPS nuqtasini Google Maps’da ochish.
- Face distance va thresholdni ko‘rish.
- Oylik Excel hisobot.
- Super Admin audit jurnali.

## 2. GitHub orqali 2 ta APK yaratish

Loyiha aynan GitHub Actions uchun tayyorlangan. Lokal kompyuterda Flutter o‘rnatish shart emas.

### A. GitHub repository yarating

GitHub’da yangi repository oching va ushbu ZIP ichidagi **hamma fayl/papkalarni repository rootiga** yuklang.

Repositoryda quyidagilar ko‘rinishi kerak:

```text
.github/workflows/build-apks.yml
.github/workflows/backend-ci.yml
admin_app/
employee_app/
backend/
scripts/
docker-compose.yml
README.md
```

### B. API server manzilini kiriting

GitHub repository:

`Settings -> Secrets and variables -> Actions -> Variables -> New repository variable`

Nom:

```text
API_BASE_URL
```

Qiymat misoli:

```text
https://api.sizningdomeningiz.uz/api/v1
```

**HTTPS tavsiya qilinadi.** APK build qilinishidan oldin backend shu manzilda ishlashi kerak.

### C. APK build

GitHub:

`Actions -> Build Android APKs -> Run workflow`

Workflow Flutter **3.47.2** o‘rnatadi, har ikki loyiha uchun Android platform fayllarini yangidan generatsiya qiladi, kerakli Android Camera/GPS permissionlarini patch qiladi, `flutter analyze` bajaradi va keyin release APK yaratadi.

Natijada GitHub Actions sahifasining `Artifacts` qismida:

```text
agrostar-employee-apk  -> agrostar-hodim.apk
attendance-admin-apk   -> davomat-admin.apk
apk-checksums           -> SHA256SUMS.txt
```

chiqadi.

### D. Tavsiya: bir xil release signing kalitini GitHub Secretsga qo‘ying

Agar signing secretlari qo‘yilmasa workflow APKni test uchun debug signing bilan chiqaradi. Bir APK ustiga keyingi versiyani yangilab o‘rnatish va rasmiy tarqatish uchun **bir xil doimiy keystore** ishlating.

Keystore yarating:

```bash
keytool -genkey -v -keystore upload-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

Linux/macOS’da base64:

```bash
base64 -w 0 upload-keystore.jks
```

GitHub: `Settings -> Secrets and variables -> Actions -> Secrets` bo‘limiga quyidagilarni kiriting:

```text
ANDROID_KEYSTORE_BASE64     = keystore faylining base64 matni
ANDROID_KEYSTORE_PASSWORD   = keystore paroli
ANDROID_KEY_ALIAS           = upload
ANDROID_KEY_PASSWORD        = key paroli
```

Workflow secretlar mavjud bo‘lsa ikkala APKni shu doimiy kalit bilan imzolaydi. Har buildda `github.run_number` Android `versionCode` sifatida beriladi, shuning uchun keyingi build eski APK ustiga update bo‘lib o‘rnashi mumkin.

### Nega `android/` papkasi repositoryga qotirib qo‘yilmagan?

Flutter/Gradle/Android plugin versiyalari vaqt o‘tishi bilan o‘zgaradi. Workflow `scripts/bootstrap_android.sh` orqali Flutter 3.47.2 ning o‘zidan toza Android scaffold yaratadi. Shunda eski Gradle wrapper muammolari kamayadi va package ID/permissionlar avtomatik qo‘llanadi.

## 3. Backend serverni ishga tushirish

Server uchun Docker va Docker Compose bo‘lgan Ubuntu VPS tavsiya qilinadi.

```bash
cp backend/.env.example backend/.env
```

`backend/.env` ichida kamida bularni almashtiring:

```text
DATABASE_URL=postgresql+psycopg://attendance:DB_PASSWORD@db:5432/attendance
SECRET_KEY=...
BIOMETRIC_KEY=...
SUPERADMIN_USERNAME=superadmin
SUPERADMIN_PASSWORD=JUDA_KUCHLI_PAROL
```

Secret key yaratish:

```bash
python -c "import secrets; print(secrets.token_hex(64))"
```

Fernet biometrik kalit:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

PostgreSQL paroli docker compose uchun:

```bash
export POSTGRES_PASSWORD='DB_PASSWORD'
docker compose up -d --build
```

Tekshirish:

```text
http://SERVER_IP:8000/health
http://SERVER_IP:8000/docs
```

Productionda Caddy yoki Nginx bilan HTTPS qo‘ying. `Caddyfile.example` namuna sifatida berilgan.

## 4. Birinchi kirish

Backend birinchi ishga tushganda avtomatik:

- `Oltiariq-Agro Star` (`AGROSTAR`)
- `.env` dagi `SUPERADMIN_USERNAME`
- `.env` dagi `SUPERADMIN_PASSWORD`

bo‘yicha Super Admin yaratadi.

Admin Appga shu login/parol bilan kiring. Keyin:

1. boshqa tashkilotlarni qo‘shing;
2. Adminlar bo‘limidan admin yarating yoki kelgan admin so‘rovini tasdiqlang;
3. admin uchun rol va tashkilot(lar)ni belgilang;
4. kerak bo‘lsa individual permission bering.

## 5. GPS siyosati

Hozirgi talabingiz bo‘yicha barcha tashkilotlar standart:

```text
location_mode = anywhere
```

Davomatda server quyidagilarni saqlaydi:

- latitude;
- longitude;
- GPS accuracy;
- mock/fake GPS belgisi;
- vaqt;
- device id;
- face distance;
- face threshold;
- anti-spoof score.

Server **masofani tashkilot markaziga solishtirmaydi**. Shu sabab Oltiariq, Qo‘qon, Rishton, Bag‘dod yoki boshqa hududdagi xodim o‘sha turgan joyidan davomat qilishi mumkin.

## 6. Biometrik xavfsizlik

- FaceNet512 embedding olinadi va Fernet bilan shifrlanib PostgreSQLga yoziladi.
- 3.2.0 dan boshlab ro'yxatdan o'tish hamda Keldim/Ketdim audit selfilari ham saqlanadi.
- Audit selfilari orientatsiyasi to'g'rilanib, maksimal 720 px gacha kichraytiriladi va JPEG sifatida siqiladi.
- Selfi JPEG ham `BIOMETRIC_KEY` orqali Fernet bilan shifrlanib PostgreSQL `BYTEA` ustunida saqlanadi; admin ko'rishda va Excel generatsiyasida server ichida vaqtincha ochiladi.
- Har davomatda DeepFace anti-spoofing ishlaydi.
- Kamera faqat old kamera.
- Bir kadrda aynan bitta yuz talab qilinadi.
- Hodim tokeni Admin API’da ishlamaydi va Admin tokeni Hodim API’da ishlamaydi.
- JWT `token_version` orqali admin/xodim sessiyasini majburan bekor qilish mumkin.
- Admin amallari audit logga yoziladi.
- O‘chirishlar tarixni yo‘qotmaslik uchun soft-deactivate usulida.

DeepFace anti-spoofing foydali himoya, lekin bank/KYC darajasidagi sertifikatlangan active-liveness o‘rnini bosmaydi. Juda yuqori xavfsizlik kerak bo‘lsa keyinchalik maxsus liveness SDK ulash tavsiya etiladi.

## 7. Flutter paketlari

Asosiy paketlar:

- `camera: ^0.12.1`
- `geolocator: 14.0.2`
- `dio: ^5.9.0`
- `flutter_secure_storage`
- `share_plus`

Hodim App Android runtime’da kamera va location permissionlarini so‘raydi. Manifest permissionlari GitHub build vaqtida `scripts/patch_android.py` bilan qo‘shiladi. Android min SDK 24 qilib belgilanadi.

## 8. Muhim production ishlari

Real foydalanishdan oldin:

- domen + HTTPS o‘rnating;
- `.env` default parollarini albatta almashtiring;
- PostgreSQL backup tashkil qiling;
- biometrik ma’lumot va xodim GPS ma’lumotlarini qayta ishlash uchun tashkilotning rozilik/maxfiylik siyosatini tasdiqlang;
- birinchi real xodimlar bilan Face thresholdni sinovdan o‘tkazing;
- GitHub artifact APK test uchun ishlaydi; Google Play yoki rasmiy distributsiya uchun alohida release keystore bilan signing tashkil qiling.

## 9. Loyiha tekshiruvi

Backend Python manbalari `python -m compileall` bilan tekshiriladi. GitHub APK workflow esa har ikkala Flutter ilovada `flutter analyze` muvaffaqiyatli o‘tmasa buildni to‘xtatadi. Shu sabab GitHub’da chiqarilgan APK analyzer/build bosqichlaridan o‘tgan versiya bo‘ladi.

## 9. 3.1.0 yangilanishi — ro‘yxatdan o‘tish hududi va bugungi holat

Hodim ro‘yxatdan o‘tish ekranida **“Belgilangan hududda emasman”** belgisi mavjud.

- Belgi qo‘yilmasa ro‘yxatdan o‘tish odatdagidek davom etadi va izoh talab qilinmaydi.
- Belgi qo‘yilsa **Sababi / izoh** maydoni ochiladi va kamida 3 belgili izoh majburiy bo‘ladi.
- Bu geofence emas: tizim aniq hudud koordinatasini tekshirmaydi. Xodim holatni o‘zi belgilaydi.
- Ro‘yxatdan o‘tish holati va izohi Admin App’dagi Xodimlar bo‘limida hamda Excel hisobotda ko‘rinadi.

Admin/Super Admin boshqaruv sahifasida **Bugungi xodimlar holati** ko‘rsatiladi:

- `Keldim: HH:MM` yoki `Keldim qilmagan`;
- `Ketdim: HH:MM` yoki `Ketdim qilmagan`;
- admin faqat o‘ziga biriktirilgan tashkilot xodimlarini, Super Admin esa barcha tashkilotlarni ko‘radi.

Excel hisobotda `Xodimlar ro'yxati` varag‘i ham qo‘shilgan. Unda ro‘yxatdan o‘tish hududi va hududdan tashqarida bo‘lsa sabab/izoh saqlanadi.

### Mavjud Railway bazasi

Backend `3.1.0` birinchi ishga tushganda mavjud `employees` jadvaliga yangi ustunlarni ma’lumotlarni o‘chirmasdan avtomatik qo‘shadi. Avval **backendni Railway’ga deploy qiling**, keyin yangi APKlarni build qilib o‘rnating.


## 10. 3.2.0 yangilanishi — audit selfilari

- Xodim ro'yxatdan o'tgandagi selfi saqlanadi.
- Har bir `Keldim` va `Ketdim` muvaffaqiyatli yozuvida tekshiruvdan o'tgan selfi saqlanadi.
- Admin/Super Admin `Xodimlar`, `Davomat` va `Bugungi xodimlar holati` ekranlaridan selfini ochib ko'ra oladi.
- Selfi endpointlari JWT admin avtorizatsiyasi va tashkilotga kirish huquqi bilan himoyalangan; rasm URL'i ochiq/public emas.
- Excel `Davomat` varag'ida har bir Keldim/Ketdim qatorining selfisi 72x72 ko'rinishida joylanadi.
- Excel `Xodimlar ro'yxati` varag'ida ro'yxatdan o'tish selfisi joylanadi.
- Selfilar bazada ochiq rasm sifatida emas, `BIOMETRIC_KEY` bilan shifrlangan bytes ko'rinishida saqlanadi.
- Mavjud 3.1 bazada yangi ustunlar backend ishga tushganda avtomatik qo'shiladi. Eski yozuvlarda selfi bo'lmaydi; yangi ro'yxat/davomatlardan boshlab yig'iladi.

Biometrik selfilar shaxsiy ma'lumot hisoblanadi. Productionda admin huquqlarini minimal berish, PostgreSQL backupini himoyalash va tashkilotning saqlash muddati/maxfiylik siyosatini belgilash tavsiya etiladi.


## 3.3 — Xodimning qayta kirishi
- Ilovani oddiy yopib ochganda secure session avtomatik tiklanadi.
- Logout qilingandan keyin `Oldin ro‘yxatdan o‘tganman` orqali F.I.O. + tashkilot + jonli selfi bilan qayta kirish mumkin.
- Shu qurilma bo‘lsa darhol kiradi.
- Yangi/qayta o‘rnatilgan telefon bo‘lsa jonli yuz+liveness tekshiruvidan keyin profil avtomatik shu qurilmaga ko‘chadi.
- Qurilma o‘zgarganda eski qurilmaning tokenlari bekor qilinadi.

## 3.4.0 yangilanishi

- Mavjud xodim jonli selfi bilan yangi/qayta o‘rnatilgan telefondan ham qayta kira oladi; eski qurilma sessiyasi bekor qilinadi.
- Admin/Super Admin bo‘lish xodim profiliga to‘sqinlik qilmaydi: bir shaxs Admin App va Hodim App’da alohida akkaunt/rol bilan ishlashi mumkin.
- Hodim selfi kamerasi portret aspect ratio bilan ko‘rsatiladi va preview cho‘zilmaydi.

---

## 3.5.0 yangilanishi

`Oldin ro‘yxatdan o‘tganman` endi standart holatda F.I.O. so‘ramaydi: **Tashkilot → jonli selfi → yuzdan avtomatik aniqlash → kirish**.

Super Admin panelidagi **Sozlamalar → Mobil ilova remote-config** orqali login rejimi, F.I.O. fallback, ro‘yxat hududi checkboxi, yangi ro‘yxatga ruxsat, maintenance rejimi va yordam matnini keyinchalik APKni qayta build qilmasdan o‘zgartirish mumkin.

Batafsil: `UPDATE_3_5.md`.

import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SelfieCameraScreen extends StatefulWidget {
  final String title;
  const SelfieCameraScreen({super.key, this.title = 'Jonli selfi'});

  @override
  State<SelfieCameraScreen> createState() => _SelfieCameraScreenState();
}

class _SelfieCameraScreenState extends State<SelfieCameraScreen> {
  CameraController? controller;
  String? error;
  bool taking = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final cams = await availableCameras();
      final front = cams
          .where((c) => c.lensDirection == CameraLensDirection.front)
          .toList();
      if (front.isEmpty) throw Exception('Old kamera topilmadi');

      final c = CameraController(
        front.first,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      await c.initialize();

      // Portretda olingan JPEG yo'nalishini bir xil saqlashga yordam beradi.
      try {
        await c.lockCaptureOrientation(DeviceOrientation.portraitUp);
      } catch (_) {}
      try {
        await c.setFlashMode(FlashMode.off);
      } catch (_) {}
      try {
        await c.setFocusMode(FocusMode.auto);
        await c.setFocusPoint(const Offset(0.5, 0.5));
      } catch (_) {}
      try {
        await c.setExposureMode(ExposureMode.auto);
        await c.setExposurePoint(const Offset(0.5, 0.5));
      } catch (_) {}

      if (!mounted) {
        await c.dispose();
        return;
      }
      setState(() => controller = c);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> _capture() async {
    final c = controller;
    if (c == null || !c.value.isInitialized || taking || c.value.isTakingPicture) {
      return;
    }
    setState(() => taking = true);
    try {
      // Fokus/ekspozitsiya barqarorlashishi uchun juda qisqa kutish.
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final file = await c.takePicture();
      if (mounted) Navigator.pop(context, File(file.path));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Rasm olishda xato: $e')),
        );
        setState(() => taking = false);
      }
    }
  }

  Widget _cameraPreview() {
    final c = controller!;
    final previewSize = c.value.previewSize;
    if (previewSize == null) return CameraPreview(c);

    // Android kamera sensori previewSize'ni landshaft koordinatalarida beradi.
    // Portret ekranda width/height ni almashtirib, BoxFit.cover bilan ko'rsatish
    // tasvirning "tapaloq" yoki cho'zilib ketishini oldini oladi.
    return ClipRect(
      child: SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          clipBehavior: Clip.hardEdge,
          child: SizedBox(
            width: previewSize.height,
            height: previewSize.width,
            child: CameraPreview(c),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(error!),
              ),
            )
          : controller == null
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(22),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              _cameraPreview(),
                              IgnorePointer(
                                child: CustomPaint(
                                  painter: _FaceGuidePainter(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(20, 8, 20, 12),
                      child: Text(
                        'Yuzingizni oval ichiga joylashtiring. Telefonni tik tuting, yorug‘ joyda turing va kadrda faqat bitta odam bo‘lsin.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 28),
                      child: FilledButton.icon(
                        onPressed: taking ? null : _capture,
                        icon: const Icon(Icons.camera_alt),
                        label: Text(taking ? 'Olinmoqda...' : 'Selfi olish'),
                      ),
                    ),
                  ],
                ),
    );
  }
}

class _FaceGuidePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final dim = Paint()..color = const Color(0x38000000);
    final hole = Path()
      ..addOval(
        Rect.fromCenter(
          center: Offset(size.width / 2, size.height * 0.47),
          width: size.width * 0.62,
          height: size.height * 0.58,
        ),
      );
    final full = Path()..addRect(Offset.zero & size);
    canvas.drawPath(Path.combine(PathOperation.difference, full, hole), dim);

    final border = Paint()
      ..color = const Color(0xEBFFFFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width / 2, size.height * 0.47),
        width: size.width * 0.62,
        height: size.height * 0.58,
      ),
      border,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from app.core.config import settings
from app.core.security import hash_password
from app.db.session import Base, engine, SessionLocal
from app.models.entities import Organization, AdminUser
from app.api.routes import public, employee_auth, employee, attendance, admin_auth, admin


def _validate_production_settings() -> None:
    if settings.env.lower() != "production":
        return
    problems = []
    if settings.secret_key in {"dev-only-change-me", "CHANGE_ME_WITH_64_BYTE_RANDOM_HEX"} or len(settings.secret_key) < 32:
        problems.append("SECRET_KEY")
    if not settings.biometric_key or settings.biometric_key.startswith("CHANGE_ME"):
        problems.append("BIOMETRIC_KEY")
    if settings.superadmin_password in {"ChangeMe123!", "CHANGE_ME_NOW"} or len(settings.superadmin_password) < 12:
        problems.append("SUPERADMIN_PASSWORD")
    if problems:
        raise RuntimeError("Production secretlari sozlanmagan: " + ", ".join(problems))


def bootstrap() -> None:
    _validate_production_settings()
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        org = db.scalar(select(Organization).where(Organization.code == "AGROSTAR"))
        if not org:
            db.add(Organization(name="Oltiariq-Agro Star", code="AGROSTAR", location_mode="anywhere", employee_auto_approve=True))
        root = db.scalar(select(AdminUser).where(AdminUser.username == settings.superadmin_username.lower()))
        if not root:
            db.add(AdminUser(full_name=settings.superadmin_full_name, username=settings.superadmin_username.lower(),
                             password_hash=hash_password(settings.superadmin_password), role="super_admin",
                             permissions=[], is_active=True, is_approved=True))
        db.commit()
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    bootstrap()
    yield


app = FastAPI(title=settings.app_name, version="3.0.3", lifespan=lifespan)
if settings.cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(public.router, prefix=settings.api_v1_prefix)
app.include_router(employee_auth.router, prefix=settings.api_v1_prefix)
app.include_router(employee.router, prefix=settings.api_v1_prefix)
app.include_router(attendance.router, prefix=settings.api_v1_prefix)
app.include_router(admin_auth.router, prefix=settings.api_v1_prefix)
app.include_router(admin.router, prefix=settings.api_v1_prefix)

@app.get("/health")
def health():
    return {"status": "ok", "version": "3.0.3", "anti_spoofing": "torch-ready"}

# Dual Face Attendance API v3

Base URL: `https://YOUR_DOMAIN/api/v1`

## Public
- `GET /public/organizations` — faol tashkilotlar. `Oltiariq-Agro Star` backend birinchi ishga tushganda avtomatik yaratiladi.

## Hodim App
- `POST /employee-auth/register` multipart: `full_name`, `organization_id`, `device_id`, `selfie`
- `POST /employee-auth/login-face` multipart: `full_name`, `organization_id`, `device_id`, `selfie`; yuz+liveness mos bo‘lsa mavjud profilga kiradi, yangi qurilma bo‘lsa avtomatik qayta bog‘laydi va eski sessiyani bekor qiladi
- `POST /employee-auth/relink` multipart: yuqoridagidek; yuz+liveness mos bo‘lsa qurilma avtomatik qayta bog‘lanadi va eski sessiya bekor qilinadi
- `POST /employee-auth/refresh` JSON: `refresh_token`
- `GET /employee/me`
- `GET /employee/history`
- `POST /attendance/checkin` multipart: `latitude`, `longitude`, `accuracy_m`, `is_mocked`, `selfie`
- `POST /attendance/checkout` multipart: shu format

Hodim autentifikatsiyalangan so‘rovlari:
- `Authorization: Bearer <employee_access_token>`
- `X-Device-ID: <secure-storage-generated UUID>`

GPS geofence bilan chegaralanmaydi. Har bir muvaffaqiyatli davomat yozuvida koordinata, accuracy, mock flag, face distance/threshold va anti-spoof score saqlanadi.

## Admin Auth
- `POST /admin-auth/register-request` — F.I.O., login, parol va tashkilot tanlab admin so‘rovi
- `POST /admin-auth/login`
- `POST /admin-auth/refresh`

## Admin App
- `GET /admin/me`
- `GET /admin/dashboard`
- `GET /admin/permissions`

### Tashkilotlar
- `GET /admin/organizations`
- `POST /admin/organizations`
- `PATCH /admin/organizations/{id}`
- `DELETE /admin/organizations/{id}` — soft deactivate

### Adminlar
- `GET /admin/admins`
- `POST /admin/admins` — Super Admin
- `PATCH /admin/admins/{id}` — rol, permission, tashkilotlar, status
- `POST /admin/admins/{id}/approve`
- `POST /admin/admins/{id}/reset-password`
- `DELETE /admin/admins/{id}` — soft deactivate

### Xodimlar
- `GET /admin/employees?organization_id=`
- `PATCH /admin/employees/{id}`
- `POST /admin/employees/{id}/approve`
- `POST /admin/employees/{id}/reset-device`
- `DELETE /admin/employees/{id}` — soft deactivate

### Davomat va hisobot
- `GET /admin/attendance?organization_id=&limit=`
- `GET /admin/reports/monthly.xlsx?organization_id=&year=&month=`
- `GET /admin/audit` — Super Admin

## Admin rollari
- `super_admin` — barcha huquqlar
- `org_admin` — o‘z tashkilotlari, xodimlar, davomat, hisobot; `org.create` orqali yangi tashkilot ham qo‘sha oladi
- `hr_manager` — xodimlar, davomat, hisobot
- `auditor` — read-only

Role permissionlariga qo‘shimcha individual permissionlar Super Admin tomonidan berilishi mumkin.

## v3.1.0 qo‘shimchalari

### POST `/employee-auth/register`
Yangi multipart maydonlar:
- `registration_outside_area`: boolean, default `false`.
- `registration_area_note`: string; `registration_outside_area=true` bo‘lsa majburiy.

### GET `/admin/today-status`
Admin ko‘ra oladigan faol xodimlarning tashkilot timezone’i bo‘yicha bugungi holatini qaytaradi:
- `checkin_done`, `checkin_at`
- `checkout_done`, `checkout_at`
- `state`: `not_started | working | completed`
- `registration_outside_area`, `registration_area_note`

### GET `/admin/employees`
Har bir xodimda qo‘shimcha:
- `registration_outside_area`
- `registration_area_note`

### GET `/admin/reports/monthly.xlsx`
Ro‘yxatdan o‘tish hududi va izohi `Davomat`, `Xodimlar xulosasi` va `Xodimlar ro'yxati` varaqlarida beriladi.


## v3.2.0 — selfi audit va Excel rasmlari

Yangi muvaffaqiyatli ro'yxatdan o'tishdan boshlab server `registration_selfie_enc` saqlaydi. Har bir muvaffaqiyatli Keldim/Ketdimda `selfie_enc` saqlanadi. Ikkalasi ham siqilgan JPEGning `BIOMETRIC_KEY` bilan Fernet-shifrlangan ko'rinishi.

Admin JSON qo'shimchalari:
- `GET /admin/employees`: `registration_selfie_available`
- `GET /admin/attendance`: `selfie_available`
- `GET /admin/today-status`: `registration_selfie_available`, `checkin_attendance_id`, `checkout_attendance_id`, `checkin_selfie_available`, `checkout_selfie_available`

Himoyalangan rasm endpointlari:
- `GET /admin/employees/{employee_id}/registration-selfie` — `image/jpeg`, `employee.read` va tashkilot access talab qiladi.
- `GET /admin/attendance/{attendance_id}/selfie` — `image/jpeg`, `attendance.read` va tashkilot access talab qiladi.

`GET /admin/reports/monthly.xlsx` endi `Davomat` varag'iga Keldim/Ketdim selfilarini, `Xodimlar ro'yxati` varag'iga ro'yxatdan o'tish selfisini ichki Excel image sifatida joylaydi.

import 'dart:io';
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import 'selfie_camera_screen.dart';

enum EntryMode { register, login }

class RegistrationScreen extends StatefulWidget {
  final ApiClient api;
  final VoidCallback onDone;
  const RegistrationScreen({super.key, required this.api, required this.onDone});
  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final name = TextEditingController();
  final areaNote = TextEditingController();
  List<Organization> orgs = [];
  int? orgId;
  File? selfie;
  bool loading = true;
  bool submitting = false;
  bool outsideArea = false;
  EntryMode mode = EntryMode.register;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    name.dispose();
    areaNote.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      orgs = await widget.api.organizations();
      if (orgs.isNotEmpty) orgId = orgs.first.id;
    } catch (e) {
      if (mounted) _snack('$e');
    }
    if (mounted) setState(() => loading = false);
  }

  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(s.replaceFirst('Exception: ', ''))),
      );

  void _setMode(EntryMode next) {
    setState(() {
      mode = next;
      selfie = null;
      if (mode == EntryMode.login) {
        outsideArea = false;
        areaNote.clear();
      }
    });
  }

  Future<void> _selfie() async {
    final f = await Navigator.push<File>(
      context,
      MaterialPageRoute(
        builder: (_) => SelfieCameraScreen(
          title: mode == EntryMode.login
              ? 'Kirish uchun jonli selfi'
              : 'Ro‘yxatdan o‘tish selfisi',
        ),
      ),
    );
    if (f != null) setState(() => selfie = f);
  }

  Future<void> _submit() async {
    if (name.text.trim().length < 3 || orgId == null || selfie == null) {
      _snack('F.I.O., tashkilot va jonli selfi talab qilinadi');
      return;
    }
    if (mode == EntryMode.register && outsideArea && areaNote.text.trim().length < 3) {
      _snack('Belgilangan hududda emas bo‘lsangiz, sababini yozing');
      return;
    }

    setState(() => submitting = true);
    try {
      if (mode == EntryMode.login) {
        await widget.api.loginFace(
          fullName: name.text.trim(),
          organizationId: orgId!,
          selfie: selfie!,
        );
      } else {
        await widget.api.register(
          fullName: name.text.trim(),
          organizationId: orgId!,
          selfie: selfie!,
          registrationOutsideArea: outsideArea,
          registrationAreaNote: outsideArea ? areaNote.text.trim() : '',
        );
      }
      widget.onDone();
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLogin = mode == EntryMode.login;
    return Scaffold(
      appBar: AppBar(title: const Text('Agro Star Hodim')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Xodim kabineti',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                SegmentedButton<EntryMode>(
                  segments: const [
                    ButtonSegment(
                      value: EntryMode.register,
                      icon: Icon(Icons.person_add_alt_1),
                      label: Text('Yangi ro‘yxat'),
                    ),
                    ButtonSegment(
                      value: EntryMode.login,
                      icon: Icon(Icons.login),
                      label: Text('Oldin ro‘yxatdan o‘tganman'),
                    ),
                  ],
                  selected: {mode},
                  onSelectionChanged: (v) => _setMode(v.first),
                  showSelectedIcon: false,
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(
                      isLogin
                          ? 'Oldin ro‘yxatdan o‘tgan bo‘lsangiz, F.I.O. va tashkilotni tanlang. Jonli selfi orqali yuzingiz tekshiriladi va akkauntingizga qayta kirasiz. Telefon almashtirilgan bo‘lsa, muvaffaqiyatli yuz tekshiruvidan keyin akkaunt yangi qurilmaga avtomatik ko‘chadi; eski qurilma sessiyasi bekor qilinadi.'
                          : 'Birinchi marta foydalanayotgan xodim shu yerda ro‘yxatdan o‘tadi. Davomatni keyin istalgan tumandan qilishingiz mumkin.',
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText: 'F.I.O.',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<int>(
                  initialValue: orgId,
                  decoration: const InputDecoration(
                    labelText: 'Tashkilot',
                    border: OutlineInputBorder(),
                  ),
                  items: orgs
                      .map((o) => DropdownMenuItem(value: o.id, child: Text(o.name)))
                      .toList(),
                  onChanged: (v) => setState(() => orgId = v),
                ),
                const SizedBox(height: 14),
                if (!isLogin) ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(
                        children: [
                          CheckboxListTile(
                            value: outsideArea,
                            onChanged: (v) => setState(() {
                              outsideArea = v ?? false;
                              if (!outsideArea) areaNote.clear();
                            }),
                            title: const Text('Belgilangan hududda emasman'),
                            subtitle: const Text(
                              'Hududda bo‘lsangiz belgini qo‘ymang. Hududda emas bo‘lsangiz belgilang va sabab yozing.',
                            ),
                            controlAffinity: ListTileControlAffinity.leading,
                          ),
                          if (outsideArea)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                              child: TextField(
                                controller: areaNote,
                                minLines: 2,
                                maxLines: 4,
                                decoration: const InputDecoration(
                                  labelText: 'Sababi / izoh *',
                                  hintText: 'Masalan: xizmat safari, boshqa tumandagi obyekt...',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                OutlinedButton.icon(
                  onPressed: _selfie,
                  icon: const Icon(Icons.face),
                  label: Text(
                    selfie == null
                        ? (isLogin ? 'Kirish uchun jonli selfi olish' : 'Old kamera bilan selfi olish')
                        : 'Selfi olindi — qayta olish',
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: submitting ? null : _submit,
                  icon: Icon(isLogin ? Icons.login : Icons.person_add),
                  label: Text(
                    submitting
                        ? 'Tekshirilmoqda...'
                        : (isLogin ? 'AKKAUNTGA KIRISH' : 'RO‘YXATDAN O‘TISH'),
                  ),
                ),
              ],
            ),
    );
  }
}

import secrets
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.db.session import get_db
from app.models.entities import Employee, Organization
from app.schemas.common import TokenPair, RefreshRequest
from app.services.biometric_crypto import encrypt_embedding, decrypt_embedding, encrypt_bytes
from app.services.face import extract_embedding, analyze_selfie, verify_embedding, FaceError

router = APIRouter(prefix="/employee-auth", tags=["employee-auth"])


def tokens(emp: Employee) -> TokenPair:
    return TokenPair(
        access_token=create_access_token(str(emp.id), "employee", emp.token_version),
        refresh_token=create_refresh_token(str(emp.id), "employee", emp.token_version),
    )

@router.post("/register", response_model=TokenPair)
async def register(
    full_name: str = Form(...),
    organization_id: int = Form(...),
    device_id: str = Form(...),
    registration_outside_area: bool = Form(False),
    registration_area_note: str | None = Form(None),
    selfie: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    name = " ".join(full_name.split()).strip()
    if len(name) < 3:
        raise HTTPException(422, "F.I.O. noto'g'ri")
    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")
    area_note = " ".join((registration_area_note or "").split()).strip()
    if registration_outside_area and len(area_note) < 3:
        raise HTTPException(422, "Belgilangan hududda emas bo'lsangiz, sababini yozing")
    if not registration_outside_area:
        area_note = ""
    try:
        selfie_bytes = await selfie.read()
        embedding, _, registration_selfie_jpeg = analyze_selfie(selfie_bytes, require_liveness=True)
    except FaceError as exc:
        raise HTTPException(422, str(exc))
    # Bir xil F.I.O. ga ruxsat beriladi, lekin bir yuz ikkinchi marta ro'yxatdan o'tolmaydi.
    existing_people = db.scalars(select(Employee).where(Employee.organization_id == organization_id, Employee.is_active.is_(True))).all()
    for existing in existing_people:
        try:
            matched, _, _ = verify_embedding(decrypt_embedding(existing.face_embedding_enc), embedding)
        except Exception:
            matched = False
        if matched:
            raise HTTPException(409, "Bu yuz ushbu tashkilotda allaqachon ro'yxatdan o'tgan. Qurilma almashtirilgan bo'lsa admin reset qilsin.")
    emp = Employee(
        full_name=name,
        employee_code=f"EMP-{secrets.token_hex(4).upper()}",
        organization_id=organization_id,
        face_embedding_enc=encrypt_embedding(embedding),
        device_id=device_id,
        registration_outside_area=registration_outside_area,
        registration_area_note=area_note or None,
        registration_selfie_enc=encrypt_bytes(registration_selfie_jpeg),
        is_approved=org.employee_auto_approve,
    )
    db.add(emp); db.commit(); db.refresh(emp)
    return tokens(emp)


@router.post("/login-face", response_model=TokenPair)
async def login_face(
    full_name: str = Form(...),
    organization_id: int = Form(...),
    device_id: str = Form(...),
    selfie: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Existing employee sign-in with a live selfie.

    Yuz + liveness muvaffaqiyatli tasdiqlansa, xodim yangi telefondan ham
    qayta kira oladi. Agar qurilma o'zgargan bo'lsa, profil yangi qurilmaga
    ko'chiriladi va token_version oshiriladi — eski qurilmadagi sessiyalar
    avtomatik bekor bo'ladi.
    """
    name = " ".join(full_name.split()).strip()
    if len(name) < 3:
        raise HTTPException(422, "F.I.O. noto'g'ri")

    org = db.get(Organization, organization_id)
    if not org or not org.is_active:
        raise HTTPException(404, "Tashkilot topilmadi")

    candidates = db.scalars(
        select(Employee).where(
            Employee.organization_id == organization_id,
            Employee.full_name.ilike(name),
            Employee.is_active.is_(True),
        )
    ).all()
    if not candidates:
        raise HTTPException(404, "Bu F.I.O. bilan xodim topilmadi")

    try:
        probe, _ = extract_embedding(await selfie.read(), require_liveness=True)
    except FaceError as exc:
        raise HTTPException(422, str(exc))

    best = None
    best_distance = 999.0
    for candidate in candidates:
        try:
            ok, distance, _ = verify_embedding(
                decrypt_embedding(candidate.face_embedding_enc), probe
            )
        except Exception:
            ok, distance = False, 999.0
        if ok and distance < best_distance:
            best = candidate
            best_distance = distance

    if best is None:
        raise HTTPException(403, "Yuz ushbu xodim profiliga mos kelmadi")

    emp = best

    # Jonli yuz muvaffaqiyatli tekshirilgani uchun yangi qurilmaga xavfsiz
    # qayta bog'laymiz. token_version eski qurilmadagi refresh/access
    # sessiyalarini bekor qiladi. Shu qurilma bo'lsa versiyani o'zgartirmaymiz.
    if emp.device_id != device_id:
        emp.device_id = device_id
        emp.token_version += 1
        db.commit()
        db.refresh(emp)

    return tokens(emp)

@router.post("/relink", response_model=TokenPair)
async def relink(full_name: str = Form(...), organization_id: int = Form(...), device_id: str = Form(...), selfie: UploadFile = File(...), db: Session = Depends(get_db)):
    name = " ".join(full_name.split()).strip()
    candidates = db.scalars(select(Employee).where(Employee.organization_id == organization_id, Employee.full_name.ilike(name), Employee.is_active.is_(True))).all()
    if not candidates:
        raise HTTPException(404, "Xodim topilmadi")
    probe, _ = extract_embedding(await selfie.read(), require_liveness=True)
    best = None
    best_distance = 999.0
    best_threshold = 0.0
    for candidate in candidates:
        ok, distance, threshold = verify_embedding(decrypt_embedding(candidate.face_embedding_enc), probe)
        if ok and distance < best_distance:
            best, best_distance, best_threshold = candidate, distance, threshold
    if best is None:
        raise HTTPException(403, "F.I.O. bo'yicha topilgan profillarning hech biriga yuz mos kelmadi")
    emp = best
    if emp.device_id != device_id:
        emp.device_id = device_id
        emp.token_version += 1
        db.commit()
        db.refresh(emp)
    return tokens(emp)

@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        p = decode_token(body.refresh_token)
        if p.get("actor") != "employee" or p.get("typ") != "refresh": raise ValueError()
    except Exception:
        raise HTTPException(401, "Refresh token yaroqsiz")
    emp = db.get(Employee, int(p["sub"]))
    if not emp or not emp.is_active or emp.token_version != int(p.get("ver", 0)):
        raise HTTPException(401, "Sessiya yaroqsiz")
    return tokens(emp)

# AgroStar Davomat 3.2.0

## Yangi funksiyalar
- Ro'yxatdan o'tish selfisini saqlash va Admin/Super Admin ko'rishi.
- Har bir Keldim/Ketdim selfisini saqlash va Admin/Super Admin ko'rishi.
- Bugungi holat kartasidan Ro'yxat/Keldim/Ketdim selfilarini ochish.
- Excel Davomat varag'ida Keldim/Ketdim selfi rasmlari.
- Excel Xodimlar ro'yxati varag'ida ro'yxatdan o'tish selfisi.
- JPEG 720 px gacha siqiladi va bazada Fernet bilan shifrlanadi.

## Deploy
1. Avval backendni Railway'ga shu ZIP bilan deploy qiling. `/health` versiyasi `3.2.0` bo'lishi kerak.
2. So'ng aynan shu ZIPdan Admin va Hodim APKlarni build qiling.
3. Eski yozuvlar uchun selfi mavjud bo'lmaydi; yangi ro'yxatdan o'tish/davomatlardan boshlab selfilar chiqadi.

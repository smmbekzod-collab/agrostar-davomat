import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/api_client.dart';
import '../core/session_store.dart';
import '../models/models.dart';
import '../services/location_service.dart';
import 'selfie_camera_screen.dart';

class DashboardScreen extends StatefulWidget {
  final ApiClient api;
  final SessionStore session;
  final VoidCallback onLogout;
  const DashboardScreen({super.key, required this.api, required this.session, required this.onLogout});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  EmployeeMe? me;
  List<AttendanceItem> history = [];
  bool loading = true;
  bool acting = false;

  @override void initState() { super.initState(); _load(); }
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.replaceFirst('Exception: ', ''))));
  Future<void> _load() async {
    try { me = await widget.api.me(); history = await widget.api.history(); }
    catch (e) { _snack('$e'); }
    if (mounted) setState(() => loading = false);
  }
  Future<void> _act(String type) async {
    if (acting) return;
    setState(() => acting = true);
    try {
      final pos = await LocationService().current();
      final f = await Navigator.push<File>(context, MaterialPageRoute(builder: (_) => SelfieCameraScreen(title: type == 'checkin' ? 'Ishga kelish selfisi' : 'Ishdan ketish selfisi')));
      if (f == null) return;
      await widget.api.attendance(type: type, latitude: pos.latitude, longitude: pos.longitude, accuracy: pos.accuracy, isMocked: pos.isMocked, selfie: f);
      _snack(type == 'checkin' ? 'Ishga kelish muvaffaqiyatli qayd etildi' : 'Ishdan ketish muvaffaqiyatli qayd etildi');
      history = await widget.api.history();
    } catch (e) { _snack('$e'); }
    finally { if (mounted) setState(() => acting = false); }
  }
  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Akkauntdan chiqish'),
        content: const Text('Keyin “Oldin ro‘yxatdan o‘tganman” bo‘limidan jonli selfi bilan qayta kirishingiz mumkin.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Bekor qilish')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Chiqish')),
        ],
      ),
    );
    if (ok != true) return;
    await widget.session.clearTokens();
    widget.onLogout();
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Agro Star Hodim'), actions: [IconButton(onPressed: _logout, icon: const Icon(Icons.logout))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(me?.fullName ?? '', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          Text(me?.organizationName ?? ''),
          Text('Kod: ${me?.employeeCode ?? ''}'),
        ]))),
        const SizedBox(height: 16),
        if (me?.isApproved == false) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Ro‘yxatdan o‘tish saqlandi. Admin tasdiqlashi kutilmoqda. Tasdiqlangandan keyin sahifani pastga tortib yangilang.', style: TextStyle(fontWeight: FontWeight.bold)))),
        FilledButton.icon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(58)), onPressed: acting || me?.isApproved == false ? null : () => _act('checkin'), icon: const Icon(Icons.login), label: const Text('🟢 ISHGA KELDIM')),
        const SizedBox(height: 12),
        FilledButton.tonalIcon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(58)), onPressed: acting || me?.isApproved == false ? null : () => _act('checkout'), icon: const Icon(Icons.logout), label: const Text('🔴 ISHDAN KETDIM')),
        const SizedBox(height: 20),
        const Text('Davomat tarixi', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (history.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Hozircha davomat yozuvi yo‘q.'))),
        ...history.map((x) => Card(child: ListTile(
          leading: Icon(x.eventType == 'checkin' ? Icons.login : Icons.logout),
          title: Text(x.eventType == 'checkin' ? 'Ishga keldi' : 'Ishdan ketdi'),
          subtitle: Text('${DateFormat('dd.MM.yyyy HH:mm').format(x.occurredAt.toLocal())}\nGPS: ${x.latitude.toStringAsFixed(6)}, ${x.longitude.toStringAsFixed(6)}  ±${x.accuracy?.toStringAsFixed(0) ?? '-'} m'),
          isThreeLine: true,
        ))),
      ])),
    );
  }
}

# AgroStar Davomat 3.3.0

## Xodim qayta kirishi

Hodim App boshlang‘ich ekraniga ikki rejim qo‘shildi:

1. **Yangi ro‘yxat** — yangi xodim uchun.
2. **Oldin ro‘yxatdan o‘tganman** — mavjud xodim uchun F.I.O. + tashkilot + jonli selfi bilan face-login.

### Qurilma qoidasi
- Shu qurilma: face verificationdan keyin token qayta beriladi.
- Admin reset qilgan profil (`device_id = null`): yangi qurilma avtomatik bog‘lanadi.
- Boshqa faol qurilmaga bog‘langan profil: login rad etiladi va admin reset talab qilinadi.

Oddiy app close/reopen sessiyani o‘chirmaydi; refresh token orqali login saqlanadi.

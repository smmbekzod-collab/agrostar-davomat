# AgroStar Davomat 3.1.0

## Qo‘shildi
1. Hodim ro‘yxatdan o‘tishda `Belgilangan hududda emasman` checkboxi.
2. Checkbox yoqilsa sabab/izoh maydoni majburiy ochiladi; o‘chiq bo‘lsa izohsiz davom etadi.
3. Aniq geofence yo‘q — hudud holatini xodimning o‘zi belgilaydi.
4. Admin/Super Admin dashboardda barcha tegishli xodimlarning bugungi `Keldim/Ketdim` holati.
5. Admin Xodimlar bo‘limida ro‘yxatdan o‘tish hududi va izohi.
6. Excel’da ro‘yxatdan o‘tish hududi/izohi va alohida `Xodimlar ro'yxati` varag‘i.
7. Mavjud PostgreSQL bazasi uchun avtomatik, ma’lumot yo‘qotmaydigan schema update.

## Deploy tartibi
1. Shu ZIPni GitHub repositoryga yuklang va eski loyiha ZIPlarini o‘chirib bitta ZIP qoldiring.
2. `Deploy Backend to Railway` workflow:
   - zip_file: shu ZIP nomi
   - railway_service: `grand-recreation`
3. `/health` da `version: 3.1.0` ni tekshiring.
4. `Build APKs from uploaded ZIP` workflow:
   - zip_file: shu ZIP nomi
   - api_base_url: `https://grand-recreation-production-caad.up.railway.app/api/v1`
5. Yangi `agrostar-hodim.apk` va `davomat-admin.apk` ni o‘rnating.

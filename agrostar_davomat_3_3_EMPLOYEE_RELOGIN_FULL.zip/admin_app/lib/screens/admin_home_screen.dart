import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api_client.dart';
import '../core/session_store.dart';
import '../models/models.dart';

class AdminHomeScreen extends StatefulWidget{
  final ApiClient api;final SessionStore session;final VoidCallback onLogout;
  const AdminHomeScreen({super.key,required this.api,required this.session,required this.onLogout});
  @override State<AdminHomeScreen> createState()=>_AdminHomeScreenState();
}
class _AdminHomeScreenState extends State<AdminHomeScreen>{
  Map<String,dynamic>? me;Map<String,dynamic> stats={};List<Organization> orgs=[];List<AdminAccount> admins=[];List<EmployeeItem> employees=[];List<AttendanceItem> attendance=[];List<Map<String,dynamic>> todayStatus=[];List<Map<String,dynamic>> audit=[];
  bool loading=true;int tab=0;int reportYear=DateTime.now().year;int reportMonth=DateTime.now().month;
  bool get superAdmin=>me?['role']=='super_admin';
  Set<String> get perms=>Set<String>.from(me?['effective_permissions']??[]);
  bool can(String p)=>perms.contains('*')||perms.contains(p);
  @override void initState(){super.initState();loadAll();}
  void snack(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s.replaceFirst('Exception: ',''))));
  Future<void> loadAll()async{setState(()=>loading=true);try{me=await widget.api.me();stats=await widget.api.dashboard();todayStatus=await widget.api.todayStatus();if(can('org.read'))orgs=await widget.api.organizations();if(can('admin.read'))admins=await widget.api.admins();if(can('employee.read'))employees=await widget.api.employees();if(can('attendance.read'))attendance=await widget.api.attendance();if(superAdmin&&can('audit.read')){try{audit=await widget.api.audit();}catch(_){}}}catch(e){snack('$e');}if(mounted)setState(()=>loading=false);}
  Future<void> logout()async{await widget.session.clear();widget.onLogout();}
  @override
  Widget build(BuildContext c) {
    final pages = [
      dashboardPage(),
      orgPage(),
      adminPage(),
      employeePage(),
      attendancePage(),
      reportPage(),
      settingsPage(),
      auditPage(),
    ];
    final labels = ['Boshqaruv', 'Tashkilotlar', 'Adminlar', 'Xodimlar', 'Davomat', 'Hisobot', 'Sozlamalar', 'Audit'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Davomat Admin — ${labels[tab]}'),
        actions: [
          IconButton(onPressed: loadAll, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.admin_panel_settings, size: 44),
                  const SizedBox(height: 8),
                  Text(me?['full_name'] ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(me?['role'] ?? ''),
                ],
              ),
            ),
            for (int i = 0; i < labels.length; i++)
              if (i != 7 || superAdmin)
                ListTile(
                  selected: tab == i,
                  leading: Icon([Icons.dashboard, Icons.business, Icons.manage_accounts, Icons.people, Icons.location_on, Icons.table_view, Icons.settings, Icons.history][i]),
                  title: Text(labels[i]),
                  onTap: () {
                    setState(() => tab = i);
                    Navigator.pop(context);
                  },
                ),
          ],
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(onRefresh: loadAll, child: pages[tab]),
    );
  }

  Widget wrap(List<Widget> children)=>ListView(padding:const EdgeInsets.all(16),children:children);
  Widget dashboardPage()=>wrap([
    Text('Xush kelibsiz, ${me?['full_name']??''}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    Wrap(spacing:12,runSpacing:12,children:[
      stat('Tashkilotlar',stats['organizations'],Icons.business),
      stat('Xodimlar',stats['employees'],Icons.people),
      stat('Bugungi yozuvlar',stats['today_events'],Icons.today),
      if(superAdmin)stat('Kutilayotgan admin',stats['pending_admins'],Icons.hourglass_top),
    ]),
    const SizedBox(height:16),
    Row(children:[
      const Expanded(child:Text('Bugungi xodimlar holati',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
      IconButton(onPressed:loadAll,icon:const Icon(Icons.refresh),tooltip:'Yangilash'),
    ]),
    const Text('Ro‘yxatdan o‘tgan xodimlarning bugungi Keldim/Ketdim holati.'),
    const SizedBox(height:8),
    if(todayStatus.isEmpty)
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Xodimlar topilmadi.')))
    else
      ...todayStatus.map(todayEmployeeCard),
    const SizedBox(height:12),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text("GPS rejimi: xodimlar turli tumanlardan davomat qilishi mumkin. Koordinata bloklash uchun emas, qayerdan davomat qilinganini qayd etish uchun saqlanadi."))),
  ]);

  Widget stat(String t,dynamic v,IconData i)=>SizedBox(width:180,child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[Icon(i,size:34),Text('${v??0}',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(t,textAlign:TextAlign.center)]))));

  String eventTime(dynamic value){
    if(value==null)return '-';
    try{return DateFormat('HH:mm').format(DateTime.parse(value.toString()).toLocal());}catch(_){return value.toString();}
  }

  Future<void> showSelfie(String title,Future<dynamic> Function() loader)async{
    try{
      final bytes=await loader();
      if(!mounted)return;
      await showDialog<void>(context:context,builder:(c)=>Dialog(child:ConstrainedBox(
        constraints:const BoxConstraints(maxWidth:520,maxHeight:720),
        child:Column(mainAxisSize:MainAxisSize.min,children:[
          Padding(padding:const EdgeInsets.fromLTRB(16,14,8,8),child:Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))),IconButton(onPressed:()=>Navigator.pop(c),icon:const Icon(Icons.close))])),
          Flexible(child:InteractiveViewer(minScale:0.8,maxScale:4,child:Image.memory(bytes,fit:BoxFit.contain))),
          const SizedBox(height:12),
        ]),
      )));
    }catch(e){snack('$e');}
  }

  Widget todayEmployeeCard(Map<String,dynamic> row){
    final checkedIn=row['checkin_done']==true;
    final checkedOut=row['checkout_done']==true;
    final approved=row['is_approved']==true;
    final outside=row['registration_outside_area']==true;
    final note=row['registration_area_note']?.toString()??'';
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        Expanded(child:Text(row['employee_name']?.toString()??'',style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold))),
        if(!approved)const Chip(label:Text('Tasdiq kutilmoqda')),
      ]),
      Text(row['organization_name']?.toString()??''),
      const SizedBox(height:8),
      Wrap(spacing:8,runSpacing:6,children:[
        Chip(avatar:Icon(checkedIn?Icons.check_circle:Icons.cancel,size:18),label:Text(checkedIn?'Keldim: ${eventTime(row['checkin_at'])}':'Keldim qilmagan')),
        Chip(avatar:Icon(checkedOut?Icons.check_circle:Icons.cancel,size:18),label:Text(checkedOut?'Ketdim: ${eventTime(row['checkout_at'])}':'Ketdim qilmagan')),
      ]),
      const SizedBox(height:6),
      Wrap(spacing:8,runSpacing:6,children:[
        if(row['registration_selfie_available']==true)OutlinedButton.icon(onPressed:()=>showSelfie('${row['employee_name']} — ro‘yxatdan o‘tish selfisi',()=>widget.api.employeeRegistrationSelfie(row['employee_id'] as int)),icon:const Icon(Icons.badge),label:const Text('Ro‘yxat selfi')),
        if(row['checkin_selfie_available']==true&&row['checkin_attendance_id']!=null)OutlinedButton.icon(onPressed:()=>showSelfie('${row['employee_name']} — Keldim selfisi',()=>widget.api.attendanceSelfie(row['checkin_attendance_id'] as int)),icon:const Icon(Icons.login),label:const Text('Keldim selfi')),
        if(row['checkout_selfie_available']==true&&row['checkout_attendance_id']!=null)OutlinedButton.icon(onPressed:()=>showSelfie('${row['employee_name']} — Ketdim selfisi',()=>widget.api.attendanceSelfie(row['checkout_attendance_id'] as int)),icon:const Icon(Icons.logout),label:const Text('Ketdim selfi')),
      ]),
      if(outside)Padding(padding:const EdgeInsets.only(top:6),child:Text('Ro‘yxatdan o‘tish: hududda emas${note.isEmpty?'':' — $note'}',style:const TextStyle(fontWeight:FontWeight.w600))),
    ])));
  }

  Widget orgPage()=>wrap([Row(children:[const Expanded(child:Text('Tashkilotlar',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),if(can('org.create'))FilledButton.icon(onPressed:addOrg,icon:const Icon(Icons.add),label:const Text("Qo'shish"))]),const SizedBox(height:8),...orgs.map((o)=>Card(child:ListTile(title:Text(o.name),subtitle:Text('${o.code} • GPS: istalgan joydan • ${o.workStart}–${o.workEnd} • grace ${o.graceMinutes} daq • Auto tasdiq: ${o.autoApprove?"ha":"yo‘q"}'),trailing:can('org.update')?PopupMenuButton<String>(onSelected:(v){if(v=='edit')editOrg(o);if(v=='off')deactivateOrg(o);},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('Tahrirlash')),PopupMenuItem(value:'off',child:Text('Faolsizlantirish'))]):null)))]);
  Future<void> addOrg()async{
    final n=TextEditingController(),code=TextEditingController(),start=TextEditingController(text:'09:00'),end=TextEditingController(text:'18:00'),grace=TextEditingController(text:'10');
    bool auto=true;
    String? formError;
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(
      title:const Text("Tashkilot qo'shish"),
      content:SizedBox(width:430,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:n,textCapitalization:TextCapitalization.words,decoration:const InputDecoration(labelText:'Nomi',helperText:'Kamida 2 ta belgi')),
        TextField(controller:code,textCapitalization:TextCapitalization.characters,decoration:const InputDecoration(labelText:'Kodi',helperText:'Kamida 2 ta belgi. Masalan: AG, AGRO2, QOQON')),
        TextField(controller:start,decoration:const InputDecoration(labelText:'Ish boshlanishi (HH:MM)')),
        TextField(controller:end,decoration:const InputDecoration(labelText:'Ish tugashi (HH:MM)')),
        TextField(controller:grace,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Kechikish grace (daqiqa)')),
        const ListTile(contentPadding:EdgeInsets.zero,title:Text('Timezone'),subtitle:Text('Asia/Tashkent')),
        const ListTile(contentPadding:EdgeInsets.zero,title:Text('GPS rejimi'),subtitle:Text('Istalgan joydan (anywhere)')),
        SwitchListTile(value:auto,onChanged:(v)=>setD(()=>auto=v),title:const Text('Xodimni avtomatik tasdiqlash')),
        if(formError!=null)Padding(padding:const EdgeInsets.only(top:10),child:Text(formError!,style:TextStyle(color:Theme.of(c).colorScheme.error,fontWeight:FontWeight.w600))),
      ]))),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),
        FilledButton(onPressed:(){
          final name=n.text.trim();
          final orgCode=code.text.trim().toUpperCase();
          final g=int.tryParse(grace.text.trim());
          if(name.length<2){setD(()=>formError='Tashkilot nomi kamida 2 ta belgidan iborat bo‘lsin.');return;}
          if(orgCode.length<2){setD(()=>formError='Tashkilot kodi kamida 2 ta belgidan iborat bo‘lsin. Masalan: AG, AGRO2 yoki QOQON.');return;}
          if(!RegExp(r'^[A-Z0-9_-]+$').hasMatch(orgCode)){setD(()=>formError='Kodda faqat lotin harflari, raqam, _ yoki - ishlating.');return;}
          if(!RegExp(r'^([01]\d|2[0-3]):[0-5]\d$').hasMatch(start.text.trim())||!RegExp(r'^([01]\d|2[0-3]):[0-5]\d$').hasMatch(end.text.trim())){setD(()=>formError='Ish vaqtini HH:MM formatida kiriting. Masalan: 09:00 va 18:00.');return;}
          if(g==null||g<0||g>180){setD(()=>formError='Grace daqiqasi 0–180 oralig‘ida bo‘lsin.');return;}
          code.text=orgCode;
          n.text=name;
          setD(()=>formError=null);
          Navigator.pop(c,true);
        },child:const Text('Saqlash'))
      ]
    )));
    if(ok==true){
      try{
        await widget.api.createOrganization(n.text.trim(),code.text.trim().toUpperCase(),auto,workStart:start.text.trim(),workEnd:end.text.trim(),graceMinutes:int.tryParse(grace.text.trim())??10);
        await loadAll();
        snack('Tashkilot muvaffaqiyatli qo‘shildi.');
      }catch(e){snack('$e');}
    }
  }

  Future<void> editOrg(Organization o)async{
    bool active=o.isActive,auto=o.autoApprove;
    final start=TextEditingController(text:o.workStart),end=TextEditingController(text:o.workEnd),grace=TextEditingController(text:'${o.graceMinutes}');
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(
      title:Text(o.name),
      content:SizedBox(width:430,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        SwitchListTile(value:active,onChanged:(v)=>setD(()=>active=v),title:const Text('Faol')),
        SwitchListTile(value:auto,onChanged:(v)=>setD(()=>auto=v),title:const Text('Xodim auto-tasdiq')),
        TextField(controller:start,decoration:const InputDecoration(labelText:'Ish boshlanishi (HH:MM)')),
        TextField(controller:end,decoration:const InputDecoration(labelText:'Ish tugashi (HH:MM)')),
        TextField(controller:grace,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Kechikish grace (daqiqa)')),
        const ListTile(contentPadding:EdgeInsets.zero,title:Text('Timezone'),subtitle:Text('Asia/Tashkent')),
        const ListTile(contentPadding:EdgeInsets.zero,title:Text('GPS rejimi'),subtitle:Text('Istalgan joydan (anywhere)')),
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Saqlash'))]
    )));
    if(ok==true){
      try{
        await widget.api.updateOrganization(o.id,{'is_active':active,'employee_auto_approve':auto,'location_mode':'anywhere','timezone':'Asia/Tashkent','work_start':start.text.trim(),'work_end':end.text.trim(),'grace_minutes':int.tryParse(grace.text)??10});
        await loadAll();
      }catch(e){snack('$e');}
    }
  }
  Future<void> deactivateOrg(Organization o)async{try{await widget.api.deactivateOrganization(o.id);await loadAll();}catch(e){snack('$e');}}

  Widget adminPage()=>wrap([Row(children:[const Expanded(child:Text('Adminlar',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),if(superAdmin&&can('admin.manage'))FilledButton.icon(onPressed:addAdmin,icon:const Icon(Icons.person_add),label:const Text("Qo'shish"))]),...admins.map((a)=>Card(child:ListTile(title:Text(a.fullName),subtitle:Text('${a.username} • ${a.role}\nTashkilot ID: ${a.organizationIds.join(', ')} • ${a.isApproved?'tasdiqlangan':'KUTILMOQDA'}'),isThreeLine:true,trailing:superAdmin?PopupMenuButton<String>(onSelected:(v){if(v=='edit')editAdmin(a);if(v=='approve')approveAdmin(a);if(v=='pass')resetPass(a);if(v=='off')deactivateAdmin(a);},itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('Rol/huquq/tashkilot')),if(!a.isApproved)const PopupMenuItem(value:'approve',child:Text('Tasdiqlash')),const PopupMenuItem(value:'pass',child:Text('Parolni reset')),const PopupMenuItem(value:'off',child:Text('Faolsizlantirish'))]):null)))]);
  Future<void> addAdmin()async{final f=TextEditingController(),u=TextEditingController(),p=TextEditingController();String role='org_admin';final selected=<int>{};final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text("Admin qo'shish"),content:SizedBox(width:430,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:f,decoration:const InputDecoration(labelText:'F.I.O.')),TextField(controller:u,decoration:const InputDecoration(labelText:'Login')),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Parol')),DropdownButtonFormField<String>(initialValue:role,items:['org_admin','hr_manager','auditor'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setD(()=>role=v!),decoration:const InputDecoration(labelText:'Rol')),const SizedBox(height:8),const Align(alignment:Alignment.centerLeft,child:Text('Tashkilotlar')),for(final o in orgs)CheckboxListTile(value:selected.contains(o.id),onChanged:(v)=>setD(()=>v!?selected.add(o.id):selected.remove(o.id)),title:Text(o.name))]))),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Yaratish'))])));if(ok==true){try{await widget.api.createAdmin({'full_name':f.text,'username':u.text,'password':p.text,'role':role,'permissions':[],'organization_ids':selected.toList(),'is_approved':true});await loadAll();}catch(e){snack('$e');}}}
  Future<void> editAdmin(AdminAccount a)async{String role=a.role;final selected=<int>{...a.organizationIds};final custom=<String>{...a.permissions};final catalog=await widget.api.permissionCatalog();final all=List<String>.from(catalog['permissions']??[]);final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:Text('${a.fullName} — huquqlar'),content:SizedBox(width:480,height:500,child:ListView(children:[DropdownButtonFormField<String>(initialValue:role,items:['org_admin','hr_manager','auditor','super_admin'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setD(()=>role=v!),decoration:const InputDecoration(labelText:'Rol')),const Divider(),const Text('Tashkilotlar'),for(final o in orgs)CheckboxListTile(value:selected.contains(o.id),onChanged:(v)=>setD(()=>v!?selected.add(o.id):selected.remove(o.id)),title:Text(o.name)),const Divider(),const Text('Qo‘shimcha permissionlar'),for(final x in all)CheckboxListTile(value:custom.contains(x),onChanged:(v)=>setD(()=>v!?custom.add(x):custom.remove(x)),title:Text(x))])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Saqlash'))])));if(ok==true){try{await widget.api.updateAdmin(a.id,{'role':role,'organization_ids':selected.toList(),'permissions':custom.toList()});await loadAll();}catch(e){snack('$e');}}}
  Future<void> approveAdmin(AdminAccount a)async{try{await widget.api.approveAdmin(a.id);await loadAll();}catch(e){snack('$e');}}
  Future<void> resetPass(AdminAccount a)async{final p=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Yangi parol'),content:TextField(controller:p,obscureText:true),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Saqlash'))]));if(ok==true){try{await widget.api.resetAdminPassword(a.id,p.text);snack('Parol almashtirildi');}catch(e){snack('$e');}}}
  Future<void> deactivateAdmin(AdminAccount a)async{try{await widget.api.deactivateAdmin(a.id);await loadAll();}catch(e){snack('$e');}}

  Widget employeePage()=>wrap([
    const Text('Xodimlar',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    ...employees.map((e)=>Card(child:ListTile(
      leading:e.registrationSelfieAvailable?IconButton(icon:const Icon(Icons.photo_camera),tooltip:'Ro‘yxatdan o‘tish selfisi',onPressed:()=>showSelfie('${e.fullName} — ro‘yxatdan o‘tish selfisi',()=>widget.api.employeeRegistrationSelfie(e.id))):const CircleAvatar(child:Icon(Icons.person)),
      title:Text(e.fullName),
      subtitle:Text('${e.orgName} • ${e.code}\n${e.approved?'Tasdiqlangan':'KUTILMOQDA'} • Qurilma: ${e.deviceBound?'bog‘langan':'reset qilingan'}\nRo‘yxatdan o‘tish: ${e.registrationOutsideArea?'hududda emas':'hududda'}${e.registrationOutsideArea&&((e.registrationAreaNote??'').isNotEmpty)?' — ${e.registrationAreaNote}':''}'),
      isThreeLine:true,
      trailing:can('employee.manage')?PopupMenuButton<String>(onSelected:(v)async{try{if(v=='approve')await widget.api.approveEmployee(e.id);if(v=='reset')await widget.api.resetEmployeeDevice(e.id);if(v=='off')await widget.api.deactivateEmployee(e.id);await loadAll();}catch(x){snack('$x');}},itemBuilder:(_)=>[if(!e.approved)const PopupMenuItem(value:'approve',child:Text('Tasdiqlash')),const PopupMenuItem(value:'reset',child:Text('Qurilmani reset')),const PopupMenuItem(value:'off',child:Text('Faolsizlantirish'))]):null
    )))
  ]);

  Widget attendancePage()=>wrap([
    const Text('Davomat, GPS va selfilar',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const Text('Har bir Keldim/Ketdim yozuvida GPS va tekshiruvdan o‘tgan audit selfisi saqlanadi.'),
    const SizedBox(height:8),
    ...attendance.map((a)=>Card(child:ListTile(
      leading:Icon(a.type=='checkin'?Icons.login:Icons.logout),
      title:Text('${a.employeeName} — ${a.type=='checkin'?'Keldi':'Ketdi'}'),
      subtitle:Text('${a.orgName}\n${DateFormat('dd.MM.yyyy HH:mm').format(a.at.toLocal())}\nStatus: ${a.scheduleStatus??'-'} ${a.minutesDelta==null?'':'(${a.minutesDelta} daq)'}\nGPS: ${a.lat.toStringAsFixed(6)}, ${a.lon.toStringAsFixed(6)} ±${a.accuracy?.toStringAsFixed(0)??'-'}m\nFace: ${a.distance?.toStringAsFixed(3)??'-'} / ${a.threshold?.toStringAsFixed(3)??'-'}'),
      isThreeLine:true,
      trailing:Row(mainAxisSize:MainAxisSize.min,children:[
        if(a.selfieAvailable)IconButton(icon:const Icon(Icons.photo_camera),tooltip:'Selfini ko‘rish',onPressed:()=>showSelfie('${a.employeeName} — ${a.type=='checkin'?'Keldim':'Ketdim'} selfisi',()=>widget.api.attendanceSelfie(a.id))),
        IconButton(icon:const Icon(Icons.map),tooltip:'Xaritada ko‘rish',onPressed:()=>launchUrl(Uri.parse('https://maps.google.com/?q=${a.lat},${a.lon}'),mode:LaunchMode.externalApplication)),
      ]),
    )))
  ]);

  Widget reportPage()=>wrap([
    const Text('Oylik Excel hisobot',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),
    Row(children:[
      Expanded(child:DropdownButtonFormField<int>(initialValue:reportMonth,decoration:const InputDecoration(labelText:'Oy',border:OutlineInputBorder()),items:List.generate(12,(i)=>DropdownMenuItem(value:i+1,child:Text('${i+1}-oy'))),onChanged:(v)=>setState(()=>reportMonth=v??reportMonth))),
      const SizedBox(width:12),
      Expanded(child:DropdownButtonFormField<int>(initialValue:reportYear,decoration:const InputDecoration(labelText:'Yil',border:OutlineInputBorder()),items:List.generate(6,(i)=>DateTime.now().year-i).map((y)=>DropdownMenuItem(value:y,child:Text('$y'))).toList(),onChanged:(v)=>setState(()=>reportYear=v??reportYear))),
    ]),
    const SizedBox(height:10),
    for(final o in orgs)Card(child:ListTile(title:Text(o.name),subtitle:Text('$reportYear-yil $reportMonth-oy XLSX hisoboti'),trailing:IconButton(icon:const Icon(Icons.download),onPressed:()=>downloadReport(o))))
  ]);
  Future<void> downloadReport(Organization o)async{try{final f=await widget.api.monthlyReport(o.id,reportYear,reportMonth);await SharePlus.instance.share(ShareParams(files:[XFile(f.path)],text:'${o.name} — $reportYear.$reportMonth davomat hisoboti'));}catch(e){snack('$e');}}

  Widget settingsPage()=>wrap([
    const Text('Admin sozlamalari',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(me?['full_name']??'',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      Text('Login: ${me?['username']??''}'),
      Text('Rol: ${me?['role']??''}'),
      Text('Tashkilot ID: ${(me?['organization_ids']??[]).join(', ')}'),
      const SizedBox(height:8),
      Text('Huquqlar: ${perms.join(', ')}'),
    ]))),
    const SizedBox(height:10),
    FilledButton.icon(onPressed:changeOwnPassword,icon:const Icon(Icons.password),label:const Text('Parolimni almashtirish')),
    const SizedBox(height:8),
    OutlinedButton.icon(onPressed:logout,icon:const Icon(Icons.logout),label:const Text('Chiqish')),
  ]);

  Future<void> changeOwnPassword()async{
    final current=TextEditingController(),next=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
      title:const Text('Parolni almashtirish'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:current,obscureText:true,decoration:const InputDecoration(labelText:'Joriy parol')),
        TextField(controller:next,obscureText:true,decoration:const InputDecoration(labelText:'Yangi parol (kamida 8 belgi)')),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Bekor')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Almashtirish'))]
    ));
    if(ok==true){
      try{
        await widget.api.changeOwnPassword(current.text,next.text);
        await widget.session.clear();
        widget.onLogout();
      }catch(e){snack('$e');}
    }
  }

  Widget auditPage()=>wrap([const Text('Audit jurnal',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),...audit.map((x)=>Card(child:ListTile(title:Text(x['action']?.toString()??''),subtitle:Text('${x['created_at']}\n${x['target_type']??''} ${x['target_id']??''}\n${x['details']??{}}'),isThreeLine:true)))]);
}

import json
from cryptography.fernet import Fernet, InvalidToken
from app.core.config import settings


def _fernet() -> Fernet:
    if not settings.biometric_key:
        raise RuntimeError("BIOMETRIC_KEY is not configured")
    return Fernet(settings.biometric_key.encode())


def encrypt_embedding(vector: list[float]) -> str:
    raw = json.dumps(vector, separators=(",", ":")).encode()
    return _fernet().encrypt(raw).decode()


def decrypt_embedding(token: str) -> list[float]:
    try:
        raw = _fernet().decrypt(token.encode())
    except InvalidToken as exc:
        raise RuntimeError("Stored biometric data cannot be decrypted") from exc
    return [float(x) for x in json.loads(raw.decode())]


def encrypt_bytes(data: bytes) -> bytes:
    if not data:
        return b""
    return _fernet().encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    if not token:
        return b""
    try:
        return _fernet().decrypt(bytes(token))
    except InvalidToken as exc:
        raise RuntimeError("Stored biometric image cannot be decrypted") from exc

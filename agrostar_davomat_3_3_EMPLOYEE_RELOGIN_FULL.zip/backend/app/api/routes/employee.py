from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import current_employee
from app.db.session import get_db
from app.models.entities import Employee, Attendance

router = APIRouter(prefix="/employee", tags=["employee"])

@router.get("/me")
def me(emp: Employee = Depends(current_employee)):
    return {"id": emp.id, "full_name": emp.full_name, "employee_code": emp.employee_code,
            "organization_id": emp.organization_id, "organization_name": emp.organization.name,
            "is_approved": emp.is_approved,
            "registration_outside_area": emp.registration_outside_area,
            "registration_area_note": emp.registration_area_note}

@router.get("/history")
def history(emp: Employee = Depends(current_employee), db: Session = Depends(get_db)):
    rows = db.scalars(select(Attendance).where(Attendance.employee_id == emp.id).order_by(Attendance.occurred_at.desc()).limit(200)).all()
    return [{"id": r.id, "event_type": r.event_type, "occurred_at": r.occurred_at,
             "latitude": r.latitude, "longitude": r.longitude, "accuracy_m": r.accuracy_m,
             "is_mocked": r.is_mocked, "face_distance": r.face_distance} for r in rows]

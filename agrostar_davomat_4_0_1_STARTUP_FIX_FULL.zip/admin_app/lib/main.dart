import 'package:flutter/material.dart';
import 'core/api_client.dart';
import 'core/session_store.dart';
import 'screens/admin_home_screen.dart';
import 'screens/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AdminApp());
}

class AdminApp extends StatefulWidget {
  const AdminApp({super.key});
  @override
  State<AdminApp> createState() => _AdminAppState();
}

class _AdminAppState extends State<AdminApp> {
  final session = SessionStore();
  late final ApiClient api = ApiClient(session);

  bool? logged;
  String startupStatus = 'Admin panel ishga tushirilmoqda...';
  String? startupWarning;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => check());
  }

  Future<void> check() async {
    if (!mounted) return;
    setState(() {
      logged = null;
      startupStatus = 'Sessiya tekshirilmoqda...';
      startupWarning = null;
    });

    try {
      final token = await session.accessToken().timeout(const Duration(seconds: 4));
      if (token == null || token.isEmpty) {
        if (mounted) setState(() => logged = false);
        return;
      }

      if (mounted) setState(() => startupStatus = 'Server bilan bog‘lanmoqda...');
      try {
        await api.me().timeout(const Duration(seconds: 8));
        if (mounted) setState(() => logged = true);
        return;
      } catch (_) {
        if (mounted) setState(() => startupStatus = 'Sessiya yangilanmoqda...');
      }

      final ok = await api.refresh().timeout(
        const Duration(seconds: 8),
        onTimeout: () => false,
      );
      if (mounted) setState(() => logged = ok);
    } catch (_) {
      if (mounted) {
        setState(() {
          logged = false;
          startupWarning = 'Oldingi sessiyani tiklab bo‘lmadi. Qayta login qiling.';
        });
      }
    }
  }

  Widget _bootScreen() => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.admin_panel_settings, size: 64),
                  const SizedBox(height: 18),
                  const Text(
                    'DAVOMAT ADMIN',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 22),
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(startupStatus, textAlign: TextAlign.center),
                ],
              ),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'AGROSTAR Admin',
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF4B3F72),
          useMaterial3: true,
        ),
        home: logged == null
            ? _bootScreen()
            : logged!
                ? AdminHomeScreen(
                    api: api,
                    session: session,
                    onLogout: () => setState(() => logged = false),
                  )
                : LoginScreen(
                    api: api,
                    startupWarning: startupWarning,
                    onLogin: () => setState(() {
                      startupWarning = null;
                      logged = true;
                    }),
                  ),
      );
}

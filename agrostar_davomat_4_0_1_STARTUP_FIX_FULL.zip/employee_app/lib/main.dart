import 'dart:async';
import 'package:flutter/material.dart';
import 'core/api_client.dart';
import 'core/session_store.dart';
import 'screens/dashboard_screen.dart';
import 'screens/registration_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EmployeeApp());
}

class EmployeeApp extends StatefulWidget {
  const EmployeeApp({super.key});
  @override
  State<EmployeeApp> createState() => _EmployeeAppState();
}

class _EmployeeAppState extends State<EmployeeApp> {
  final session = SessionStore();
  late final ApiClient api = ApiClient(session);

  bool? loggedIn;
  String startupStatus = 'Ilova ishga tushirilmoqda...';
  String? startupWarning;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _check());
  }

  Future<void> _check() async {
    if (!mounted) return;
    setState(() {
      loggedIn = null;
      startupStatus = 'Sessiya tekshirilmoqda...';
      startupWarning = null;
    });

    try {
      final token = await session.accessToken().timeout(const Duration(seconds: 4));
      if (token == null || token.isEmpty) {
        if (mounted) setState(() => loggedIn = false);
        return;
      }

      if (mounted) setState(() => startupStatus = 'Server bilan bog‘lanmoqda...');
      try {
        await api.me().timeout(const Duration(seconds: 8));
        if (mounted) setState(() => loggedIn = true);
        return;
      } catch (_) {
        if (mounted) setState(() => startupStatus = 'Sessiya yangilanmoqda...');
      }

      final ok = await api.refresh().timeout(
        const Duration(seconds: 8),
        onTimeout: () => false,
      );
      if (mounted) setState(() => loggedIn = ok);
    } catch (e) {
      // Hech qachon start ekranda cheksiz qolib ketmaymiz.
      // Token/secure-storage xatosida foydalanuvchi yuz orqali qayta kira oladi.
      if (mounted) {
        setState(() {
          loggedIn = false;
          startupWarning = 'Oldingi sessiyani tiklab bo‘lmadi. Jonli selfi orqali qayta kiring.';
        });
      }
    }
  }

  Widget _bootScreen() {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.agriculture, size: 64),
                const SizedBox(height: 18),
                const Text(
                  'AGROSTAR OLTIARIQ',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 22),
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text(startupStatus, textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AGROSTAR OLTIARIQ',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF87C600),
        useMaterial3: true,
      ),
      home: loggedIn == null
          ? _bootScreen()
          : loggedIn!
              ? DashboardScreen(
                  api: api,
                  session: session,
                  onLogout: () => setState(() => loggedIn = false),
                )
              : RegistrationScreen(
                  api: api,
                  startupWarning: startupWarning,
                  onDone: () => setState(() {
                    startupWarning = null;
                    loggedIn = true;
                  }),
                ),
    );
  }
}

from __future__ import annotations
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from sqlalchemy import select
from app.db.session import SessionLocal
from app.models.entities import WorkTask
from app.services.work_config import get_work_config
from app.services.push import queue_push

_scheduler = None

def _aware(dt):
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)

def _remaining_text(due_at: datetime | None, now: datetime) -> str:
    due = _aware(due_at)
    if due is None:
        return ""
    seconds = int((due - now).total_seconds())
    if seconds <= 0:
        mins = max(1, abs(seconds) // 60)
        return f"Muddat {mins} daqiqa oldin tugagan"
    mins = max(1, seconds // 60)
    if mins < 60:
        return f"Muddat tugashiga {mins} daqiqa qoldi"
    hours = mins // 60
    rem = mins % 60
    return f"Muddat tugashiga {hours} soat {rem} daqiqa qoldi" if rem else f"Muddat tugashiga {hours} soat qoldi"

def _daily_long_next(now: datetime, cfg: dict) -> datetime:
    local = now.astimezone(ZoneInfo("Asia/Tashkent"))
    hh, mm = [int(x) for x in str(cfg.get("long_task_reminder_time", "09:30")).split(":")]
    nxt = local.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if nxt <= local:
        nxt += timedelta(days=1)
    return nxt.astimezone(timezone.utc)

def _next_for_task(task: WorkTask, now: datetime, cfg: dict) -> datetime:
    due = _aware(task.due_at)
    deadline_interval = int(cfg.get("deadline_reminder_minutes", 30))
    warning_minutes = int(cfg.get("deadline_warning_minutes", 180))
    if due is not None:
        warning_start = due - timedelta(minutes=warning_minutes)
        if now >= warning_start:
            return now + timedelta(minutes=deadline_interval)
        if task.task_type == "long":
            return min(_daily_long_next(now, cfg), warning_start)
        normal_interval = task.reminder_interval_minutes or int(cfg.get("short_task_reminder_minutes", 30))
        return min(now + timedelta(minutes=normal_interval), warning_start)
    if task.task_type == "long":
        return _daily_long_next(now, cfg)
    mins = task.reminder_interval_minutes or int(cfg.get("short_task_reminder_minutes", 30))
    return now + timedelta(minutes=mins)

def reminder_tick():
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        cfg = get_work_config(db)
        tasks = list(db.scalars(select(WorkTask).where(WorkTask.status.in_(["assigned", "in_progress"]))).all())
        for t in tasks:
            if not t.assigned_employee_id:
                continue
            due_at = _aware(t.due_at)
            due = _aware(t.next_reminder_at)
            if due is None:
                t.next_reminder_at = _next_for_task(t, now, cfg)
                continue
            if due > now:
                continue
            remaining = _remaining_text(due_at, now)
            body = t.content[:120].strip()
            if remaining:
                body = f"{remaining}. {body}" if body else remaining
            elif body:
                body = body
            else:
                body = "Topshiriqni bajarishni unutmang."
            category = "task_deadline" if due_at is not None and now >= due_at - timedelta(minutes=int(cfg.get("deadline_warning_minutes", 180))) else "task_reminder"
            queue_push(
                db, "employee", t.assigned_employee_id, f"⏰ Vazifa: {t.title}", body,
                category=category, urgent=t.priority == "urgent",
                data={"task_id": t.id, "due_at": due_at.isoformat() if due_at else ""},
            )
            t.next_reminder_at = _next_for_task(t, now, cfg)
        db.commit()
    finally:
        db.close()

def start_scheduler():
    global _scheduler
    if _scheduler is not None:
        return
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        _scheduler = BackgroundScheduler(timezone="UTC")
        _scheduler.add_job(reminder_tick, "interval", minutes=1, id="task-reminders", replace_existing=True, max_instances=1)
        _scheduler.start()
    except Exception:
        _scheduler = None

def stop_scheduler():
    global _scheduler
    if _scheduler:
        try:
            _scheduler.shutdown(wait=False)
        except Exception:
            pass
    _scheduler = None

from __future__ import annotations
from copy import deepcopy
from sqlalchemy.orm import Session
from app.models.entities import SystemSetting

WORK_CONFIG_KEY = "work_config"
DEFAULT_WORK_CONFIG = {
    "short_task_reminder_minutes": 30,
    "deadline_warning_minutes": 180,
    "deadline_reminder_minutes": 30,
    "long_task_reminder_time": "09:30",
    "friday_quiet_enabled": True,
    "friday_quiet_start": "11:30",
    "friday_quiet_end": "13:30",
    "working_hours_start": "09:00",
    "working_hours_end": "18:00",
    "location_tracking_enabled": True,
    "location_interval_minutes": 15,
    "location_distance_m": 100,
    "daily_idea_reminder_enabled": True,
    "urgent_high_priority_push": True,
    "task_module_enabled": True,
    "idea_module_enabled": True,
    "business_trip_module_enabled": True,
    "bonus_module_enabled": True,
}

def get_work_config(db: Session) -> dict:
    cfg = deepcopy(DEFAULT_WORK_CONFIG)
    row = db.get(SystemSetting, WORK_CONFIG_KEY)
    if row and isinstance(row.value, dict): cfg.update(row.value)
    return cfg

def save_work_config(db: Session, patch: dict) -> dict:
    cfg = get_work_config(db); cfg.update({k:v for k,v in patch.items() if v is not None})
    row = db.get(SystemSetting, WORK_CONFIG_KEY)
    if row is None: row = SystemSetting(key=WORK_CONFIG_KEY, value=cfg); db.add(row)
    else: row.value = cfg
    db.commit(); return get_work_config(db)

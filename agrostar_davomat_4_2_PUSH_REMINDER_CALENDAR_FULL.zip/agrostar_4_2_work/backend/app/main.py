from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import inspect, select, text
from app.core.config import settings
from app.core.security import hash_password
from app.db.session import Base, engine, SessionLocal
from app.models.entities import Organization, AdminUser, SystemSetting, DEFAULT_REPORT_COLUMNS
from app.api.routes import public, employee_auth, employee, attendance, admin_auth, admin, work, admin_work
from app.services.mobile_config import (
    MOBILE_CONFIG_KEY, DEFAULT_MOBILE_CONFIG, SECURITY_CONFIG_KEY, DEFAULT_SECURITY_CONFIG,
)
from app.services.retention import cleanup_expired_selfies
from app.services.work_config import WORK_CONFIG_KEY, DEFAULT_WORK_CONFIG
from app.services.work_scheduler import start_scheduler, stop_scheduler


def _validate_production_settings() -> None:
    if settings.env.lower() != "production": return
    problems = []
    if settings.secret_key in {"dev-only-change-me", "CHANGE_ME_WITH_64_BYTE_RANDOM_HEX"} or len(settings.secret_key) < 32: problems.append("SECRET_KEY")
    if not settings.biometric_key or settings.biometric_key.startswith("CHANGE_ME"): problems.append("BIOMETRIC_KEY")
    if settings.superadmin_password in {"ChangeMe123!", "CHANGE_ME_NOW"} or len(settings.superadmin_password) < 12: problems.append("SUPERADMIN_PASSWORD")
    if problems: raise RuntimeError("Production secretlari sozlanmagan: " + ", ".join(problems))


def _ensure_compat_schema() -> None:
    """Existing Railway database is upgraded additively without deleting data."""
    inspector = inspect(engine)
    tables = set(inspector.get_table_names())
    blob_type = "BYTEA" if engine.dialect.name == "postgresql" else "BLOB"
    json_type = "JSON" if engine.dialect.name == "postgresql" else "JSON"
    dt_type = "TIMESTAMP WITH TIME ZONE" if engine.dialect.name == "postgresql" else "DATETIME"
    bool_type = "BOOLEAN" if engine.dialect.name == "postgresql" else "BOOLEAN"
    statements: list[str] = []

    def add_columns(table: str, specs: dict[str, str]):
        if table not in tables: return
        cols = {c["name"] for c in inspector.get_columns(table)}
        for name, spec in specs.items():
            if name not in cols:
                statements.append(f"ALTER TABLE {table} ADD COLUMN {name} {spec}")

    add_columns("employees", {
        "registration_outside_area": f"{bool_type} NOT NULL DEFAULT FALSE",
        "registration_area_note": "TEXT NULL",
        "registration_selfie_enc": f"{blob_type} NULL",
        "employment_status": "VARCHAR(30) NOT NULL DEFAULT 'active'",
        "status_note": "TEXT NULL",
        "status_until": f"{dt_type} NULL",
        "archived_at": f"{dt_type} NULL",
        "job_title": "VARCHAR(160) NULL",
    })
    add_columns("attendance", {
        "selfie_enc": f"{blob_type} NULL",
        "employee_reason": "TEXT NULL",
        "admin_note": "TEXT NULL",
        "review_status": "VARCHAR(30) NOT NULL DEFAULT 'approved'",
        "suspicious_flags": f"{json_type} NULL",
        "reviewed_by_admin_id": "INTEGER NULL",
        "reviewed_at": f"{dt_type} NULL",
    })
    add_columns("organizations", {
        "late_monitoring_enabled": f"{bool_type} NOT NULL DEFAULT TRUE",
        "early_leave_monitoring_enabled": f"{bool_type} NOT NULL DEFAULT TRUE",
        "late_reason_mode": "VARCHAR(20) NOT NULL DEFAULT 'optional'",
        "early_leave_reason_mode": "VARCHAR(20) NOT NULL DEFAULT 'optional'",
        "face_threshold_override": "DOUBLE PRECISION NULL",
        "anti_spoof_policy": "VARCHAR(30) NOT NULL DEFAULT 'required'",
        "selfie_retention_days": "INTEGER NOT NULL DEFAULT 90",
        "suspicious_accuracy_m": "DOUBLE PRECISION NOT NULL DEFAULT 80",
        "suspicious_face_margin": "DOUBLE PRECISION NOT NULL DEFAULT 0.03",
        "unusual_distance_km": "DOUBLE PRECISION NOT NULL DEFAULT 50",
        "report_columns": f"{json_type} NULL",
        "custom_rules": f"{json_type} NULL",
    })
    add_columns("admin_users", {
        "failed_login_attempts": "INTEGER NOT NULL DEFAULT 0",
        "locked_until": f"{dt_type} NULL",
        "password_changed_at": f"{dt_type} NULL",
        "last_login_at": f"{dt_type} NULL",
        "force_password_change": f"{bool_type} NOT NULL DEFAULT FALSE",
    })
    if statements:
        with engine.begin() as conn:
            for statement in statements:
                conn.execute(text(statement))


def bootstrap() -> None:
    _validate_production_settings()
    Base.metadata.create_all(bind=engine)
    _ensure_compat_schema()
    db = SessionLocal()
    try:
        org = db.scalar(select(Organization).where(Organization.code == "AGROSTAR"))
        if not org:
            db.add(Organization(name="Oltiariq-Agro Star", code="AGROSTAR", location_mode="anywhere", employee_auto_approve=True))
        root = db.scalar(select(AdminUser).where(AdminUser.username == settings.superadmin_username.lower()))
        if not root:
            db.add(AdminUser(full_name=settings.superadmin_full_name, username=settings.superadmin_username.lower(),
                             password_hash=hash_password(settings.superadmin_password), role="super_admin",
                             permissions=[], is_active=True, is_approved=True))
        if db.get(SystemSetting, MOBILE_CONFIG_KEY) is None:
            db.add(SystemSetting(key=MOBILE_CONFIG_KEY, value=DEFAULT_MOBILE_CONFIG.copy()))
        if db.get(SystemSetting, SECURITY_CONFIG_KEY) is None:
            db.add(SystemSetting(key=SECURITY_CONFIG_KEY, value=DEFAULT_SECURITY_CONFIG.copy()))
        if db.get(SystemSetting, WORK_CONFIG_KEY) is None:
            db.add(SystemSetting(key=WORK_CONFIG_KEY, value=DEFAULT_WORK_CONFIG.copy()))
        db.commit()
        # Fill nullable migration columns for older rows.
        for o in db.scalars(select(Organization)).all():
            if not o.report_columns: o.report_columns = list(DEFAULT_REPORT_COLUMNS)
            if not o.custom_rules: o.custom_rules = {}
        for a in db.scalars(select(AdminUser)).all():
            if a.password_changed_at is None: a.password_changed_at = a.created_at
        db.commit()
        cleanup_expired_selfies(db)
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    bootstrap()
    if settings.work_scheduler_enabled: start_scheduler()
    yield
    stop_scheduler()


app = FastAPI(title=settings.app_name, version="4.2.0", lifespan=lifespan)
if settings.cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(public.router, prefix=settings.api_v1_prefix)
app.include_router(employee_auth.router, prefix=settings.api_v1_prefix)
app.include_router(employee.router, prefix=settings.api_v1_prefix)
app.include_router(attendance.router, prefix=settings.api_v1_prefix)
app.include_router(admin_auth.router, prefix=settings.api_v1_prefix)
app.include_router(admin.router, prefix=settings.api_v1_prefix)
app.include_router(work.router, prefix=settings.api_v1_prefix)
app.include_router(admin_work.router, prefix=settings.api_v1_prefix)


@app.get("/health")
def health():
    return {
        "status": "ok", "version": "4.2.0", "anti_spoofing": "torch+weights-ready",
        "policy_engine": "ready", "attendance_review": "ready", "remote_config": "ready",
        "selfie_retention": "ready", "cross_org_reports": "ready", "security_policy": "ready",
        "task_management": "ready", "ideas": "ready", "business_trips": "ready", "bonuses": "ready",
        "working_hours_location": "ready", "push_scheduler": "deadline-aware",
        "push_enabled": settings.push_enabled, "firebase_provider_configured": bool(settings.firebase_credentials_json),
        "firebase_client_configured": bool(settings.firebase_client_config_json),
    }

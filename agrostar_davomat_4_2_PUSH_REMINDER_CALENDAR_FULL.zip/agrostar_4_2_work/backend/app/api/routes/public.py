from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Organization
from app.schemas.common import OrganizationOut
from app.services.mobile_config import get_mobile_config
from app.core.config import settings
import json

router = APIRouter(prefix="/public", tags=["public"])

@router.get("/organizations", response_model=list[OrganizationOut])
def organizations(db: Session = Depends(get_db)):
    return list(db.scalars(select(Organization).where(Organization.is_active.is_(True)).order_by(Organization.name)).all())

@router.get("/mobile-config")
def mobile_config(db: Session = Depends(get_db)):
    """Mobil ilovalar uchun serverdan boshqariladigan feature-flaglar.

    Shu endpoint tufayli login rejimi, ro'yxatdan o'tish hududi checkboxi,
    maintenance xabari kabi mayda UX o'zgarishlari APK qayta build qilmasdan
    Super Admin panelidan o'zgartirilishi mumkin.
    """
    return get_mobile_config(db)


@router.get("/push-config")
def push_config():
    """Firebase client config is public by design; service-account secrets are never returned."""
    if not settings.push_enabled or not settings.firebase_client_config_json:
        return {"enabled": False}
    try:
        raw = json.loads(settings.firebase_client_config_json)
        return {
            "enabled": True,
            "api_key": raw.get("apiKey") or raw.get("api_key") or "",
            "app_id": raw.get("appId") or raw.get("app_id") or "",
            "messaging_sender_id": raw.get("messagingSenderId") or raw.get("messaging_sender_id") or "",
            "project_id": raw.get("projectId") or raw.get("project_id") or "",
            "storage_bucket": raw.get("storageBucket") or raw.get("storage_bucket") or "",
        }
    except Exception:
        return {"enabled": False, "error": "firebase_client_config_invalid"}

# Firebase Push setup — AgroStar 4.2

4.2 da Hodim APK Firebase Messaging'ni runtime konfiguratsiya bilan ishlatadi. `google-services.json` APK ichiga qo'yilishi shart emas.

## 1. Firebase project
Firebase Console'da Android app yarating. Firebase Android app konfiguratsiyasidan quyidagi PUBLIC qiymatlarni oling: `apiKey`, `appId`, `messagingSenderId`, `projectId`, `storageBucket` (ixtiyoriy).

Railway backend Variables ga bitta JSON sifatida qo'ying:

```
FIREBASE_CLIENT_CONFIG_JSON={"apiKey":"...","appId":"...","messagingSenderId":"...","projectId":"...","storageBucket":"..."}
```

## 2. Server service-account
Firebase Console > Project settings > Service accounts > Generate new private key. JSONni bir qatorda Railway variable sifatida qo'ying:

```
FIREBASE_CREDENTIALS_JSON={...service-account json...}
PUSH_ENABLED=true
```

## 3. Tekshirish
Backend deploydan keyin `/health` ichida `firebase_provider_configured: true` va `firebase_client_configured: true` bo'lishi kerak.

Hodim ilovaga kirganda notification permission OS tomonidan bir marta so'raladi va FCM token `/api/v1/work/push-token` ga avtomatik yoziladi.

## 4. Xulq
- yangi topshiriq: darhol ovoz + vibratsiya bilan push;
- vazifa muddati yaqinlashganda: default 3 soat oldindan, har 30 daqiqada;
- overdue vazifa: har 30 daqiqada, vazifa `done/cancelled` bo'lguncha;
- Juma 11:30–13:30 oddiy notificationlar quiet/deferred; urgent bundan mustasno.

Android'da `tasks`, `task_reminders`, `urgent` high-importance notification channel'lari native bootstrap orqali yaratiladi. Foydalanuvchi Android sozlamasida channel ovozini o'chirsa, ilova uni majburan qayta yoqa olmaydi.

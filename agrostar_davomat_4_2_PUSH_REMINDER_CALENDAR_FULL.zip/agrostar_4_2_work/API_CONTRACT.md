# Dual Face Attendance API v3

Base URL: `https://YOUR_DOMAIN/api/v1`

## Public
- `GET /public/organizations` — faol tashkilotlar. `Oltiariq-Agro Star` backend birinchi ishga tushganda avtomatik yaratiladi.

## Hodim App
- `POST /employee-auth/register` multipart: `full_name`, `organization_id`, `device_id`, `selfie`
- `POST /employee-auth/login-face` multipart: `full_name`, `organization_id`, `device_id`, `selfie`; yuz+liveness mos bo‘lsa mavjud profilga kiradi, yangi qurilma bo‘lsa avtomatik qayta bog‘laydi va eski sessiyani bekor qiladi
- `POST /employee-auth/relink` multipart: yuqoridagidek; yuz+liveness mos bo‘lsa qurilma avtomatik qayta bog‘lanadi va eski sessiya bekor qilinadi
- `POST /employee-auth/refresh` JSON: `refresh_token`
- `GET /employee/me`
- `GET /employee/history`
- `POST /attendance/checkin` multipart: `latitude`, `longitude`, `accuracy_m`, `is_mocked`, `selfie`
- `POST /attendance/checkout` multipart: shu format

Hodim autentifikatsiyalangan so‘rovlari:
- `Authorization: Bearer <employee_access_token>`
- `X-Device-ID: <secure-storage-generated UUID>`

GPS geofence bilan chegaralanmaydi. Har bir muvaffaqiyatli davomat yozuvida koordinata, accuracy, mock flag, face distance/threshold va anti-spoof score saqlanadi.

## Admin Auth
- `POST /admin-auth/register-request` — F.I.O., login, parol va tashkilot tanlab admin so‘rovi
- `POST /admin-auth/login`
- `POST /admin-auth/refresh`

## Admin App
- `GET /admin/me`
- `GET /admin/dashboard`
- `GET /admin/permissions`

### Tashkilotlar
- `GET /admin/organizations`
- `POST /admin/organizations`
- `PATCH /admin/organizations/{id}`
- `DELETE /admin/organizations/{id}` — soft deactivate

### Adminlar
- `GET /admin/admins`
- `POST /admin/admins` — Super Admin
- `PATCH /admin/admins/{id}` — rol, permission, tashkilotlar, status
- `POST /admin/admins/{id}/approve`
- `POST /admin/admins/{id}/reset-password`
- `DELETE /admin/admins/{id}` — soft deactivate

### Xodimlar
- `GET /admin/employees?organization_id=`
- `PATCH /admin/employees/{id}`
- `POST /admin/employees/{id}/approve`
- `POST /admin/employees/{id}/reset-device`
- `DELETE /admin/employees/{id}` — soft deactivate

### Davomat va hisobot
- `GET /admin/attendance?organization_id=&limit=`
- `GET /admin/reports/monthly.xlsx?organization_id=&year=&month=`
- `GET /admin/audit` — Super Admin

## Admin rollari
- `super_admin` — barcha huquqlar
- `org_admin` — o‘z tashkilotlari, xodimlar, davomat, hisobot; `org.create` orqali yangi tashkilot ham qo‘sha oladi
- `hr_manager` — xodimlar, davomat, hisobot
- `auditor` — read-only

Role permissionlariga qo‘shimcha individual permissionlar Super Admin tomonidan berilishi mumkin.

## v3.1.0 qo‘shimchalari

### POST `/employee-auth/register`
Yangi multipart maydonlar:
- `registration_outside_area`: boolean, default `false`.
- `registration_area_note`: string; `registration_outside_area=true` bo‘lsa majburiy.

### GET `/admin/today-status`
Admin ko‘ra oladigan faol xodimlarning tashkilot timezone’i bo‘yicha bugungi holatini qaytaradi:
- `checkin_done`, `checkin_at`
- `checkout_done`, `checkout_at`
- `state`: `not_started | working | completed`
- `registration_outside_area`, `registration_area_note`

### GET `/admin/employees`
Har bir xodimda qo‘shimcha:
- `registration_outside_area`
- `registration_area_note`

### GET `/admin/reports/monthly.xlsx`
Ro‘yxatdan o‘tish hududi va izohi `Davomat`, `Xodimlar xulosasi` va `Xodimlar ro'yxati` varaqlarida beriladi.


## v3.2.0 — selfi audit va Excel rasmlari

Yangi muvaffaqiyatli ro'yxatdan o'tishdan boshlab server `registration_selfie_enc` saqlaydi. Har bir muvaffaqiyatli Keldim/Ketdimda `selfie_enc` saqlanadi. Ikkalasi ham siqilgan JPEGning `BIOMETRIC_KEY` bilan Fernet-shifrlangan ko'rinishi.

Admin JSON qo'shimchalari:
- `GET /admin/employees`: `registration_selfie_available`
- `GET /admin/attendance`: `selfie_available`
- `GET /admin/today-status`: `registration_selfie_available`, `checkin_attendance_id`, `checkout_attendance_id`, `checkin_selfie_available`, `checkout_selfie_available`

Himoyalangan rasm endpointlari:
- `GET /admin/employees/{employee_id}/registration-selfie` — `image/jpeg`, `employee.read` va tashkilot access talab qiladi.
- `GET /admin/attendance/{attendance_id}/selfie` — `image/jpeg`, `attendance.read` va tashkilot access talab qiladi.

`GET /admin/reports/monthly.xlsx` endi `Davomat` varag'iga Keldim/Ketdim selfilarini, `Xodimlar ro'yxati` varag'iga ro'yxatdan o'tish selfisini ichki Excel image sifatida joylaydi.

## 3.5 Remote Config va yuz orqali qayta kirish

### GET `/api/v1/public/mobile-config`
Autentifikatsiyasiz mobil feature flaglarni qaytaradi.

Asosiy maydonlar:
- `employee_relogin_mode`: `face_only` | `name_and_face`
- `employee_name_fallback_enabled`: bool
- `employee_registration_area_toggle`: bool
- `allow_new_employee_registration`: bool
- `maintenance_enabled`: bool
- `maintenance_message`: string
- `relogin_help_text`: string

### POST `/api/v1/employee-auth/login-face`
Multipart:
- `organization_id` — required
- `device_id` — required
- `selfie` — required
- `full_name` — optional; remote config `name_and_face` bo‘lsa required

`face_only` rejimida backend tashkilotdagi faol xodimlarni embedding bo‘yicha qidiradi. Yagona aniq moslik bo‘lmasa, login rad etiladi.

### GET/PATCH `/api/v1/admin/mobile-config`
Faqat `super_admin`. Admin App orqali mobil feature flaglarni APK build qilmasdan boshqarish uchun.

# AgroStar Work 4.0 API

Employee:
- `GET /api/v1/work/config`
- `GET /api/v1/work/tasks`
- `POST /api/v1/work/tasks/{id}/start`
- `GET/POST /api/v1/work/reports`
- `POST /api/v1/work/reports/{id}/attachment`
- `GET/POST /api/v1/work/ideas`
- `GET /api/v1/work/ideas/daily-reminder`
- `GET /api/v1/work/business-trips`
- `GET /api/v1/work/bonuses`
- `POST /api/v1/work/locations/batch`
- `POST /api/v1/work/push-token`

Admin/Manager:
- `GET/PATCH /api/v1/admin/work/config`
- `GET/POST/PATCH /api/v1/admin/work/tasks`
- `GET /api/v1/admin/work/reports`
- `PATCH /api/v1/admin/work/reports/{id}/review`
- `GET /api/v1/admin/work/reports/{id}/attachments`
- `GET /api/v1/admin/work/attachments/{id}`
- `GET /api/v1/admin/work/ideas`
- `GET/POST /api/v1/admin/work/business-trips`
- `GET/POST /api/v1/admin/work/bonuses`
- `GET /api/v1/admin/work/locations/latest`
- `POST /api/v1/admin/work/push-token`

## 4.1 Media / profile additions

- `POST /api/v1/admin/work/tasks/{task_id}/attachment` — rahbarning task audio/media fayli.
- `GET /api/v1/admin/work/tasks/{task_id}/attachments` — task media ro'yxati.
- `GET /api/v1/work/tasks/{task_id}/attachments` — hodim uchun topshiriq media ro'yxati.
- `GET /api/v1/work/reports/{report_id}/attachments` — hodim o'z report media ro'yxati.
- `POST /api/v1/work/ideas/{idea_id}/attachment` — Eureka media qo'shish.
- `GET /api/v1/work/ideas/{idea_id}/attachments` — hodim Eureka media.
- `GET /api/v1/admin/work/ideas/{idea_id}/attachments` — admin Eureka media.
- `GET /api/v1/employee/profile-selfie` — hodim o'z avatar selfisi.
- `GET /api/v1/admin/me/avatar` — admin uchun mos Face ID avatar (display-only).


## 4.2 Push va deadline reminder

- `GET /api/v1/public/push-config` — Hodim ilovasi uchun public Firebase client config.
- `POST /api/v1/work/push-token` — Hodim FCM device tokenini ro‘yxatdan o‘tkazadi.
- `POST /api/v1/admin/work/tasks` — `due_at` berilsa deadline-aware reminder rejalashtiriladi.
- `PATCH /api/v1/admin/work/config` — `deadline_warning_minutes` (default 180) va `deadline_reminder_minutes` (default 30).
- Task pushlar `task`, `task_reminder`, `task_deadline` kategoriyalarida notification sound + vibration bilan yuboriladi.
- Hodim `GET /api/v1/employee/history` ma’lumotidan kalendar statuslarini hisoblaydi.

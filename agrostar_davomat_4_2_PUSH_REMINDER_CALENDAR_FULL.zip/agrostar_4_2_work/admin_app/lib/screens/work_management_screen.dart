import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import '../services/voice_record_service.dart';
import '../widgets/audio_message_card.dart';
import '../ui/agro_theme.dart';

class WorkManagementScreen extends StatefulWidget {
  final ApiClient api;
  final List<Organization> orgs;
  final List<EmployeeItem> employees;
  final bool superAdmin;
  const WorkManagementScreen({
    super.key,
    required this.api,
    required this.orgs,
    required this.employees,
    required this.superAdmin,
  });

  @override
  State<WorkManagementScreen> createState() => _WorkManagementScreenState();
}

class _WorkManagementScreenState extends State<WorkManagementScreen> {
  int tab = 0;
  bool loading = true;
  List<Map<String, dynamic>> tasks = [];
  List<Map<String, dynamic>> reports = [];
  List<Map<String, dynamic>> ideas = [];
  List<Map<String, dynamic>> trips = [];
  List<Map<String, dynamic>> locations = [];
  Map<String, dynamic> cfg = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  void snack(String x) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(x.replaceFirst('Exception: ', ''))),
      );

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final r = await Future.wait<dynamic>([
        widget.api.workTasks(),
        widget.api.workReports(),
        widget.api.workIdeas(),
        widget.api.workTrips(),
        widget.api.latestLocations(),
        widget.api.workConfig(),
      ]);
      tasks = List<Map<String, dynamic>>.from(r[0]);
      reports = List<Map<String, dynamic>>.from(r[1]);
      ideas = List<Map<String, dynamic>>.from(r[2]);
      trips = List<Map<String, dynamic>>.from(r[3]);
      locations = List<Map<String, dynamic>>.from(r[4]);
      cfg = Map<String, dynamic>.from(r[5]);
    } catch (e) {
      snack('$e');
    }
    if (mounted) setState(() => loading = false);
  }

  String dt(dynamic x) {
    if (x == null) return '-';
    final d = DateTime.tryParse(x.toString());
    return d == null ? x.toString() : DateFormat('dd.MM.yyyy HH:mm').format(d.toLocal());
  }

  Widget page(List<Widget> children) => ListView(
        padding: const EdgeInsets.all(14),
        children: children,
      );

  @override
  Widget build(BuildContext context) {
    const labels = ['Vazifalar', 'Hisobotlar', 'G‘oyalar', 'Safarlar', 'Lokatsiya', 'Sozlama'];
    final pages = [taskPage(), reportPage(), ideaPage(), tripPage(), locationPage(), configPage()];
    return loading
        ? const Center(child: CircularProgressIndicator())
        : Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Image.asset('assets/agrostar_logo.png', width: 54, height: 54),
                    const SizedBox(width: 8),
                    Expanded(child: Text('Ish boshqaruvi — ${labels[tab]}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                    IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
                  ],
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    labels.length,
                    (i) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: ChoiceChip(label: Text(labels[i]), selected: tab == i, onSelected: (_) => setState(() => tab = i)),
                    ),
                  ),
                ),
              ),
              Expanded(child: AgroBackground(child: pages[tab])),
            ],
          );
  }

  Widget taskPage() => page([
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(onPressed: createTask, icon: const Icon(Icons.add), label: const Text('Vazifa berish')),
        ),
        ...tasks.map((t) => GlassCard(
              child: ListTile(
                title: Text(t['title']?.toString() ?? ''),
                subtitle: Text(
                  '${t['content'] ?? ''}\n${t['task_type']} • ${t['priority']} • ${t['status']} • '
                  'progress ${t['progress_total'] ?? 0}${t['expected_total'] == null ? '' : '/${t['expected_total']}'}\n'
                  'Muddat: ${dt(t['due_at'])}',
                ),
                trailing:IconButton(icon:const Icon(Icons.play_circle_outline),tooltip:'Ovoz / media',onPressed:()=>showTaskFiles(t)),
                isThreeLine: true,
              ),
            )),
      ]);

  Widget reportPage() => page([
        if (reports.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Hisobotlar yo‘q.'))),
        ...reports.map((r) => GlassCard(
              child: ListTile(
                title: Text('${r['employee_name']} — ${r['report_type']}'),
                subtitle: Text(
                  '${r['text'] ?? ''}\nProgress: ${r['progress_total'] ?? '-'} • ${dt(r['created_at'])}\n'
                  'Holat: ${r['status']}${(r['manager_comment'] ?? '').toString().isEmpty ? '' : ' • ${r['manager_comment']}'}',
                ),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'files') {
                      showFiles(r);
                    } else {
                      review(r, v);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'files', child: Text('Foto/ovoz fayllari')),
                    PopupMenuItem(value: 'accepted', child: Text('Qabul qilish / bonus')),
                    PopupMenuItem(value: 'reviewed', child: Text('Ko‘rib chiqildi')),
                    PopupMenuItem(value: 'rejected', child: Text('Rad etish')),
                  ],
                ),
                isThreeLine: true,
              ),
            )),
      ]);

  Widget ideaPage() => page([
        ...ideas.map((x) => GlassCard(
              child: ListTile(
                leading: const Icon(Icons.lightbulb),
                title: Text(x['title']?.toString() ?? 'G‘oya'),
                subtitle: Text('${x['text'] ?? ''}\n${dt(x['created_at'])}'),
                trailing:IconButton(icon:const Icon(Icons.play_circle_outline),onPressed:()=>showIdeaFiles(x)),
              ),
            )),
      ]);

  Widget tripPage() => page([
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(onPressed: createTrip, icon: const Icon(Icons.add), label: const Text('Safar biriktirish')),
        ),
        ...trips.map((x) => Card(
              child: ListTile(
                leading: const Icon(Icons.flight),
                title: Text('${x['employee_name']} — ${x['title']}'),
                subtitle: Text('${x['destination']}\n${dt(x['start_at'])} — ${dt(x['end_at'])}\n${x['purpose']}'),
                isThreeLine: true,
              ),
            )),
      ]);

  Widget locationPage() => page([
        const Text('Ish vaqtidagi oxirgi lokatsiyalar', style: TextStyle(fontWeight: FontWeight.bold)),
        ...locations.map((x) => Card(
              child: ListTile(
                leading: const Icon(Icons.location_on),
                title: Text(x['employee_name']?.toString() ?? ''),
                subtitle: Text('${x['latitude']}, ${x['longitude']} ±${x['accuracy_m'] ?? '-'} m\n${dt(x['captured_at'])}'),
              ),
            )),
      ]);

  Widget configPage() => page([
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Text('Qisqa vazifa reminder: ${cfg['short_task_reminder_minutes'] ?? 30} daq'),
                Text('Uzoq vazifa reminder: ${cfg['long_task_reminder_time'] ?? '09:30'}'),
                Text('Juma tinch vaqt: ${cfg['friday_quiet_start'] ?? '11:30'}–${cfg['friday_quiet_end'] ?? '13:30'}'),
                Text('Ish vaqti lokatsiya: ${cfg['working_hours_start'] ?? '09:00'}–${cfg['working_hours_end'] ?? '18:00'}'),
                const SizedBox(height: 8),
                FilledButton(onPressed: editConfig, child: const Text('Sozlamalarni o‘zgartirish')),
              ],
            ),
          ),
        ),
      ]);

  Future<void> showFiles(Map<String, dynamic> r) async {
    try {
      final files = await widget.api.workReportAttachments(r['id'] as int);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Hisobot media fayllari'),
          content: SizedBox(
            width: 500,
            child: files.isEmpty
                ? const Text('Media fayl yo‘q')
                : ListView(
                    shrinkWrap: true,
                    children: files.map((f) {
                      if (f['media_type'] == 'audio') {
                        return AudioMessageCard(
                          title: f['filename']?.toString() ?? 'Ovozli hisobot',
                          subtitle: 'Xodim ovozli xabari',
                          loader: () => widget.api.downloadWorkAttachment(f['id'] as int, f['filename']?.toString() ?? 'audio.m4a'),
                        );
                      }
                      return ListTile(
                        leading: Icon(f['media_type'] == 'image' ? Icons.image : Icons.attach_file),
                        title: Text(f['filename']?.toString() ?? ''),
                        subtitle: Text('${f['media_type']} • ${f['size_bytes']} byte'),
                        trailing: IconButton(icon: const Icon(Icons.share), onPressed: () async {final file=await widget.api.downloadWorkAttachment(f['id'] as int,f['filename']?.toString()??'file');await SharePlus.instance.share(ShareParams(files:[XFile(file.path)]));}),
                      );
                    }).toList(),
                  ),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Yopish'))],
        ),
      );
    } catch (e) {
      snack('$e');
    }
  }

  Future<void> showTaskFiles(Map<String, dynamic> task) async {
    try {
      final files = await widget.api.workTaskAttachments(task['id'] as int);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => Dialog(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560, maxHeight: 680),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          task['title']?.toString() ?? 'Vazifa',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(c),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  Flexible(
                    child: files.isEmpty
                        ? const Center(child: Text('Media biriktirilmagan.'))
                        : ListView(
                            children: files.map((f) {
                              if (f['media_type'] == 'audio') {
                                return AudioMessageCard(
                                  title: f['filename']?.toString() ??
                                      'Ovozli topshiriq',
                                  subtitle: 'Rahbar ovozli topshirig‘i',
                                  loader: () => widget.api.downloadWorkAttachment(
                                    f['id'] as int,
                                    f['filename']?.toString() ?? 'audio.m4a',
                                  ),
                                );
                              }
                              return ListTile(
                                leading: const Icon(Icons.attach_file),
                                title: Text(f['filename']?.toString() ?? ''),
                              );
                            }).toList(),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } catch (e) {
      snack('$e');
    }
  }

  Future<void> showIdeaFiles(Map<String, dynamic> idea) async {
    try {
      final files = await widget.api.workIdeaAttachments(idea['id'] as int);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => Dialog(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560, maxHeight: 680),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'G‘oya media',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(c),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  Flexible(
                    child: files.isEmpty
                        ? const Center(child: Text('Media yo‘q.'))
                        : ListView(
                            children: files.map((f) {
                              if (f['media_type'] == 'audio') {
                                return AudioMessageCard(
                                  title: f['filename']?.toString() ??
                                      'Ovozli g‘oya',
                                  loader: () => widget.api.downloadWorkAttachment(
                                    f['id'] as int,
                                    f['filename']?.toString() ?? 'audio.m4a',
                                  ),
                                );
                              }
                              return ListTile(
                                leading: const Icon(Icons.attach_file),
                                title: Text(f['filename']?.toString() ?? ''),
                              );
                            }).toList(),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } catch (e) {
      snack('$e');
    }
  }

  Future<void> createTask() async {
    if (widget.orgs.isEmpty) return;
    int org = widget.orgs.first.id;
    int? emp;
    String type = 'short';
    String priority = 'normal';
    DateTime? dueAt;
    final title = TextEditingController();
    final content = TextEditingController();
    final expected = TextEditingController();
    final voice = VoiceRecordService();
    File? audio; bool recording=false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Yangi vazifa'),
          content: SizedBox(
            width: 520,
            child: ListView(
              shrinkWrap: true,
              children: [
                DropdownButtonFormField<int>(
                  initialValue: org,
                  items: widget.orgs.map((o) => DropdownMenuItem(value: o.id, child: Text(o.name))).toList(),
                  onChanged: (v) => setD(() {
                    org = v ?? org;
                    emp = null;
                  }),
                  decoration: const InputDecoration(labelText: 'Tashkilot'),
                ),
                DropdownButtonFormField<int?>(
                  initialValue: emp,
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('Barcha xodimlar')),
                    ...widget.employees.where((e) => e.orgId == org).map((e) => DropdownMenuItem<int?>(value: e.id, child: Text(e.fullName))),
                  ],
                  onChanged: (v) => setD(() => emp = v),
                  decoration: const InputDecoration(labelText: 'Xodim'),
                ),
                TextField(controller: title, decoration: const InputDecoration(labelText: 'Vazifa nomi')),
                TextField(controller: content, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'Mazmuni')),
                DropdownButtonFormField<String>(
                  initialValue: type,
                  items: const [
                    DropdownMenuItem(value: 'short', child: Text('Qisqa muddatli')),
                    DropdownMenuItem(value: 'long', child: Text('Uzoq muddatli')),
                  ],
                  onChanged: (v) => setD(() => type = v ?? type),
                  decoration: const InputDecoration(labelText: 'Turi'),
                ),
                DropdownButtonFormField<String>(
                  initialValue: priority,
                  items: const [
                    DropdownMenuItem(value: 'normal', child: Text('Oddiy')),
                    DropdownMenuItem(value: 'high', child: Text('Muhim')),
                    DropdownMenuItem(value: 'urgent', child: Text('SHOSHILINCH')),
                  ],
                  onChanged: (v) => setD(() => priority = v ?? priority),
                  decoration: const InputDecoration(labelText: 'Muhimlik'),
                ),
                TextField(controller: expected, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Kutilgan jami progress (ixtiyoriy)')),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final date = await showDatePicker(
                      context: c,
                      initialDate: dueAt ?? now,
                      firstDate: DateTime(now.year, now.month, now.day),
                      lastDate: DateTime(now.year + 3, 12, 31),
                    );
                    if (date == null || !c.mounted) {
                      return;
                    }
                    final time = await showTimePicker(
                      context: c,
                      initialTime: dueAt == null ? TimeOfDay.fromDateTime(now.add(const Duration(hours: 2))) : TimeOfDay.fromDateTime(dueAt!),
                    );
                    if (time == null) {
                      return;
                    }
                    setD(() => dueAt = DateTime(date.year, date.month, date.day, time.hour, time.minute));
                  },
                  icon: const Icon(Icons.event_available),
                  label: Text(dueAt == null ? 'Topshiriq muddatini belgilash' : 'Muddat: ${DateFormat('dd.MM.yyyy HH:mm').format(dueAt!)}'),
                ),
                if (dueAt == null)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('Muddat belgilanmasa deadline bo‘yicha 30 daqiqalik ogohlantirish ishlamaydi.', style: TextStyle(fontSize: 12)),
                  ),
                const SizedBox(height:10),
                OutlinedButton.icon(
                  onPressed:()async{try{if(!recording){await voice.start();setD(()=>recording=true);}else{final f=await voice.stop();setD((){recording=false;audio=f;});}}catch(e){snack('$e');}},
                  icon:Icon(recording?Icons.stop_circle:Icons.mic),
                  label:Text(recording?'Ovoz yozilmoqda — to‘xtatish':audio==null?'Ovozli topshiriq yozish':'Ovoz tayyor — qayta yozish'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Bekor')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yaratish')),
          ],
        ),
      ),
    );
    if(recording)audio=await voice.stop();
    await voice.dispose();
    if (ok == true) {
      try {
        final created=await widget.api.createWorkTask({
          'organization_id': org,
          'title': title.text,
          'content': content.text,
          'task_type': type,
          'priority': priority,
          'assigned_employee_id': emp,
          'expected_total': double.tryParse(expected.text),
          'due_at': dueAt?.toUtc().toIso8601String(),
        });
        if(audio!=null)await widget.api.uploadWorkTaskAttachment(created['id'] as int,audio!,'audio');
        await load();
      } catch (e) {
        snack('$e');
      }
    }
  }

  Future<void> review(Map<String, dynamic> r, String status) async {
    final comment = TextEditingController();
    final bonus = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (x) => AlertDialog(
        title: const Text('Hisobotni baholash'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: comment, maxLines: 3, decoration: const InputDecoration(labelText: 'Rahbar izohi')),
            if (status == 'accepted')
              TextField(controller: bonus, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Bonus so‘m (ixtiyoriy)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('Bekor')),
          FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('Saqlash')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await widget.api.reviewWorkReport(
          r['id'] as int,
          status: status,
          comment: comment.text,
          bonusAmount: double.tryParse(bonus.text),
        );
        await load();
      } catch (e) {
        snack('$e');
      }
    }
  }

  Future<void> createTrip() async {
    if (widget.orgs.isEmpty || widget.employees.isEmpty) return;
    int org = widget.orgs.first.id;
    final firstEmployees = widget.employees.where((e) => e.orgId == org).toList();
    int? emp = firstEmployees.isEmpty ? null : firstEmployees.first.id;
    final title = TextEditingController();
    final dest = TextEditingController();
    final purpose = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Xizmat safari'),
          content: SizedBox(
            width: 520,
            child: ListView(
              shrinkWrap: true,
              children: [
                DropdownButtonFormField<int>(
                  initialValue: org,
                  items: widget.orgs.map((o) => DropdownMenuItem(value: o.id, child: Text(o.name))).toList(),
                  onChanged: (v) => setD(() {
                    org = v ?? org;
                    final list = widget.employees.where((e) => e.orgId == org).toList();
                    emp = list.isEmpty ? null : list.first.id;
                  }),
                  decoration: const InputDecoration(labelText: 'Tashkilot'),
                ),
                DropdownButtonFormField<int>(
                  initialValue: emp,
                  items: widget.employees.where((e) => e.orgId == org).map((e) => DropdownMenuItem(value: e.id, child: Text(e.fullName))).toList(),
                  onChanged: (v) => setD(() => emp = v),
                  decoration: const InputDecoration(labelText: 'Xodim'),
                ),
                TextField(controller: title, decoration: const InputDecoration(labelText: 'Safar nomi')),
                TextField(controller: dest, decoration: const InputDecoration(labelText: 'Manzil')),
                TextField(controller: purpose, maxLines: 3, decoration: const InputDecoration(labelText: 'Maqsad')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Bekor')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Biriktirish')),
          ],
        ),
      ),
    );
    if (ok == true && emp != null) {
      try {
        await widget.api.createWorkTrip({
          'organization_id': org,
          'employee_id': emp,
          'title': title.text,
          'destination': dest.text,
          'purpose': purpose.text,
          'start_at': DateTime.now().toUtc().toIso8601String(),
        });
        await load();
      } catch (e) {
        snack('$e');
      }
    }
  }

  Future<void> editConfig() async {
    final short = TextEditingController(text: '${cfg['short_task_reminder_minutes'] ?? 30}');
    final long = TextEditingController(text: '${cfg['long_task_reminder_time'] ?? '09:30'}');
    final deadlineWarn = TextEditingController(text: '${cfg['deadline_warning_minutes'] ?? 180}');
    final deadlineEvery = TextEditingController(text: '${cfg['deadline_reminder_minutes'] ?? 30}');
    final interval = TextEditingController(text: '${cfg['location_interval_minutes'] ?? 15}');
    bool quiet = cfg['friday_quiet_enabled'] ?? true;
    bool track = cfg['location_tracking_enabled'] ?? true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Ish moduli sozlamalari'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: short, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Qisqa reminder (daq)')),
              TextField(controller: long, decoration: const InputDecoration(labelText: 'Uzoq reminder vaqti HH:MM')),
              TextField(controller: deadlineWarn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Muddat yaqinlashishi (daq, masalan 180)')),
              TextField(controller: deadlineEvery, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Muddat yaqinida eslatma intervali (daq, masalan 30)')),
              SwitchListTile(value: quiet, onChanged: (v) => setD(() => quiet = v), title: const Text('Juma 11:30–13:30 tinch rejim')),
              SwitchListTile(value: track, onChanged: (v) => setD(() => track = v), title: const Text('Ish vaqti lokatsiya')),
              TextField(controller: interval, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Lokatsiya intervali daq')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Bekor')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Saqlash')),
          ],
        ),
      ),
    );
    if (ok == true) {
      try {
        cfg = await widget.api.updateWorkConfig({
          'short_task_reminder_minutes': int.tryParse(short.text) ?? 30,
          'long_task_reminder_time': long.text,
          'deadline_warning_minutes': int.tryParse(deadlineWarn.text) ?? 180,
          'deadline_reminder_minutes': int.tryParse(deadlineEvery.text) ?? 30,
          'friday_quiet_enabled': quiet,
          'location_tracking_enabled': track,
          'location_interval_minutes': int.tryParse(interval.text) ?? 15,
        });
        setState(() {});
      } catch (e) {
        snack('$e');
      }
    }
  }
}

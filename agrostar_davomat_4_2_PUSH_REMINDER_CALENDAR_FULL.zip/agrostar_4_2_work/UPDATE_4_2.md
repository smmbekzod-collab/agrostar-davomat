# AgroStar 4.2 — Push + Deadline Reminder + Attendance Calendar

- Firebase Messaging client runtime init va employee FCM token avtomatik registratsiyasi.
- Yangi topshiriq background/closed app holatida notification payload bilan push.
- Task/reminder pushlar Android high-importance channel, default ovoz va vibratsiya bilan.
- Deadline reminder default 180 daqiqa oldindan boshlanadi va har 30 daqiqada qaytadi.
- Scheduler 1 daqiqada bir tekshiradi, har task `next_reminder_at` bilan dublikatlar cheklanadi.
- Hodim dashboardida davomat kalendari: yashil = Keldim+Ketdim, sariq = qisman, qizil = davomat yo'q, kelajak = neytral.
- Oldingi Face ID, selfie camera, startup, attendance, task/audio va glass UI fixlar saqlangan.

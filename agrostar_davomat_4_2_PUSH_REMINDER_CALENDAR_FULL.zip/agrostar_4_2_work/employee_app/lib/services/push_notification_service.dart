import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
import '../core/api_client.dart';

class PushNotificationService {
  PushNotificationService._();
  static final instance = PushNotificationService._();

  static const _native = MethodChannel('agrostar/notifications');
  bool _initialized = false;
  void Function(String title, String body, Map<String, dynamic> data)? _foregroundHandler;

  Future<bool> initialize(
    ApiClient api, {
    void Function(String title, String body, Map<String, dynamic> data)? onForegroundMessage,
  }) async {
    _foregroundHandler = onForegroundMessage;
    if (_initialized) {
      return true;
    }
    try {
      final cfg = await api.publicPushConfig();
      if (cfg['enabled'] != true) {
        return false;
      }
      final apiKey = cfg['api_key']?.toString() ?? '';
      final appId = cfg['app_id']?.toString() ?? '';
      final sender = cfg['messaging_sender_id']?.toString() ?? '';
      final projectId = cfg['project_id']?.toString() ?? '';
      if ([apiKey, appId, sender, projectId].any((e) => e.isEmpty)) {
        return false;
      }

      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: FirebaseOptions(
            apiKey: apiKey,
            appId: appId,
            messagingSenderId: sender,
            projectId: projectId,
            storageBucket: (cfg['storage_bucket']?.toString().isNotEmpty ?? false)
                ? cfg['storage_bucket'].toString()
                : null,
          ),
        );
      }

      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      if (Platform.isIOS) {
        await messaging.setForegroundNotificationPresentationOptions(
          alert: true,
          badge: true,
          sound: true,
        );
      }
      final token = await messaging.getToken();
      if (token != null) {
        await api.registerPushToken(
          token,
          platform: Platform.isIOS ? 'ios' : 'android',
        );
      }
      messaging.onTokenRefresh.listen((token) {
        api.registerPushToken(
          token,
          platform: Platform.isIOS ? 'ios' : 'android',
        );
      });

      FirebaseMessaging.onMessage.listen((message) async {
        final title = message.notification?.title ?? 'AgroStar';
        final body = message.notification?.body ?? '';
        try {
          await _native.invokeMethod<void>('playNotificationSound');
        } catch (_) {}
        HapticFeedback.heavyImpact();
        _foregroundHandler?.call(
          title,
          body,
          Map<String, dynamic>.from(message.data),
        );
      });
      _initialized = true;
      return true;
    } catch (_) {
      return false;
    }
  }
}

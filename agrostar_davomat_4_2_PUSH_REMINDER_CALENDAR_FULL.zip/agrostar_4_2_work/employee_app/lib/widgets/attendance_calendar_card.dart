import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../models/models.dart';
import '../ui/agro_theme.dart';

class AttendanceCalendarCard extends StatefulWidget {
  final List<AttendanceItem> history;
  const AttendanceCalendarCard({super.key, required this.history});

  @override
  State<AttendanceCalendarCard> createState() => _AttendanceCalendarCardState();
}

class _AttendanceCalendarCardState extends State<AttendanceCalendarCard> {
  late DateTime focusedDay;

  @override
  void initState() {
    super.initState();
    focusedDay = DateUtils.dateOnly(DateTime.now());
  }

  DateTime _day(DateTime value) => DateTime(value.year, value.month, value.day);

  int _status(DateTime day) {
    final target = _day(day);
    final now = _day(DateTime.now());
    if (target.isAfter(now)) {
      return 0;
    }
    bool checkinAny = false;
    bool checkoutAny = false;
    bool checkinApproved = false;
    bool checkoutApproved = false;
    for (final item in widget.history) {
      final eventDay = _day(item.occurredAt.toLocal());
      if (eventDay != target || item.reviewStatus == 'rejected') {
        continue;
      }
      if (item.eventType == 'checkin') {
        checkinAny = true;
        if (item.reviewStatus == 'approved') {
          checkinApproved = true;
        }
      } else if (item.eventType == 'checkout') {
        checkoutAny = true;
        if (item.reviewStatus == 'approved') {
          checkoutApproved = true;
        }
      }
    }
    if (checkinApproved && checkoutApproved) {
      return 3;
    }
    if (checkinAny || checkoutAny) {
      return 2;
    }
    return 1;
  }

  Color _color(BuildContext context, DateTime day) {
    switch (_status(day)) {
      case 3:
        return AgroColors.green;
      case 2:
        return const Color(0xFFF2B705);
      case 1:
        return const Color(0xFFD84444);
      default:
        return Theme.of(context)
            .colorScheme
            .surfaceContainerHighest
            .withValues(alpha: .40);
    }
  }

  DateTime get firstDay {
    if (widget.history.isEmpty) {
      return DateTime(DateTime.now().year, DateTime.now().month, 1);
    }
    final dates = widget.history
        .map((item) => _day(item.occurredAt.toLocal()))
        .toList()
      ..sort();
    return DateTime(dates.first.year, dates.first.month, 1);
  }

  Widget _cell(BuildContext context, DateTime day, {bool outside = false}) {
    final future = _day(day).isAfter(_day(DateTime.now()));
    final color = _color(context, day);
    return Container(
      margin: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: outside ? color.withValues(alpha: .30) : color,
        border: DateUtils.isSameDay(day, DateTime.now())
            ? Border.all(color: AgroColors.orange, width: 2.5)
            : null,
      ),
      alignment: Alignment.center,
      child: Text(
        '${day.day}',
        style: TextStyle(
          fontWeight: FontWeight.w700,
          color: future
              ? Theme.of(context).colorScheme.onSurfaceVariant
              : Colors.white,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const uzDow = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'];
    const months = [
      'Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun',
      'Iyul', 'Avgust', 'Sentabr', 'Oktabr', 'Noyabr', 'Dekabr',
    ];
    final safeFocusedDay = focusedDay.isBefore(firstDay) ? firstDay : focusedDay;
    return GlassCard(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.calendar_month),
                SizedBox(width: 8),
                Text(
                  'Davomat kalendari',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TableCalendar<void>(
              firstDay: firstDay,
              lastDay: DateTime(DateTime.now().year + 1, 12, 31),
              focusedDay: safeFocusedDay,
              startingDayOfWeek: StartingDayOfWeek.monday,
              calendarFormat: CalendarFormat.month,
              availableCalendarFormats: const {CalendarFormat.month: 'Oy'},
              headerStyle: HeaderStyle(
                titleCentered: true,
                formatButtonVisible: false,
                titleTextFormatter: (day, _) => '${months[day.month - 1]} ${day.year}',
              ),
              daysOfWeekStyle: DaysOfWeekStyle(
                dowTextFormatter: (day, _) => uzDow[day.weekday - 1],
                weekdayStyle: const TextStyle(fontWeight: FontWeight.w700),
                weekendStyle: const TextStyle(fontWeight: FontWeight.w700),
              ),
              onPageChanged: (day) {
                focusedDay = day;
              },
              calendarBuilders: CalendarBuilders<void>(
                defaultBuilder: (context, day, focused) => _cell(context, day),
                todayBuilder: (context, day, focused) => _cell(context, day),
                outsideBuilder: (context, day, focused) =>
                    _cell(context, day, outside: true),
              ),
            ),
            const SizedBox(height: 8),
            const Wrap(
              spacing: 12,
              runSpacing: 8,
              children: [
                _Legend(color: AgroColors.green, text: 'Keldim + Ketdim'),
                _Legend(color: Color(0xFFF2B705), text: 'Faqat bittasi'),
                _Legend(color: Color(0xFFD84444), text: 'Davomat qilinmagan'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String text;
  const _Legend({required this.color, required this.text});

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      );
}

# Railway Face Fix V4

- DeepFace `extract_faces` ichidan `max_faces` olib tashlangan.
- CPU-only PyTorch 2.5.1 o‘rnatiladi.
- Docker build vaqtida `Fasnet()` ishga tushirilmaydi.
- MiniFASNet anti-spoofing weights `curl` orqali image ichiga oldindan yuklanadi.
- Backend version: 3.0.4.

# Railway Face Fix V3 (3.0.3)

Bu versiya DeepFace anti-spoofing uchun yetishmayotgan PyTorch dependency'ni tuzatadi.

- CPU-only `torch==2.5.1` Railway Docker image ichiga o'rnatiladi.
- MiniFASNet anti-spoofing weightlari build vaqtida oldindan yuklanadi.
- `extract_faces(..., max_faces=...)` noto'g'ri parametri V2 da olib tashlangan holicha qoladi.
- `/health` javobi `3.0.3` va `anti_spoofing: torch-ready` ni ko'rsatadi.

Deploydan keyin APKni qayta build qilish shart emas: bu server-side fix.

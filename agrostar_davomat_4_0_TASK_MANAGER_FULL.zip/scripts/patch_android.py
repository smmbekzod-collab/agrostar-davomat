from pathlib import Path
import sys

android = Path(sys.argv[1])
label = sys.argv[2]
needs_location = sys.argv[3].lower() == "yes"
manifest = android / "app/src/main/AndroidManifest.xml"
s = manifest.read_text(encoding="utf-8")
permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
]
if needs_location:
    permissions += [
        '<uses-permission android:name="android.permission.CAMERA" />',
        '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
        '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
        '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
        '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
        '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />',
        '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
        '<uses-feature android:name="android.hardware.camera.front" android:required="true" />',
        '<uses-feature android:name="android.hardware.location.gps" android:required="false" />',
    ]
insert = "\n    " + "\n    ".join(permissions) + "\n"
if permissions[0] not in s:
    pos = s.find(">") + 1
    s = s[:pos] + insert + s[pos:]
s = s.replace('android:label="employee"', f'android:label="{label}"')
s = s.replace('android:label="admin"', f'android:label="{label}"')
manifest.write_text(s, encoding="utf-8")

build = android / "app/build.gradle.kts"
if build.exists():
    b = build.read_text(encoding="utf-8")
    b = b.replace("minSdk = flutter.minSdkVersion", "minSdk = 24")
    marker = 'plugins {'
    signing_header = '''import java.util.Properties\nimport java.io.FileInputStream\n\n'''
    signing_header += marker
    if 'val keystoreProperties = Properties()' not in b:
        b = b.replace(marker, signing_header, 1)
        anchor = '}\n\nandroid {'
        signing_vars = '''}\n\nval keystoreProperties = Properties()\nval keystorePropertiesFile = rootProject.file("key.properties")\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n}\n\nandroid {'''
        b = b.replace(anchor, signing_vars, 1)
        build_types = '    buildTypes {'
        signing_block = '''    signingConfigs {\n        create("release") {\n            if (keystorePropertiesFile.exists()) {\n                keyAlias = keystoreProperties.getProperty("keyAlias")\n                keyPassword = keystoreProperties.getProperty("keyPassword")\n                storeFile = keystoreProperties.getProperty("storeFile")?.let { file(it) }\n                storePassword = keystoreProperties.getProperty("storePassword")\n            }\n        }\n    }\n\n    buildTypes {'''
        b = b.replace(build_types, signing_block, 1)
        b = b.replace(
            'signingConfig = signingConfigs.getByName("debug")',
            'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")',
        )
    build.write_text(b, encoding="utf-8")

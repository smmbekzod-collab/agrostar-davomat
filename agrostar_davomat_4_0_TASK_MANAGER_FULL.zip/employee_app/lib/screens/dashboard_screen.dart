import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/api_client.dart';
import '../core/session_store.dart';
import '../models/models.dart';
import '../services/location_service.dart';
import 'selfie_camera_screen.dart';
import 'work_hub_screen.dart';
import '../services/work_location_service.dart';

class DashboardScreen extends StatefulWidget {
  final ApiClient api;
  final SessionStore session;
  final VoidCallback onLogout;
  const DashboardScreen({super.key, required this.api, required this.session, required this.onLogout});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  static const currentVersion = '4.0.0';
  EmployeeMe? me;
  List<AttendanceItem> history = [];
  MobileConfig config = const MobileConfig();
  bool loading = true;
  bool acting = false;
  final WorkLocationService workLocation = WorkLocationService();

  @override void initState() { super.initState(); _load(); }
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.replaceFirst('Exception: ', ''))));

  int _cmpVersion(String a,String b){
    List<int> p(String x)=>x.split('.').map((e)=>int.tryParse(e.replaceAll(RegExp(r'[^0-9].*'),''))??0).toList();
    final aa=p(a),bb=p(b); for(var i=0;i<3;i++){final av=i<aa.length?aa[i]:0,bv=i<bb.length?bb[i]:0;if(av!=bv)return av.compareTo(bv);}return 0;
  }
  bool get forcedUpdate => _cmpVersion(currentVersion,config.employeeMinVersion)<0;
  bool get updateAvailable => _cmpVersion(currentVersion,config.employeeLatestVersion)<0;
  bool get employeeBlocked => me!=null && me!.employmentStatus!='active';

  Future<void> _load() async {
    try { config=await widget.api.mobileConfig(); me = await widget.api.me(); history = await widget.api.history(); try { final wc=await widget.api.workConfig(); await workLocation.start(widget.api,wc); } catch (_) {} }
    catch (e) { _snack('$e'); }
    if (mounted) setState(() => loading = false);
  }

  Future<String?> _reasonFor(String type) async {
    final ctx=await widget.api.attendanceContext(type);
    final mode=ctx['reason_mode']?.toString()??'off';
    final status=ctx['schedule_status']?.toString()??'';
    if(mode=='off'||(status!='late'&&status!='early_leave'))return '';
    final ctl=TextEditingController();
    final required=mode=='required';
    final prompt=ctx['reason_prompt']?.toString()??'Sabab / izoh';
    final result=await showDialog<String?>(context:context,builder:(c)=>AlertDialog(
      title:Text(status=='late'?'Kechikish sababi':'Erta ketish sababi'),
      content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('$prompt${required?' — majburiy':' — ixtiyoriy'}'),const SizedBox(height:10),
        TextField(controller:ctl,minLines:2,maxLines:4,decoration:const InputDecoration(border:OutlineInputBorder(),labelText:'Sabab / izoh')),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,null),child:const Text('Bekor')),
        FilledButton(onPressed:(){final v=ctl.text.trim();if(required&&v.length<3){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Sabab yozish majburiy')));return;}Navigator.pop(c,v);},child:const Text('Davom etish'))],
    ));
    return result;
  }

  Future<void> _act(String type) async {
    if (acting||forcedUpdate||config.maintenanceEnabled||employeeBlocked) return;
    setState(() => acting = true);
    try {
      final reason=await _reasonFor(type);
      if(reason==null)return;
      final pos = await LocationService().current();
      final f = await Navigator.push<File>(context, MaterialPageRoute(builder: (_) => SelfieCameraScreen(title: type == 'checkin' ? 'Ishga kelish selfisi' : 'Ishdan ketish selfisi')));
      if (f == null) return;
      final result=await widget.api.attendance(type: type, latitude: pos.latitude, longitude: pos.longitude, accuracy: pos.accuracy, isMocked: pos.isMocked, selfie: f, reason: reason);
      _snack(result['message']?.toString() ?? (type == 'checkin' ? 'Ishga kelish qayd etildi' : 'Ishdan ketish qayd etildi'));
      history = await widget.api.history();
    } catch (e) { _snack('$e'); }
    finally { if (mounted) setState(() => acting = false); }
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(context: context,builder: (context) => AlertDialog(
      title: const Text('Akkauntdan chiqish'),
      content: const Text('Keyin “Oldin ro‘yxatdan o‘tganman” bo‘limidan tashkilot + jonli selfi bilan qayta kirasiz.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Bekor qilish')),FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Chiqish'))],));
    if (ok != true) return; await widget.session.clearTokens(); widget.onLogout();
  }

  String _statusLabel(String s)=>const {'active':'Faol','leave':'Ta’til','business_trip':'Xizmat safari','sick':'Kasallik','terminated':'Ishdan bo‘shagan','archived':'Arxiv'}[s]??s;

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Agro Star Hodim'), actions: [IconButton(onPressed: _logout, icon: const Icon(Icons.logout))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(18), children: [
        if(config.bannerEnabled&&config.bannerMessage.isNotEmpty)Card(color:Theme.of(context).colorScheme.secondaryContainer,child:Padding(padding:const EdgeInsets.all(14),child:Text(config.bannerMessage,style:const TextStyle(fontWeight:FontWeight.w600)))),
        if(config.maintenanceEnabled)Card(color:Theme.of(context).colorScheme.errorContainer,child:Padding(padding:const EdgeInsets.all(14),child:Text(config.maintenanceMessage.isEmpty?'Texnik ishlar olib borilmoqda':config.maintenanceMessage))),
        if(forcedUpdate||updateAvailable)Card(color:forcedUpdate?Theme.of(context).colorScheme.errorContainer:null,child:Padding(padding:const EdgeInsets.all(14),child:Text('${config.updateMessage.isEmpty?'Yangi versiya mavjud.':config.updateMessage}\nJoriy: $currentVersion • Oxirgi: ${config.employeeLatestVersion}${forcedUpdate?'\nYangilamaguncha davomat bloklangan.':''}'))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(me?.fullName ?? '', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),Text(me?.organizationName ?? ''),Text('Kod: ${me?.employeeCode ?? ''}'),
          if(me!=null&&me!.employmentStatus!='active')Text('Holat: ${_statusLabel(me!.employmentStatus)}${(me!.statusNote??'').isEmpty?'':' — ${me!.statusNote}'}',style:TextStyle(color:Theme.of(context).colorScheme.error,fontWeight:FontWeight.bold)),
        ]))),
        const SizedBox(height: 16),
        if (me?.isApproved == false) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Ro‘yxatdan o‘tish saqlandi. Admin tasdiqlashi kutilmoqda.', style: TextStyle(fontWeight: FontWeight.bold)))),
        if(employeeBlocked)Card(child:Padding(padding:const EdgeInsets.all(16),child:Text('Davomat vaqtincha bloklangan: ${_statusLabel(me!.employmentStatus)}. Zarur bo‘lsa administrator bilan bog‘laning.'))),
        FilledButton.icon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(58)), onPressed: acting || me?.isApproved == false || employeeBlocked || forcedUpdate || config.maintenanceEnabled ? null : () => _act('checkin'), icon: const Icon(Icons.login), label: const Text('🟢 ISHGA KELDIM')),
        const SizedBox(height: 12),
        FilledButton.tonalIcon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(58)), onPressed: acting || me?.isApproved == false || employeeBlocked || forcedUpdate || config.maintenanceEnabled ? null : () => _act('checkout'), icon: const Icon(Icons.logout), label: const Text('🔴 ISHDAN KETDIM')),
        const SizedBox(height: 16),
        FilledButton.tonalIcon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(58)), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkHubScreen(api: widget.api))), icon: const Icon(Icons.workspaces_outline), label: const Text('VAZIFALAR • HISOBOT • EUREKA • BONUS')),
        const SizedBox(height: 20),
        const Text('Davomat tarixi', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),const SizedBox(height: 8),
        if (history.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Hozircha davomat yozuvi yo‘q.'))),
        ...history.map((x) => Card(child: ListTile(
          leading: Icon(x.eventType == 'checkin' ? Icons.login : Icons.logout),
          title: Text('${x.eventType == 'checkin' ? 'Ishga keldi' : 'Ishdan ketdi'}${x.reviewStatus=='pending_review'?' • TEKSHIRUVDA':x.reviewStatus=='rejected'?' • RAD ETILGAN':''}'),
          subtitle: Text('${DateFormat('dd.MM.yyyy HH:mm').format(x.occurredAt.toLocal())}\nGPS: ${x.latitude.toStringAsFixed(6)}, ${x.longitude.toStringAsFixed(6)}  ±${x.accuracy?.toStringAsFixed(0) ?? '-'} m${x.scheduleStatus=='late'?'\nKechikish: ${x.minutesDelta??0} daq':x.scheduleStatus=='early_leave'?'\nErta ketish: ${x.minutesDelta??0} daq':''}${(x.employeeReason??'').isEmpty?'':'\nSabab: ${x.employeeReason}'}${x.suspiciousFlags.isEmpty?'':'\nTekshiruv: ${x.suspiciousFlags.join(', ')}'}'),
          isThreeLine: true,
        ))),
      ])),
    );
  }
}

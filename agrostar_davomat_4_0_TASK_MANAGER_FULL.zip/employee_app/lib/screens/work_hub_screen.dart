import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/api_client.dart';
import 'work_photo_screen.dart';
import '../services/voice_record_service.dart';

class WorkHubScreen extends StatefulWidget {
  final ApiClient api;
  const WorkHubScreen({super.key, required this.api});

  @override
  State<WorkHubScreen> createState() => _WorkHubScreenState();
}

class _WorkHubScreenState extends State<WorkHubScreen> {
  int tab = 0;
  bool loading = true;
  List<Map<String, dynamic>> tasks = [];
  List<Map<String, dynamic>> reports = [];
  List<Map<String, dynamic>> ideas = [];
  List<Map<String, dynamic>> trips = [];
  Map<String, dynamic> bonus = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  void snack(String x) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(x.replaceFirst('Exception: ', ''))),
      );

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait<dynamic>([
        widget.api.workTasks(),
        widget.api.workReports(),
        widget.api.ideas(),
        widget.api.businessTrips(),
        widget.api.bonuses(),
      ]);
      tasks = List<Map<String, dynamic>>.from(result[0]);
      reports = List<Map<String, dynamic>>.from(result[1]);
      ideas = List<Map<String, dynamic>>.from(result[2]);
      trips = List<Map<String, dynamic>>.from(result[3]);
      bonus = Map<String, dynamic>.from(result[4]);

      final oldIdea = await widget.api.dailyIdea();
      if (oldIdea != null && mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          showDialog<void>(
            context: context,
            builder: (c) => AlertDialog(
              title: const Text('💡 Bugungi eski g‘oya'),
              content: Text(
                '${oldIdea['title']}\n\n${oldIdea['text']}\n\n${oldIdea['created_at'] ?? ''}',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(c),
                  child: const Text('Yopish'),
                ),
              ],
            ),
          );
        });
      }
    } catch (e) {
      snack('$e');
    }
    if (mounted) setState(() => loading = false);
  }

  String dt(dynamic x) {
    if (x == null) return '-';
    final d = DateTime.tryParse(x.toString());
    return d == null
        ? x.toString()
        : DateFormat('dd.MM.yyyy HH:mm').format(d.toLocal());
  }

  Widget page(List<Widget> children) => RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: children,
        ),
      );

  @override
  Widget build(BuildContext context) {
    const labels = ['Vazifalar', 'Hisobotlar', 'Xizmat safari', 'Eureka', 'Bonus'];
    final pages = [taskPage(), reportPage(), tripPage(), ideaPage(), bonusPage()];
    return Scaffold(
      appBar: AppBar(
        title: Text('AgroStar Ish — ${labels[tab]}'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.task_alt), label: 'Vazifa'),
          NavigationDestination(icon: Icon(Icons.summarize), label: 'Hisobot'),
          NavigationDestination(icon: Icon(Icons.flight_takeoff), label: 'Safar'),
          NavigationDestination(icon: Icon(Icons.lightbulb), label: 'Eureka'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Bonus'),
        ],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : pages[tab],
    );
  }

  Widget taskPage() => page([
        Row(
          children: [
            Image.asset('assets/agrostar_logo.png', width: 58, height: 58, fit: BoxFit.contain),
            const SizedBox(width: 10),
            const Expanded(
              child: Text('Mening vazifalarim', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (tasks.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Hozircha vazifa yo‘q.'))),
        ...tasks.map((t) => Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            t['title']?.toString() ?? '',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Chip(label: Text((t['priority'] ?? 'normal').toString().toUpperCase())),
                      ],
                    ),
                    Text(t['content']?.toString() ?? ''),
                    const SizedBox(height: 8),
                    Text(
                      'Holat: ${t['status']} • Muddat: ${dt(t['due_at'])}\n'
                      'Progress: ${t['progress_total'] ?? 0}${t['expected_total'] == null ? '' : ' / ${t['expected_total']}'}',
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        if (t['status'] == 'assigned')
                          OutlinedButton(
                            onPressed: () async {
                              try {
                                await widget.api.startTask(t['id'] as int);
                                await load();
                              } catch (e) {
                                snack('$e');
                              }
                            },
                            child: const Text('Boshlash'),
                          ),
                        FilledButton(
                          onPressed: () => reportDialog(task: t),
                          child: const Text('Progress hisobot'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )),
      ]);

  Widget reportPage() => page([
        Row(
          children: [
            const Expanded(child: Text('Hisobotlar', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
            FilledButton.icon(
              onPressed: () => reportDialog(),
              icon: const Icon(Icons.add),
              label: const Text('Proaktiv'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ...reports.map((r) => Card(
              child: ListTile(
                leading: Icon(r['report_type'] == 'proactive' ? Icons.bolt : Icons.description),
                title: Text(
                  r['report_type'] == 'business_trip'
                      ? 'Xizmat safari hisoboti'
                      : r['report_type'] == 'proactive'
                          ? 'Proaktiv hisobot'
                          : 'Vazifa hisoboti',
                ),
                subtitle: Text(
                  '${r['text'] ?? ''}\nProgress: ${r['progress_total'] ?? '-'} • ${dt(r['created_at'])}\n'
                  'Holat: ${r['status']}${(r['manager_comment'] ?? '').toString().isEmpty ? '' : '\nRahbar: ${r['manager_comment']}'}',
                ),
                isThreeLine: true,
              ),
            )),
      ]);

  Widget tripPage() => page([
        const Text('Xizmat safarlari', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        ...trips.map((x) => Card(
              child: ListTile(
                leading: const Icon(Icons.flight),
                title: Text(x['title']?.toString() ?? ''),
                subtitle: Text(
                  '${x['destination'] ?? ''}\n${dt(x['start_at'])} — ${dt(x['end_at'])}\n${x['purpose'] ?? ''}',
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.add_comment),
                  onPressed: () => reportDialog(trip: x),
                ),
                isThreeLine: true,
              ),
            )),
        if (trips.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Faol xizmat safari yo‘q.'))),
      ]);

  Widget ideaPage() => page([
        Row(
          children: [
            const Expanded(child: Text('💡 Eureka — g‘oyalar', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
            FilledButton.icon(onPressed: ideaDialog, icon: const Icon(Icons.add), label: const Text('G‘oya')),
          ],
        ),
        ...ideas.map((x) => Card(
              child: ListTile(
                title: Text(x['title']?.toString() ?? 'G‘oya'),
                subtitle: Text('${x['text'] ?? ''}\n${dt(x['created_at'])}'),
                isThreeLine: true,
              ),
            )),
      ]);

  Widget bonusPage() {
    final total = (bonus['total'] as num?)?.toDouble() ?? 0;
    final raw = bonus['items'];
    final items = raw is List
        ? raw.map((e) => Map<String, dynamic>.from(e as Map)).toList()
        : <Map<String, dynamic>>[];
    return page([
      Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              const Icon(Icons.emoji_events, size: 48),
              Text('${NumberFormat('#,##0').format(total)} so‘m', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const Text('Jami bonus'),
            ],
          ),
        ),
      ),
      ...items.map((x) => Card(
            child: ListTile(
              leading: Text(x['emoji']?.toString() ?? '💵', style: const TextStyle(fontSize: 28)),
              title: Text('${NumberFormat('#,##0').format((x['amount'] as num?) ?? 0)} so‘m'),
              subtitle: Text('${x['note'] ?? ''}\n${dt(x['created_at'])}'),
            ),
          )),
    ]);
  }

  Future<void> reportDialog({Map<String, dynamic>? task, Map<String, dynamic>? trip}) async {
    final text = TextEditingController();
    final delta = TextEditingController();
    final total = TextEditingController();
    File? photo;
    File? audio;
    final voice = VoiceRecordService();
    bool recording = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(task != null ? 'Progress hisobot' : trip != null ? 'Xizmat safari hisoboti' : 'Proaktiv hisobot'),
          content: SizedBox(
            width: 500,
            child: ListView(
              shrinkWrap: true,
              children: [
                TextField(
                  controller: text,
                  minLines: 3,
                  maxLines: 7,
                  decoration: const InputDecoration(labelText: 'Matnli hisobot', border: OutlineInputBorder()),
                ),
                if (task != null) ...[
                  TextField(controller: delta, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Bugungi progress (masalan 500)')),
                  TextField(controller: total, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jami progress (masalan 2000)')),
                ],
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        final f = await Navigator.push<File>(context, MaterialPageRoute(builder: (_) => const WorkPhotoScreen()));
                        if (f != null) setD(() => photo = f);
                      },
                      icon: const Icon(Icons.photo_camera),
                      label: Text(photo == null ? 'Foto qo‘shish' : 'Foto tayyor'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () async {
                        try {
                          if (!recording) {
                            await voice.start();
                            setD(() => recording = true);
                          } else {
                            final f = await voice.stop();
                            setD(() {
                              recording = false;
                              audio = f;
                            });
                          }
                        } catch (e) {
                          snack('$e');
                        }
                      },
                      icon: Icon(recording ? Icons.stop : Icons.mic),
                      label: Text(recording ? 'Ovozni to‘xtatish' : audio == null ? 'Ovoz yozish' : 'Ovoz tayyor'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Bekor')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yuborish')),
          ],
        ),
      ),
    );

    if (recording) audio = await voice.stop();
    await voice.dispose();
    if (ok == true) {
      try {
        final r = await widget.api.submitWorkReport(
          taskId: task?['id'] as int?,
          businessTripId: trip?['id'] as int?,
          text: text.text,
          progressDelta: double.tryParse(delta.text),
          progressTotal: double.tryParse(total.text),
        );
        final id = r['id'] as int;
        if (photo != null) await widget.api.uploadReportAttachment(id, photo!, 'image');
        if (audio != null) await widget.api.uploadReportAttachment(id, audio!, 'audio');
        await load();
      } catch (e) {
        snack('$e');
      }
    }
  }

  Future<void> ideaDialog() async {
    final title = TextEditingController(text: 'Yangi g‘oya');
    final text = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Eureka — g‘oya'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Sarlavha')),
            TextField(controller: text, minLines: 3, maxLines: 7, decoration: const InputDecoration(labelText: 'G‘oya', border: OutlineInputBorder())),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Bekor')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Saqlash')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await widget.api.addIdea(title.text, text.text);
        await load();
      } catch (e) {
        snack('$e');
      }
    }
  }
}

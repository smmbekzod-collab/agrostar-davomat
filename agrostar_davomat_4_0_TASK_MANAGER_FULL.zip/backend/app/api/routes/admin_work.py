from __future__ import annotations
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import Response
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.api.deps import current_admin, require_permission
from app.db.session import get_db
from app.models.entities import AdminUser, Employee, WorkTask, WorkReport, WorkAttachment, Idea, BonusAward, BusinessTrip, EmployeeLocation, PushDevice
from app.schemas.work import TaskCreate, TaskUpdate, ReportReview, BonusCreate, TripCreate, WorkConfigUpdate, PushTokenIn
from app.services.permissions import effective_permissions
from app.services.work_config import get_work_config, save_work_config
from app.services.push import queue_push
from app.services.audit import add_audit

router=APIRouter(prefix="/admin/work",tags=["admin-work"])

def allowed_orgs(admin:AdminUser)->set[int]:
    if admin.role=="super_admin":return set()
    return {x.organization_id for x in admin.org_links}

def ensure_org(admin:AdminUser,org_id:int):
    a=allowed_orgs(admin)
    if admin.role!="super_admin" and org_id not in a: raise HTTPException(403,"Tashkilotga ruxsat yo‘q")

def task_json(t:WorkTask)->dict:
    return {"id":t.id,"organization_id":t.organization_id,"title":t.title,"content":t.content,"task_type":t.task_type,"priority":t.priority,"status":t.status,"assigned_employee_id":t.assigned_employee_id,"due_at":t.due_at,"expected_total":t.expected_total,"progress_total":t.progress_total,"reminder_interval_minutes":t.reminder_interval_minutes,"next_reminder_at":t.next_reminder_at,"created_at":t.created_at}

def report_json(r:WorkReport)->dict:
    return {"id":r.id,"organization_id":r.organization_id,"employee_id":r.employee_id,"employee_name":r.employee.full_name if r.employee else "","task_id":r.task_id,"business_trip_id":r.business_trip_id,"report_type":r.report_type,"text":r.text,"progress_delta":r.progress_delta,"progress_total":r.progress_total,"status":r.status,"manager_comment":r.manager_comment,"created_at":r.created_at}

@router.get("/config")
def config(admin:AdminUser=Depends(current_admin),db:Session=Depends(get_db)):
    return get_work_config(db)

@router.patch("/config")
def config_update(body:WorkConfigUpdate,admin:AdminUser=Depends(require_permission("settings.manage")),db:Session=Depends(get_db)):
    result=save_work_config(db,body.model_dump(exclude_unset=True));add_audit(db,admin.id,"work_config.update","system","work_config",body.model_dump(exclude_unset=True));return result

@router.get("/tasks")
def tasks(organization_id:int|None=None,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    q=select(WorkTask).order_by(WorkTask.created_at.desc())
    if organization_id is not None:ensure_org(admin,organization_id);q=q.where(WorkTask.organization_id==organization_id)
    elif admin.role!="super_admin":q=q.where(WorkTask.organization_id.in_(list(allowed_orgs(admin))))
    return [task_json(x) for x in db.scalars(q.limit(1000)).all()]

@router.post("/tasks")
def create_task(body:TaskCreate,admin:AdminUser=Depends(require_permission("work.manage")),db:Session=Depends(get_db)):
    ensure_org(admin,body.organization_id)
    if body.assigned_employee_id:
        e=db.get(Employee,body.assigned_employee_id)
        if not e or e.organization_id!=body.organization_id:raise HTTPException(400,"Xodim tashkilotga mos emas")
    cfg=get_work_config(db);now=datetime.now(timezone.utc)
    if body.task_type=="short":
        mins=body.reminder_interval_minutes or int(cfg.get("short_task_reminder_minutes",30));next_reminder=now+timedelta(minutes=mins)
    else:
        local=datetime.now(ZoneInfo("Asia/Tashkent"));hh,mm=[int(x) for x in str(cfg.get("long_task_reminder_time","09:30")).split(':')]; nxt=local.replace(hour=hh,minute=mm,second=0,microsecond=0)
        if nxt<=local:nxt+=timedelta(days=1)
        next_reminder=nxt.astimezone(timezone.utc)
    t=WorkTask(**body.model_dump(),created_by_admin_id=admin.id,next_reminder_at=next_reminder);db.add(t);db.commit();db.refresh(t)
    if t.assigned_employee_id: queue_push(db,"employee",t.assigned_employee_id,f"Yangi vazifa: {t.title}",t.content[:180],category="task",urgent=t.priority=="urgent",data={"task_id":t.id})
    add_audit(db,admin.id,"work.task.create","task",str(t.id),{"title":t.title});return task_json(t)

@router.patch("/tasks/{task_id}")
def update_task(task_id:int,body:TaskUpdate,admin:AdminUser=Depends(require_permission("work.manage")),db:Session=Depends(get_db)):
    t=db.get(WorkTask,task_id)
    if not t:raise HTTPException(404,"Vazifa topilmadi")
    ensure_org(admin,t.organization_id)
    for k,v in body.model_dump(exclude_unset=True).items():setattr(t,k,v)
    db.commit();db.refresh(t);return task_json(t)

@router.get("/reports")
def reports(organization_id:int|None=None,status:str|None=None,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    q=select(WorkReport).order_by(WorkReport.created_at.desc())
    if organization_id is not None:ensure_org(admin,organization_id);q=q.where(WorkReport.organization_id==organization_id)
    elif admin.role!="super_admin":q=q.where(WorkReport.organization_id.in_(list(allowed_orgs(admin))))
    if status:q=q.where(WorkReport.status==status)
    return [report_json(x) for x in db.scalars(q.limit(1000)).all()]

@router.patch("/reports/{report_id}/review")
def review(report_id:int,body:ReportReview,admin:AdminUser=Depends(require_permission("work.review")),db:Session=Depends(get_db)):
    r=db.get(WorkReport,report_id)
    if not r:raise HTTPException(404,"Hisobot topilmadi")
    ensure_org(admin,r.organization_id);r.status=body.status;r.manager_comment=body.manager_comment;r.reviewed_by_admin_id=admin.id;r.reviewed_at=datetime.now(timezone.utc)
    if body.bonus_amount:
        db.add(BonusAward(organization_id=r.organization_id,employee_id=r.employee_id,admin_id=admin.id,report_id=r.id,task_id=r.task_id,amount=body.bonus_amount,emoji=body.bonus_emoji,note=body.manager_comment or "Hisobot uchun bonus"))
    db.commit();queue_push(db,"employee",r.employee_id,"Hisobotingiz ko‘rib chiqildi",body.manager_comment or f"Holat: {body.status}",category="report_review",data={"report_id":r.id});return report_json(r)

@router.post("/bonuses")
def bonus(body:BonusCreate,admin:AdminUser=Depends(require_permission("bonus.manage")),db:Session=Depends(get_db)):
    e=db.get(Employee,body.employee_id)
    if not e:raise HTTPException(404,"Xodim topilmadi")
    ensure_org(admin,e.organization_id);x=BonusAward(organization_id=e.organization_id,employee_id=e.id,admin_id=admin.id,**body.model_dump(exclude={"employee_id"}));db.add(x);db.commit();db.refresh(x);queue_push(db,"employee",e.id,f"Bonus {x.emoji}",f"{x.amount:,.0f} so‘m — {x.note}",category="bonus");return {"id":x.id,"amount":x.amount,"emoji":x.emoji}

@router.get("/bonuses")
def bonuses(employee_id:int|None=None,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    q=select(BonusAward).order_by(BonusAward.created_at.desc())
    if employee_id:q=q.where(BonusAward.employee_id==employee_id)
    rows=list(db.scalars(q.limit(1000)).all());return [{"id":x.id,"employee_id":x.employee_id,"amount":x.amount,"emoji":x.emoji,"note":x.note,"created_at":x.created_at} for x in rows]

@router.get("/ideas")
def ideas(organization_id:int|None=None,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    q=select(Idea).order_by(Idea.created_at.desc())
    if organization_id is not None:ensure_org(admin,organization_id);q=q.where(Idea.organization_id==organization_id)
    elif admin.role!="super_admin":q=q.where(Idea.organization_id.in_(list(allowed_orgs(admin))))
    return [{"id":x.id,"employee_id":x.employee_id,"admin_id":x.admin_id,"title":x.title,"text":x.text,"status":x.status,"created_at":x.created_at} for x in db.scalars(q.limit(1000)).all()]

@router.post("/business-trips")
def create_trip(body:TripCreate,admin:AdminUser=Depends(require_permission("work.manage")),db:Session=Depends(get_db)):
    ensure_org(admin,body.organization_id);e=db.get(Employee,body.employee_id)
    if not e or e.organization_id!=body.organization_id:raise HTTPException(400,"Xodim mos emas")
    x=BusinessTrip(**body.model_dump(),created_by_admin_id=admin.id,status="active");db.add(x);e.employment_status="business_trip";db.commit();db.refresh(x);queue_push(db,"employee",e.id,f"Xizmat safari: {x.title}",x.destination,category="business_trip");return {"id":x.id,"title":x.title,"status":x.status}

@router.get("/business-trips")
def trips(admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    q=select(BusinessTrip).order_by(BusinessTrip.start_at.desc())
    if admin.role!="super_admin":q=q.where(BusinessTrip.organization_id.in_(list(allowed_orgs(admin))))
    return [{"id":x.id,"organization_id":x.organization_id,"employee_id":x.employee_id,"employee_name":x.employee.full_name if x.employee else "","title":x.title,"destination":x.destination,"purpose":x.purpose,"start_at":x.start_at,"end_at":x.end_at,"status":x.status} for x in db.scalars(q.limit(1000)).all()]

@router.get("/locations/latest")
def latest_locations(organization_id:int|None=None,admin:AdminUser=Depends(require_permission("location.read")),db:Session=Depends(get_db)):
    if organization_id is not None:ensure_org(admin,organization_id)
    eq=select(Employee)
    if organization_id is not None:eq=eq.where(Employee.organization_id==organization_id)
    elif admin.role!="super_admin":eq=eq.where(Employee.organization_id.in_(list(allowed_orgs(admin))))
    out=[]
    for e in db.scalars(eq.where(Employee.is_active.is_(True))).all():
        loc=db.scalar(select(EmployeeLocation).where(EmployeeLocation.employee_id==e.id).order_by(EmployeeLocation.captured_at.desc()).limit(1))
        if loc:out.append({"employee_id":e.id,"employee_name":e.full_name,"organization_id":e.organization_id,"latitude":loc.latitude,"longitude":loc.longitude,"accuracy_m":loc.accuracy_m,"captured_at":loc.captured_at})
    return out

@router.post("/push-token")
def push_token(body:PushTokenIn,admin:AdminUser=Depends(current_admin),db:Session=Depends(get_db)):
    existing=db.scalar(select(PushDevice).where(PushDevice.actor_type=="admin",PushDevice.actor_id==admin.id,PushDevice.token==body.token))
    if existing:existing.enabled=True;existing.platform=body.platform;existing.last_seen_at=datetime.now(timezone.utc)
    else:db.add(PushDevice(actor_type="admin",actor_id=admin.id,platform=body.platform,token=body.token))
    db.commit();return {"detail":"Push qurilma saqlandi"}


@router.get("/reports/{report_id}/attachments")
def report_attachments(report_id:int,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    r=db.get(WorkReport,report_id)
    if not r:raise HTTPException(404,"Hisobot topilmadi")
    ensure_org(admin,r.organization_id)
    rows=db.scalars(select(WorkAttachment).where(WorkAttachment.owner_type=="report",WorkAttachment.owner_id==r.id).order_by(WorkAttachment.id)).all()
    return [{"id":x.id,"media_type":x.media_type,"filename":x.filename,"content_type":x.content_type,"size_bytes":x.size_bytes} for x in rows]

@router.get("/attachments/{attachment_id}")
def attachment(attachment_id:int,admin:AdminUser=Depends(require_permission("work.read")),db:Session=Depends(get_db)):
    a=db.get(WorkAttachment,attachment_id)
    if not a:raise HTTPException(404,"Fayl topilmadi")
    ensure_org(admin,a.organization_id)
    return Response(content=a.data,media_type=a.content_type,headers={"Content-Disposition":f'attachment; filename="{a.filename}"'})
